-- phpMyAdmin SQL Dump
-- version 4.6.6
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Dec 23, 2020 at 09:58 AM
-- Server version: 5.7.17-log
-- PHP Version: 5.6.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `2021_netcafe`
--

-- --------------------------------------------------------

--
-- Table structure for table `asset`
--

CREATE TABLE `asset` (
  `id` int(11) NOT NULL,
  `rekening` varchar(50) DEFAULT NULL,
  `bank` varchar(50) DEFAULT NULL,
  `pemilik` varchar(50) DEFAULT NULL,
  `nohp` varchar(50) DEFAULT NULL,
  `provider` varchar(50) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `log_payments`
--

CREATE TABLE `log_payments` (
  `id` int(11) NOT NULL,
  `ref_fullname` varchar(255) NOT NULL,
  `ref_phone` varchar(50) NOT NULL,
  `ref_detial` varchar(255) NOT NULL,
  `ref_amount` double(10,2) NOT NULL DEFAULT '0.00',
  `ref_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `log_payments`
--

INSERT INTO `log_payments` (`id`, `ref_fullname`, `ref_phone`, `ref_detial`, `ref_amount`, `ref_time`) VALUES
(1, 'จตุรพร สุริยา', '0903696969', '390บ. 100/100mbs', 390.00, '2020-12-23 01:49:07'),
(2, 'จตุรพร สุริยา', '0903696969', '390บ. 100/100mbs', 390.00, '2020-12-23 02:53:56');

-- --------------------------------------------------------

--
-- Table structure for table `members`
--

CREATE TABLE `members` (
  `id` int(11) NOT NULL,
  `username` varchar(255) NOT NULL COMMENT 'ชื่อผู้ใช้งาน',
  `first_name` varchar(255) NOT NULL,
  `last_name` varchar(255) NOT NULL,
  `phone` text NOT NULL,
  `packge` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL,
  `contract` varchar(255) NOT NULL,
  `status` varchar(255) DEFAULT 'ปกติ',
  `ref_group` set('5','10','15','20','25') NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `members`
--

INSERT INTO `members` (`id`, `username`, `first_name`, `last_name`, `phone`, `packge`, `address`, `contract`, `status`, `ref_group`, `created_at`) VALUES
(1, 'user@fttx', 'จตุรพร', 'สุริยา', '0903696969', '390บ. 100/100mbs', '115 ม.3 ต.โคกตะเคียน อ.กาบเชิง จ.สุรินทร์', '1ปี', 'ปกติ', '5', '2020-12-23 02:53:56');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(255) NOT NULL COMMENT 'ชื่อผู้ใช้งาน',
  `password` varchar(255) NOT NULL,
  `first_name` varchar(255) NOT NULL,
  `last_name` varchar(255) NOT NULL,
  `phone` text NOT NULL,
  `packge` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL,
  `department` varchar(255) NOT NULL,
  `is_confirmed` tinyint(1) NOT NULL DEFAULT '0' COMMENT 'ประเภทผู้ใช้ เบิก - จ่าย',
  `contract` varchar(255) NOT NULL,
  `status` varchar(255) DEFAULT 'ปกติ',
  `ref_group` set('5','10','15','20','25') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `password`, `first_name`, `last_name`, `phone`, `packge`, `address`, `department`, `is_confirmed`, `contract`, `status`, `ref_group`) VALUES
(1, '0123456789', '$2y$10$H9IvrTFTgPtB4Rlf6MhPFeYbLyMnetYGMFOY3PV2Q/mvu5LObQzfG', 'จตุรพร', 'สุริยา', '0903696969', '390บ. 100/100mbs', '115 ม.3 ต.โคกตะเคียน อ.กาบเชิง จ.สุรินทร์', 'it', 0, '1ปี			', 'ปกติ', '5');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `asset`
--
ALTER TABLE `asset`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `log_payments`
--
ALTER TABLE `log_payments`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `members`
--
ALTER TABLE `members`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `asset`
--
ALTER TABLE `asset`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `log_payments`
--
ALTER TABLE `log_payments`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `members`
--
ALTER TABLE `members`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
