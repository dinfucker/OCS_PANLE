<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/*
| -------------------------------------------------------------------------
| URI ROUTING
| -------------------------------------------------------------------------
*/


$route['default_controller'] = 'login/login';

$route['panel/reseller/(:any)/addsaldo-via-hp'] = 'seller/addsaldo_hp';
$route['panel/reseller/(:any)/addsaldo-via-req'] = 'seller/addsaldo_req';

$route['panel/seller/(:any)'] = 'seller/seller/$1';
$route['panel/admin/(:any)'] = 'admin/admin/$1';
$route['panel/administrator/edit/(:any)/(:any)/(:any)'] = 'admin/lock/$2/$3';
$route['panel/seller/(:any)/(:any)/(:any)/(:any)'] = 'seller/buy/$4';
$route['panel/administrator/edit/(:any)/(:any)'] = 'admin/edit/$2';
$route['panel/administrator/(:any)/(:any)'] = 'admin/server/$2';
$route['join'] = 'seller/seller';
$route['panel/reseller/cek_account/(:any)'] = 'seller/cek_account/$1';



/*
| -------------------------------------------------------------------------
| URI ROUTING NEW 2020
| -------------------------------------------------------------------------
*/



$route['signin'] = 'login/login';
$route['signup'] = 'login/register';
$route['signout'] = 'login/logout';
$route['forgot'] = 'forgot/index';
$route['profile'] = 'login/setting';
$route['contact'] = 'login/contact';



$route['servers'] = 'seller/seller';



$route['payments'] = 'topup/index';
$route['kbank'] = 'topup/kbank';
$route['truemoney'] = 'topup/truemoney';
$route['promptpay'] = 'topup/promptpay';
$route['truewallet'] = 'topup/truewallet';














$route['report/stock'] = 'login/report_stock';


