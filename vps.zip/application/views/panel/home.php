<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<meta name="description" content=""/>
	<meta name="keywords" content=""/>
	<meta name="author" content=""/>	
    <title>ไฟแลบ VPN Internet บริการเช่า VPN ชั้นนำของไทย</title>
    <link rel="icon" type="image/png" href="<?= base_url('assets/img/icon.png')?>" />
	
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.6.3/css/all.css" integrity="sha384-UHRtZLI+pbxtHCWp1t77Bi1L4ZtiqrqD80Kn4Z8NTSRyMA2Fd33n5dQ8lWUE00s/" crossorigin="anonymous">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <link rel="stylesheet" href="<?= base_url('assets/index/firelab.css')?>">
	
</head>
<body translate="no">


    <!-- Load Facebook SDK for JavaScript -->


    <div class="preLoader" style="display: none;">
        <span class="spin"></span>
    </div>
    <header class="header">
        <div class="header-absoulate">
            <div class="sticky-wrapper" style="">
                <div class="sticky-wrapper" style="">
                    <div class="main-header fadeInDown animated">
                        <div class="container">
                            <div class="row align-items-center">
                                <div class="col-xl-3 col-lg-2 col-md-3 col-sm-5 col-7">
                                </div>
								
                                <div class="col-xl-7 col-lg-8 col-md-6 col-sm-3 col-2">
                                    <nav data-animate="fadeInDown" data-delay=".75" class="animated fadeInDown" style="animation-duration: 0.6s; animation-delay: 0.75s;">
                                        <div class="header-menu">
                                            <div id="menu-button"></div>
                                            <div id="menu-button"></div>
                                            <ul style="display: none;">
                                                <li>
                                                    <a href="#">หน้าแรก</a>
                                                </li>
                                            </ul>
                                        </div>
                                    </nav>
                                </div>
								
                                <div class="col-xl-2 col-lg-2 col-md-3 col-sm-4 col-3">
                                    <div class="register-button animated fadeInDown" data-animate="fadeInDown" data-delay="1" style="animation-duration: 0.6s; animation-delay: 1s;">
                                        <a class="btn btn-transparent btn-block" href="<?= base_url('') ?>signin">
                                            <i class="fas fa-key"></i> <span>เข้าสู่ระบบ</span>
                                        </a>
                                    </div>
                                </div>
								
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </header>
	
    <section class="main-banner bg-primary bg-rotate position-relative d-flex align-items-center">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-lg-6 col-md-4">
                    <div class="banner-image text-center animated fadeInUp" data-animate="fadeInUp" data-delay="1.2" style="animation-duration: 0.6s; animation-delay: 1.2s;"> <img data-rjs="2" src="assets/img/anigif.gif" alt="" data-rjs-processed="true"> </div>
                </div>
                <div class="col-lg-6 col-md-8">
                    <div class="banner-content text-white">
                        <h2 data-animate="fadeInUp" data-delay="1.4" class="animated fadeInUp" style="animation-duration: 0.6s; animation-delay: 1.4s;"><B>บริการให้เช่า VPN</B></h2>
                        <p data-animate="fadeInUp" data-delay="1.5" class="animated fadeInUp" style="animation-duration: 0.6s; animation-delay: 1.5s;">
                            <b>ไฟแลบ VPN </b>ทำหน้าที่เป็นอุโมงค์ที่มีความปลอดภัยในการใช้งาน ป้องกันจากการสอดแนม การแทรกแซงฯ ให้คุณใช้งานส่วนตัวได้อย่างราบลื่น และยังช่วยให้คุณท่องเว็บได้ โดยไม่ระบุตัวตนได้ในทุกที่ ฯ


                            <br /><b>ไฟแลบ VPN </b> ทำงานได้ในทุกอุปกรณ์ของคุณ ไม่ว่าจะเป็นเดสก์ท็อป สมาร์ทโฟน Linux หรือแท็บเล็ต เพียงติดตั้งแอป<B> ไฟแลบ VPN ผ่าน Play Store </B> และสามารถจัดการสั่งซื้อ <B>User&Pass</B> ได้ด้วยตนเองผ่านเว็บไซต์
                            รองรับการใช้งานผ่าน 3G,4G & WIFI 2.4Ghz & 5Ghz ได้ทั่วโลก !!
                        </p>
                        <ul class="list-inline animated fadeInUp" data-animate="fadeInUp" data-delay="1.6" style="animation-duration: 0.6s; animation-delay: 1.6s;">
                            <li>
                                <a class="btn btn-transparent" href="<?= base_url('') ?>signin"> <B>เริ่มต้นใช้งาน </B>
                                </a>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
            <span class="goDown">
                <i class="fas fa-arrow-down bounce"></i>
            </span>
        </div>
    </section>
	