<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>
<!DOCTYPE html>
<html lang="th">
<meta http-equiv="content-type" content="text/html;charset=UTF-8" />
<head>
    <meta charset="utf-8">
	<meta htt-equiv="X-UA-Compatible" content="IE=edge">
	<meta http-equiv="content-language" content="th" />
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	
    <title>ระบบ : จัดการสมาชิก</title>
	<meta name="description" content="เข้าสู่ระบบ - ไฟแลบ VPN Internet บริการเช่า VPN ชั้นนำของไทย">
	<meta name="keywords" content="เข้าสู่ระบบ - ไฟแลบ VPN Internet บริการเช่า VPN ชั้นนำของไทย">
	<meta name="author" content="F-VPN.ML">
	
	<meta property="fb:app_id" content="123456789">
	<meta property="og:type" content="website">
	<meta property="og:url" content="index.php">
	<meta property="og:title" content="เข้าสู่ระบบ - ไฟแลบ VPN Internet บริการเช่า VPN ชั้นนำของไทย">
	<meta property="og:description" content="เข้าสู่ระบบ - ไฟแลบ VPN Internet บริการเช่า VPN ชั้นนำของไทย">
	<meta property="og:image" content="<?= base_url('assets/img/icon.png')?>">	
	
	<meta name="twitter:title" content="เข้าสู่ระบบ - ไฟแลบ VPN Internet บริการเช่า VPN ชั้นนำของไทย">
	<meta name="twitter:description" content="เข้าสู่ระบบ - ไฟแลบ VPN Internet บริการเช่า VPN ชั้นนำของไทย">
	<meta name="twitter:image" content="<?= base_url('assets/img/icon.png')?>">
	<meta name="twitter:card" content="summary_large_image">
	
	<link rel="apple-touch-icon" sizes="180x180" href="<?= base_url('assets/img/icon.png')?>">
	<link rel="icon" type="image/png" sizes="32x32" href="<?= base_url('assets/img/icon.png')?>">
	<link rel="manifest" href="assets/login/favicon/site.html">
	<link rel="mask-icon" href="<?= base_url('assets/img/icon.png')?>" color="#5bbad5">
	<meta name="msapplication-TileColor" content="#00aba9">
	<meta name="theme-color" content="#ffffff">
    
    <link href="https://fonts.googleapis.com/css2?family=Prompt:wght@200;400;700&amp;display=swap" rel="stylesheet">
    <link rel="stylesheet" href="assets/login/bootstrap/css/bootstrap-csne.css">
    <link rel="stylesheet" href="assets/login/fontawesome/css/all.min.css">

	
	<script src="assets/login/jquery/jquery.min.js"></script>
	<script src="assets/login/jquery/popper.min.js"></script>
	<script src="assets/login/jquery/moment.min.js"></script>
	<script src="assets/login/bootstrap/js/bootstrap.min.js"></script>
	
	<link rel="stylesheet" href="assets/login/sweetalert2/dist/bootstrap-4.css">
	<script src="assets/login/sweetalert2/dist/sweetalert2.all.min.js"></script>
	<link rel="stylesheet" href="assets/login/aos/aos.min.css">
	<script src="assets/login/aos/aos.min.js"></script>
		
	<script>
	$(function(){
		AOS.init({
			once: true,
		});
	});
	</script>

</head>
<body>
<script>
Swal.fire({
	icon: 'error',
	html: 'กรุณาเข้าสู่ระบบก่อนดำเนินการต่อไป',
	toast: true,
	position: 'top-end',
	timer: 10000,
	timerProgressBar: true,
});
</script>
<header>
	<nav class="navbar navbar-expand-lg navbar-light bg-light" id="mainNav">
	  <div class="container">

		<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
		  <span class="navbar-toggler-icon"></span>
		</button>
		
		<div class="collapse navbar-collapse" id="navbarResponsive">
		
		  <ul class="navbar-nav ml-auto">
			<li class="nav-item" data-aos="fade-down" data-aos-delay="50">
				<a class="nav-link" href="<?= base_url('') ?>">หน้าแรก</a>
			</li>
			<li class="nav-item" data-aos="fade-down" data-aos-delay="200">
				<a class="nav-link" href="https://m.me/100009053160294">ติดต่อเรา</a>
			</li>
			<div class=" d-flex align-items-center" data-aos="fade-down" data-aos-delay="250"><li class="line-cut"></li></div>
			<li class="nav-item pr-0  active" data-aos="fade-down" data-aos-delay="300">
				<a class="nav-link" href="<?= base_url('') ?>signin">เข้าสู่ระบบ</a>
			</li>

		  </ul>
		</div>
	  </div>
	</nav>
	
</header>


<div class="container py-5 my-3" data-aos="fade" data-aos-delay="150">

	<div class="mb-4">
		<div class="d-flex justify-content-between">
			<div class="py-1">
				<div class="display-4 font-weight-bold">Signin</div>
				<h1>เข้าสู่ระบบบัญชี</h1>
			</div>
		</div>
	</div>
	
	<div class="my-4 row">
		<form class="col-12 col-md-8 col-xl-5 bg-light rounded-xl p-4" action="<?=base_url('signin')?>" method="post" accept-charset="utf-8">
			<input type="hidden" name="return_url" value="">
			<div class="form-group">
				<label for="email">Phone เบอร์มือถือ</label>
				<input type="number" class="form-control" id="username" name="username" placeholder="Number pohne" required maxlength="10" autofocus>
			</div>
			<div class="form-group">
				<label for="password">Password รหัสผ่าน</label>
				<input type="password" class="form-control" id="password" name="password" placeholder="Password" required minlength="1" maxlength="50">
			</div>

			<div class="form-group mt-3">
				<button type="submit" class="btn btn-lg btn-block btn-primary">เข้าสู่ระบบ</button>
				<div class="pt-1 text-center font08rem">
					<a href="forgot">ลืมรหัสผ่าน ?</a>
				</div>
			</div>
		</form>
		<div class="col-12 d-none d-lg-block col-xl-7 px-5">
			<img src="https://image.freepik.com/free-vector/man-sitting-workplace-using-vpn-virtual-private-network-cyber-security-privacy-concept_48369-26600.jpg" alt="Wallet Payment - TrueWallet, Credit Card, Internet Banking" class="img-fluid">
		</div>
	</div>
	
</div>

</body>
</html>