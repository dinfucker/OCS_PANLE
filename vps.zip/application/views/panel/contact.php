<div id="page-wrapper">

<div class="col-12 col-md-8">
			<h2>ข้อมูลการติดต่อ</h2>
			<div class="bg-light p-4 rounded-xl">
				<div class="form-group">
					<label class="font-weight-bold">เพจเฟสบุค</label>
					<div>https://f-vpn.ml/page</div>
				</div>
				<div class="form-group">
					<label class="font-weight-bold">เบอร์โทรศัพท์มือถือ</label>
					<div data-inputmask="'mask': '999-999-9999'" inputmode="text">097-026-7262</div>
				</div>
				<div class="form-group">
					<label class="font-weight-bold">ช่องทางไลน์</label>
					<div>https://f-vpn.ml/line</div>
				</div>
				<hr>
				<div class="form-group">
					<label class="font-weight-bold">กรณีฉุกเฉิน</label>
					<div><button type="button" class="btn btn-outline-dark btn-sm rounded-lg btn-changepwd"><i class="fa fa-key"></i> ติดต่อด่วนพิเศษ https://m.me/ceolnw</button></div>
				</div>				
			</div>
			
		
		</div>
		
</div>
