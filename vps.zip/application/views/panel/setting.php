<div id="page-wrapper">

<div class="col-12 col-md-8">
			<h2>ข้อมูลส่วนตัว</h2>
			<div class="bg-light p-4 rounded-xl">
				<div class="form-group">
					<label class="font-weight-bold">อีเมล์</label>
					<div>niantasart@gmail.com</div>
				</div>
				<div class="form-group">
					<label class="font-weight-bold">เบอร์โทรศัพท์มือถือ</label>
					<div data-inputmask="'mask': '999-999-9999'" inputmode="text">097-026-7262</div>
				</div>
				<div class="form-group">
					<label class="font-weight-bold">วันที่สมัครสมาชิก</label>
					<div>2020-07-12 20:29:38</div>
				</div>
				<hr>
				<div class="form-group">
					<label class="font-weight-bold">แก้ไขรหัสผ่าน</label>
					<div><button type="button" class="btn btn-outline-dark btn-sm rounded-lg btn-changepwd"><i class="fa fa-key"></i> เปลี่ยนรหัสผ่าน</button></div>
				</div>				
			</div>
			<!--
			<h2 class="mt-3">ข้อมูลผู้ใช้บัญชีสำหรับการยืนยัน</h2>
			<div class="bg-light p-4 rounded-xl">
				<div class="text-center py-3">
					<a href="https://wallet.csne.co.th/account/active" class="btn btn-outline-primary">กรุณายืนยันบัญชีก่อนใช้งานจริง</a>
				</div>
			</div>
			-->
		
		</div>
		
</div>




	<link rel="stylesheet" href="assets/login/sweetalert2/dist/bootstrap-4.css">
	<script src="assets/login/sweetalert2/dist/sweetalert2.all.min.js"></script>


<script>
$(function() {

	$(".btn-changepwd").on("click",function(){
		$(".btn-changepwd").prop('disabled',true);
		Swal.mixin({
			input: 'password',
			confirmButtonText: 'ขั้นตอนต่อไป &rarr;',
			cancelButtonText: 'ยกเลิก',
			showCancelButton: true,
			progressSteps: ['1', '2', '3'],
			inputValidator: (value) => {
			if (!value) {
				return 'กรุณากรอกรหัสผ่าน'
				}
			}
			}).queue([
				{
					title: 'รหัสผ่านปัจจุบัน',
					text: 'กรุณากรอกรหัสผ่านปัจจุบันของคุณ'
				},
				{
					title: 'รหัสผ่านใหม่',
					text: 'กรุณากรอกรหัสผ่านใหม่ที่ต้องการ'
				},
				{
					title: 'เยืนยันรหัสผ่านใหม่',
					text: 'กรุณากรอกยืนยันรหัสผ่านใหม่'
				}
			]).then((result) => {
			if (result.value) {
				$.post('/action/account/profile', {'do':'changePassword','password':result.value}, function(res) {
					if(res['result'] == true) {
						$(".btn-changepwd").prop('disabled',false);
						Swal.fire({
							icon: 'success',
							html: res['message'],
							toast: true,
							showConfirmButton: false,
							position: 'top-end',
							timer: 5000,
							timerProgressBar: true,
						});
					} else {
						$(".btn-changepwd").prop('disabled',false);
						Swal.fire({
							icon: 'error',
							html: res['message'],
							confirmButtonText: 'เนเธเนเนเธเธญเธตเธเธเธฃเธฑเนเธ',
						}).then((result) => {
							$(".btn-changepwd").trigger('click');
						});
					}
				},'json');
			} else {
				$(".btn-changepwd").prop('disabled',false);
			}
		});
	});
	
});
</script>
