<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>
<!DOCTYPE html>
<html lang="th">
<meta http-equiv="content-type" content="text/html;charset=UTF-8" />
<head>
    <meta charset="utf-8">
	<meta htt-equiv="X-UA-Compatible" content="IE=edge">
	<meta http-equiv="content-language" content="th" />
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	
    <title>ลืมรหัสผ่าน - ไฟแลบ VPN Internet บริการเช่า VPN ชั้นนำของไทย</title>
	<meta name="description" content="เข้าสู่ระบบ - ไฟแลบ VPN Internet บริการเช่า VPN ชั้นนำของไทย">
	<meta name="keywords" content="เข้าสู่ระบบ - ไฟแลบ VPN Internet บริการเช่า VPN ชั้นนำของไทย">
	<meta name="author" content="F-VPN.ML">
	
	<meta property="fb:app_id" content="123456789">
	<meta property="og:type" content="website">
	<meta property="og:url" content="index.php">
	<meta property="og:title" content="เข้าสู่ระบบ - ไฟแลบ VPN Internet บริการเช่า VPN ชั้นนำของไทย">
	<meta property="og:description" content="เข้าสู่ระบบ - ไฟแลบ VPN Internet บริการเช่า VPN ชั้นนำของไทย">
	<meta property="og:image" content="<?= base_url('assets/img/icon.png')?>">	
	
	<meta name="twitter:title" content="เข้าสู่ระบบ - ไฟแลบ VPN Internet บริการเช่า VPN ชั้นนำของไทย">
	<meta name="twitter:description" content="เข้าสู่ระบบ - ไฟแลบ VPN Internet บริการเช่า VPN ชั้นนำของไทย">
	<meta name="twitter:image" content="<?= base_url('assets/img/icon.png')?>">
	<meta name="twitter:card" content="summary_large_image">
	
	<link rel="apple-touch-icon" sizes="180x180" href="<?= base_url('assets/img/icon.png')?>">
	<link rel="icon" type="image/png" sizes="32x32" href="<?= base_url('assets/img/icon.png')?>">
	<link rel="manifest" href="assets/login/favicon/site.html">
	<link rel="mask-icon" href="<?= base_url('assets/img/icon.png')?>" color="#5bbad5">
	<meta name="msapplication-TileColor" content="#00aba9">
	<meta name="theme-color" content="#ffffff">
    
    <link href="https://fonts.googleapis.com/css2?family=Prompt:wght@200;400;700&amp;display=swap" rel="stylesheet">
    <link rel="stylesheet" href="assets/login/bootstrap/css/bootstrap-csne.css">
    <link rel="stylesheet" href="assets/login/fontawesome/css/all.min.css">

	
	<script src="assets/login/jquery/jquery.min.js"></script>
	<script src="assets/login/jquery/popper.min.js"></script>
	<script src="assets/login/jquery/moment.min.js"></script>
	<script src="assets/login/bootstrap/js/bootstrap.min.js"></script>
	
	<link rel="stylesheet" href="assets/login/sweetalert2/dist/bootstrap-4.css">
	<script src="assets/login/sweetalert2/dist/sweetalert2.all.min.js"></script>
	<link rel="stylesheet" href="assets/login/aos/aos.min.css">
	<script src="assets/login/aos/aos.min.js"></script>
		
	<script>
	$(function(){
		AOS.init({
			once: true,
		});
	});
	</script>

</head>
<body>
<header>
	<nav class="navbar navbar-expand-lg navbar-light bg-light" id="mainNav">
	  <div class="container">

		<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
		  <span class="navbar-toggler-icon"></span>
		</button>
		
		<div class="collapse navbar-collapse" id="navbarResponsive">
		
		  <ul class="navbar-nav ml-auto">
			<li class="nav-item" data-aos="fade-down" data-aos-delay="50">
				<a class="nav-link" href="<?= base_url('') ?>home">หน้าแรก</a>
			</li>
			<li class="nav-item" data-aos="fade-down" data-aos-delay="150">
				<a class="nav-link" href="<?= base_url('') ?>howto">แอปพลิเคชัน</a>
			</li>
			<li class="nav-item" data-aos="fade-down" data-aos-delay="200">
				<a class="nav-link" href="https://www.fb.com/%E0%B9%84%E0%B8%9F%E0%B9%81%E0%B8%A5%E0%B8%9A-vpn-116555376848959">ติดต่อเรา</a>
			</li>
			<div class=" d-flex align-items-center" data-aos="fade-down" data-aos-delay="250"><li class="line-cut"></li></div>
			<li class="nav-item pr-0  active" data-aos="fade-down" data-aos-delay="300">
				<a class="nav-link" href="<?= base_url('') ?>signin">เข้าสู่ระบบ</a>
			</li>
			<li class="nav-item pl-3" data-aos="fade-down" data-aos-delay="350">
				<a class="btn btn-outline-primary" href="<?= base_url('') ?>signup">สมัครบัญชี</a>
			</li>	

		  </ul>
		</div>
	  </div>
	</nav>
	
</header>


<div class="container py-5 my-3" data-aos="fade" data-aos-delay="150">
	<div class="mb-4">
		<div class="text-center">
			<div class="py-1">
				<div class="display-4 font-weight-bold">Forgot Password</div>
				<h1>ระบบลืมรหัสผ่าน</h1>
			</div>
		</div>
	</div>
	<div class="my-4 row">
		<form id="forgotForm" class="col-12 col-md-8 col-xl-5 mx-auto bg-light rounded-xl p-4">
			<input type="hidden" name="do" value="enterEmail">
			<div class="form-group">
				<label for="email">Email อีเมล์</label>
				<input type="email" class="form-control" id="email" name="email" placeholder="Email address" required maxlength="100" autofocus>
			</div>

			<div class="form-group mt-3">
				<button type="submit" class="btn btn-lg btn-block btn-primary">ยืนยัน</button>
			</div>
		</form>
		
		<form id="confirmForm" class="col-12 col-md-8 col-xl-5 mx-auto bg-light rounded-xl p-4" style="display:none;">
			<input type="hidden" name="do" value="enterCode">
			<input type="hidden" name="email" value="">
			<div class="form-group text-center">
				<label for="code">Access Code</label>
				<input type="tel" class="form-control form-control-lg text-center" id="code" name="code" placeholder="Enter Code" required maxlength="6">
			</div>
			<div class="form-group mt-3">
				<button type="submit" class="btn btn-lg btn-block btn-primary">ยืนยัน Access Code</button>
			</div>
		</form>
		
		
		<form id="passwordForm" class="col-12 col-md-8 col-xl-5 mx-auto bg-light rounded-xl p-4" style="display:none;">
			<input type="hidden" name="do" value="changePassword">
			<input type="hidden" name="access" value="">
			<input type="hidden" name="email" value="">
			<div class="form-group">
				<label for="password">New Password</label>
				<input type="password" class="form-control" id="password" name="password" placeholder="รหัสผ่านใหม่" required minlength="8" maxlength="50">
			</div>
			<div class="form-group">
				<label for="password2">Password confirm</label>
				<input type="password" class="form-control" id="password2" name="password2" placeholder="ยืนยันรหัสผ่านอีกครั้ง" required minlength="8" maxlength="50">
			</div>
			<div class="form-group mt-3">
				<button type="submit" class="btn btn-lg btn-block btn-primary">ยืนยันการเปลี่ยนรหัสผ่าน</button>
			</div>
		</form>

	</div>
</div>
</body>
</html>