<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

</div>
</div>
<footer id="site-footer" role="contentinfo">
</footer>
<script type="text/javascript">
$(document).ready(function () {
$('#sidebarCollapse').on('click', function () {
$('#sidebar').toggleClass('aside-toggled');
});
});
</script>

<script type="text/javascript">
$(document).ready(function () {
$('#sidebarCollapse').on('click', function () {
$('#sidebuy').toggleClass('active');
});
});
</script>
	

<style>
    .glyphicon-spin-jcs {
        -webkit-animation: spin 1000ms infinite linear;
        animation: spin 1000ms infinite linear;
    }

    @-webkit-keyframes spin {
        0% {
            -webkit-transform: rotate(0deg);
            transform: rotate(0deg);
        }

        100% {
            -webkit-transform: rotate(359deg);
            transform: rotate(359deg);
        }
    }

    @keyframes spin {
        0% {
            -webkit-transform: rotate(0deg);
            transform: rotate(0deg);
        }

        100% {
            -webkit-transform: rotate(359deg);
            transform: rotate(359deg);
        }
    }
</style>


<script>
    <!-- js 
    -->
    $(function
    ()
    {
    $('#fornesia').DataTable({
    "paging":
    true,
    "lengthChange":
    false,
    "searching":
    false,
    "ordering":
    true,
    "info":
    true,
    "autoWidth":
    false
    });
    });
<!-- js -->
</script>
<!-- DataTables JavaScript -->
<script type="text/javascript" src="https://cdn.datatables.net/v/dt/dt-1.10.16/af-2.2.2/b-1.5.1/b-colvis-1.5.1/fc-3.2.4/fh-3.1.3/r-2.2.1/sc-1.4.4/sl-1.2.5/datatables.min.js"></script>
<script type="text/javascript" src="https://cdn.datatables.net/v/bs4/jszip-2.5.0/dt-1.10.16/af-2.2.2/b-1.5.1/b-colvis-1.5.1/b-flash-1.5.1/b-html5-1.5.1/b-print-1.5.1/cr-1.4.1/fc-3.2.4/fh-3.1.3/kt-2.3.2/r-2.2.1/rg-1.0.2/rr-1.2.3/sc-1.4.4/sl-1.2.5/datatables.min.js"></script>
<!-- Tables - Use for reference -->
<div class="drag-target" style="left: 0px; touch-action: pan-y; user-select: none; -webkit-user-drag: none; -webkit-tap-highlight-color: rgba(0, 0, 0, 0);"></div>
</body>
</html>



<script>
	(function($) {
		function processForm(e) {
			$.ajax({
				url: '',
				dataType: 'text',
				type: 'post',
				contentType: 'application/x-www-form-urlencoded',
				data: $(this).serialize(),
				success: function(data, textStatus, jQxhr) {
					$('#sm-form form-show').html(data);
				},
				error: function(jqXhr, textStatus, errorThrown) {
					console.log(errorThrown);
				}
			});
			e.preventDefault();
		}
		$('#my-form').submit(processForm);
	})(jQuery);

	function blui() {
		$.blockUI({
			message: "<i class='fa fa-spinner fa-pulse orange' style='font-size:300%'></i><br>กำลังตรวจสอบ...",
			css: {
				border: 'none',
				backgroundColor: '#00000000',
				'-webkit-border-radius': '10px',
				'-moz-border-radius': '10px',
				//opacity: .5, 
				color: '#fff'
			}
		});
	}
</script>


</body>
</html>