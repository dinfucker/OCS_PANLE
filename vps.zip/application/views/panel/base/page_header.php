<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>
<?php if (isset($_SESSION['username']) && $_SESSION['logged_in'] === true): ?>
<!DOCTYPE html>
<html lang="th">
<head>
<meta charset="utf-8"/>
<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/v/bs4/jszip-2.5.0/dt-1.10.16/af-2.2.2/b-1.5.1/b-colvis-1.5.1/b-flash-1.5.1/b-html5-1.5.1/b-print-1.5.1/cr-1.4.1/fc-3.2.4/fh-3.1.3/kt-2.3.2/r-2.2.1/rg-1.0.2/rr-1.2.3/sc-1.4.4/sl-1.2.5/datatables.min.css">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="description" content=""/>
<meta name="keywords" content=""/>
<meta name="author" content=""/>
<title>ระบบจัดการสมาชิก</title>
<link rel="shortcut icon" href="<?= base_url('assets/img/newlogo2.jpg')?>">
<link rel="icon" type="images/png" href="<?= base_url('assets/img/newlogo2.jpg')?>" /> 
<!-- core CSS -->
<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
<link href="<?= base_url('assets/member/firelab.css')?>" rel="stylesheet">
<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.6.3/css/all.css" integrity="sha384-UHRtZLI+pbxtHCWp1t77Bi1L4ZtiqrqD80Kn4Z8NTSRyMA2Fd33n5dQ8lWUE00s/" crossorigin="anonymous">
<link href="https://fonts.googleapis.com/css?family=Mitr&display=swap" rel="stylesheet">	
</head>






<body id="sidebar" class="layout-boxed">
<?php if (isset($_SESSION['active']['head'])) { ?>
<div data-v-6aea5eb8="" class="wrapper position-fixed"> 
<?php }else{ ?>
<div data-v-6aea5eb8="" class="wrapper">
<?php
} 
unset($_SESSION['active']['head']); ?>


<!-- header open -->
<header data-v-79572de2="" data-v-6aea5eb8="" class="topnavbar-wrapper">

	<nav data-v-79572de2="" class="navbar topnavbar">
	  <div data-v-79572de2="" class="navbar-header">
		<?php foreach ($this->user_model->view_asset() as $row): ?>
        <?php if (empty($row['rekening'])):?>
        <?php if (empty($row['bank'])):?>
        <?php if (empty($row['pemilik'])):?>    

		
		<a data-v-79572de2="" class="navbar-brand text-white">	<img src="/assets/img/logo.jpg" width="40" height="40" class="d-inline-block align-left" alt=""></a> 
		<?php endif;?>
        <?php endif;?>
        <?php endif;?>
        <?php endforeach; ?>            
		</div> 

<ul data-v-79572de2="" class="navbar-nav mr-auto flex-row">
	<li data-v-79572de2="" class="nav-item">

		<a data-v-79572de2="" class="nav-link sidebar-toggle d-md-none">



			<em data-v-79572de2="" id="sidebarCollapse" class="fas fa-bars" style="font-size:18px"></em>
		</a>
	</li>
</ul>




	</nav>
</header>
<!-- header close -->                   
        
		
		
		              
<!-- aside close --> 
<aside data-v-6aea5eb8="" class="aside-container">
<div class="aside-inner"><nav data-sidebar-anyclick-close="" class="sidebar"><ul class="sidebar-nav">
<li class="nav-heading"><span>
เมนู</b></span>
</li>

<?php if (!$_SESSION['is_confirmed']): ?>

	<li class="router-link-exact-active <?php if (isset($_SESSION['active']['dashboard'])) { echo $_SESSION['active']['dashboard']; } unset($_SESSION['active']['dashboard']); ?>">
	<a href="<?= base_url('login/log_index')?>">
	<em class="fas fa-store-alt"></em> 
	<span>หน้าแรก</span></a>
	</li>

	
	<li class="router-link-exact-active <?php if (isset($_SESSION['active']['servers'])) { echo $_SESSION['active']['servers']; } unset($_SESSION['active']['servers']); ?>">
	<a href="<?= base_url('login/report_5')?>">
	<em class="fa fa-fw fa-random"></em>
	<span>ชำระทุกวันที่ 05</span></a>
	</li>

	<li class="router-link-exact-active <?php if (isset($_SESSION['active']['servers'])) { echo $_SESSION['active']['servers']; } unset($_SESSION['active']['servers']); ?>">
	<a href="<?= base_url('login/report_10')?>">
	<em class="fa fa-fw fa-random"></em>
	<span>ชำระทุกวันที่ 10</span></a>
	</li>

	<li class="router-link-exact-active <?php if (isset($_SESSION['active']['servers'])) { echo $_SESSION['active']['servers']; } unset($_SESSION['active']['servers']); ?>">
	<a href="<?= base_url('login/report_15')?>">
	<em class="fa fa-fw fa-random"></em>
	<span>ชำระทุกวันที่ 15</span></a>
	</li>

	<li class="router-link-exact-active <?php if (isset($_SESSION['active']['servers'])) { echo $_SESSION['active']['servers']; } unset($_SESSION['active']['servers']); ?>">
	<a href="<?= base_url('login/report_20')?>">
	<em class="fa fa-fw fa-random"></em>
	<span>ชำระทุกวันที่ 20</span></a>
	</li>

	<li class="router-link-exact-active <?php if (isset($_SESSION['active']['servers'])) { echo $_SESSION['active']['servers']; } unset($_SESSION['active']['servers']); ?>">
	<a href="<?= base_url('login/report_25')?>">
	<em class="fa fa-fw fa-random"></em>
	<span>ชำระทุกวันที่ 25</span></a>
	</li>
				

<?php else: ?>	


	
<?php endif; ?>


 <hr class="m-0"> <!----> <!----> 
 <br> 


<li class="router-link-exact-active"><a href="<?= base_url('signout')?>"><em class="fas fa-sign-out-alt"></em>
<span>ออกจากระบบ</span></a></li> 


</ul>
</nav>
</div>
</aside>
<!-- aside close --> 

<section data-v-6aea5eb8="" class="section-container"><div data-v-6aea5eb8="" class="content-wrapper">


<!-- /.sidebar -->
<?php endif; ?>
