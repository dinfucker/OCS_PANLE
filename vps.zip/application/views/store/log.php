<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>
      <div class="main-container">
		<div class="breadcrumb-holder">
			<h1 class="main-title float-left">ประวัติการชําระเงิน</h1>

			<div class="clearfix"></div>
		</div>
		<hr>

				<?php  if (isset($message)) { ?>
 				<script type="text/javascript">
				swal(
				'เชื่อมต่อสำเร็จ',
				'<?php echo $message;?>',
				'success'
				);
				</script>
				<?php } ?>		
				<?php
				ini_set('display_errors', 1);
				error_reporting(~0);
				
				function createJSON()
				{
				require APPPATH . '/config/database.php';
				$serverName = "localhost";
				$userName = $db['default']['username']; 
				$userPassword = $db['default']['password']; 
				$dbName = $db['default']['database']; 

				
				$conn = mysqli_connect($serverName,$userName,$userPassword,$dbName);
				$sql = "SELECT * FROM log_payments";
				$query = mysqli_query($conn,$sql);
				if (!$query) {
				printf("Error: %s\n", $conn->error);
				exit();
				}
				$resultArray = array();
				while($result = mysqli_fetch_array($query,MYSQLI_ASSOC))
				{
				array_push($resultArray,$result);
				}
				mysqli_close($conn);
				
				return json_encode($resultArray);
				}
				
				// Read JSON Decode
				$jsonCode = createJSON();
				$jsonDecode = json_decode($jsonCode, true);
				?>							
        <div class="main-content" autoscroll="true" bs-affix-target="" init-ripples="" style="">
		  <section class="tables-data">
            <div class="card">
              <div>
                <div class="datatables">
				
				<table width="100%" class="table table-full table-full-small" cellspacing="0" id="dataTables-example">
             
                  <thead>
                            <tr>
								<th>id</th>
								<th>ชื่อ :</th>
								<th>เบอร์ : </th>
								<th>แพ็คเกจ : </th>
								<th>ชำระเงิน : </th>
								<th>วันที่ : </th>
                            </tr>
                  </thead>
                  <tbody>
                            <?php
                    if(!empty($jsonDecode))
                    {
						$i = 1;  
                        foreach ($jsonDecode as $result)
                        {
		
							
                    ?>
									<tr>
										<td><?php echo $i++;?></td>
										<td><?php echo $result['ref_fullname'];?></td>
										<td><?php echo $result['ref_phone']; ?></td>
										<td><?php echo $result['ref_detial']; ?></td>
										<td><?php echo $result['ref_amount']; ?></td>
										<td><?php echo $result['ref_time']; ?></td>
									</tr>
                                <?php
						}	
                    }
                    ?>
                  </tbody>
                        </table>
              </div>
                    </div>
                    <!-- /.box-body -->
                </div>
                <!-- /.box -->
            </div>
        </div>
    </section>
</div>

<div class="progress-bar" style="width: 100%; height: 2px;"></div>


<script src="https://code.jquery.com/jquery-2.2.3.min.js"></script>
<script>
    $(document).ready(function () {
        $('#dataTables-example').DataTable({
            //Dom Gösterim şekli B-> buttonlar l-> lengthMenu f-> filtre vs.
            dom: "<'row'<'col-sm-6'l><'col-sm-6'f>>" +
                "<'row'<'col-sm-12'tr>>" +
                "<'row'<'col-sm-9'i><'col-sm-3'B>>" +
                "<'row'<'col-sm-7 col-centered'p>>",
            lengthMenu: [
                [10, 15, 25, 50, -1],
                [10, 15, 25, 50, "All"]
            ],

            //Dil
            language: {
                select: {
                    rows: "%d satır seçildi."
                },

                url: "https://raw.githubusercontent.com/lnwseed/z_json/master/stylesheets.json"
            },
            buttons: [{
                    extend: "print",
                    text: "Print",
                    exportOptions: {
                        orthogonal: 'export',
                        columns: ':visible'
                    },
                },
                {
                    extend: 'excelHtml5',
                    exportOptions: {
                        orthogonal: 'export'
                    },
                    text: "Excel",
                },
                {
                    extend: 'pdfHtml5',
                    exportOptions: {
                        orthogonal: 'export'
                    },
                    text: "PDF",
                }
            ],
            "order": [],
            responsive: true
        });
    });
</script>