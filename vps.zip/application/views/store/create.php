<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>
                <?php if (validation_errors()) : ?>
                    <div class="alert alert-danger"><?= validation_errors() ?></div>
                <?php endif; ?>
                <?php if (isset($error)) : ?>
					<div class="col-md-12">
						<div class="alert alert-danger" role="alert"><?= $error ?></div>
					</div>
				<?php endif; ?>
<div id="page-wrapper">

    <div class="col-12 col-md-8">
        <div class="bg-light p-4 rounded-xl shadow">
			<form  action="<?=base_url('login/addmember')?>" method="post" accept-charset="utf-8">
                <div class="form-group">
                    <label for="">USER</label>
                    <input name="username" type="text" class="form-control" id="username" value="<?php if (isset($account)){ echo $account->username; }?>" required="">
                    <div class="invalid-feedback">
                        กรุณากรอก user
                    </div>
                </div>
                <div class="form-group">
                    <label for="">ชื่อ</label>
                    <input type="text" name="first_name" id="first_name" class="form-control" value="<?php if (isset($account)){ echo $account->first_name; }?>" required="">
                    <div class="invalid-feedback">
                        กรุณากรอกชื่อ
                    </div>
                </div>
                <div class="form-group">
                    <label for="">นามสกุล</label>
                    <input type="text" name="last_name" id="last_name" class="form-control" value="<?php if (isset($account)){ echo $account->last_name; }?>" required="">
                    <div class="invalid-feedback">
                        กรุณากรอกนามสกุล
                    </div>
                </div>
                <div class="form-group">
                    <label for="">เบอรโทร</label>
                    <input type="text" class="form-control" pattern="^0([8|9|6])([0-9]{8}$)" name="phone" id="phone" autocomplete="off" value="<?php if (isset($account)){ echo $account->phone; }?>"  required="">
                    <div class="invalid-feedback">
                        กรุณากรอกเบอร์มือถือตัวเลข 10 หลัก
                    </div>
                </div>
                <div class="form-group">
                    <label for="">ที่อยู่</label>
                    <input type="text" name="address" id="" class="form-control" value="<?php if (isset($account)){ echo $account->address; }?>" required="">
                    <div class="invalid-feedback">
                        กรุณากรอกที่อยู่
                    </div>
					<hr />
			 <div class="form-group">		
				<label for="ref_group">กลุ่มลูกค้า:</label>
				<select id="ref_group" name="ref_group">
				  <option value="5">ชำระทุกวันที่ 5</option>
				  <option value="10">ชำระทุกวันที่ 10</option>
				  <option value="15">ชำระทุกวันที่ 15</option>
				  <option value="20">ชำระทุกวันที่ 20</option>
				  <option value="25">ชำระทุกวันที่ 25</option>
				</select>	
			</div>		

					<hr />
			 <div class="form-group">		
				<label for="status">สถานะ:</label>
				<select id="status" name="status">
				  <option value="ปกติ">ปกติ</option>
				  <option value="ค้างชำระ">ค้างชำระ</option>
				</select>	
			</div>				
					
					<hr />
                    <div class="form-group row">
                        <legend class="col-form-label col-sm-1 pt-0 text-right">แพ็คเกจเน็ต</legend>
                        <div class="col">
                            <div class="form-check">
                                <input name="packge" type="radio" class="form-check-input" id="packge" value="390บ. 100/100mbs" <?php if (isset($account)){ if($account->packge=='390บ. 100/100mbs') {echo 'checked="checked"';}}?> required="">
                                <label class="form-check-label" for="radio_gender_1">
                                    390 บาท
                                </label>
                            </div>
                            <div class="form-check">
                                <input class="form-check-input" type="radio" name="packge" id="packge" value="490บ. 200/200mbs" <?php if (isset($account)){ if($account->packge=='490บ. 200/200mbs') {echo 'checked="checked"';}}?> required="">
                                <label class="form-check-label" for="radio_gender_2">
                                    490 บาท
                                </label>
                            </div>
                            <div class="form-check">
                                <input class="form-check-input" type="radio" name="packge" id="packge" value="590บ. 300/300mbs" <?php if (isset($account)){ if($account->packge=='590บ. 300/300mbs') {echo 'checked="checked"';}}?> required="">
                                <label class="form-check-label" for="radio_gender_2">
                                    590 บาท
                                </label>
                                <div class="invalid-feedback">
                                    กรุณาเลือกแพ็คเกจเน็ต
                                </div>
                            </div>
                        </div>
                    </div>
					<hr />
                    <div class="form-group row">
                        <legend class="col-form-label col-sm-1 pt-0 text-right">สัญญาเช่า</legend>
                        <div class="col">
                            <div class="form-check">
                                <input class="form-check-input" type="radio" name="contract" id="contract" value="1ปี" <?php if (isset($account)){ if($account->contract=='1ปี') {echo 'checked="checked"';}}?> required="">
                                <label class="form-check-label" for="radio_gender_1">
                                    1ปี
                                </label>
                            </div>
                            <div class="form-check">
                                <input class="form-check-input" type="radio" name="contract" id="contract" value="2ปี" <?php if (isset($account)){ if($account->contract=='2ปี') {echo 'checked="checked"';}}?> required="">
                                <label class="form-check-label" for="radio_gender_2">
                                    2ปี
                                </label>
                                <div class="invalid-feedback">
                                    กรุณาเลือกสัญญาเช่า
                                </div>
                            </div>
                        </div>
                    </div>
                    <hr />
                    <input type="submit" value="บันทึก" class="btn btn-success">
                    <input type="reset" value="ล้างขอมูล" class="btn btn-danger">
                    <a href="index.php" class="btn btn-primary">หน้าแรก</a>

                    <script src="https://unpkg.com/jquery@3.3.1/dist/jquery.min.js"></script>
                    <script src="https://unpkg.com/bootstrap@4.1.0/dist/js/bootstrap.min.js"></script>
                    <script type="text/javascript">
                        $(function() {
                            $("#myform1").on("submit", function() {
                                var form = $(this)[0];
                                if (form.checkValidity() === false) {
                                    event.preventDefault();
                                    event.stopPropagation();
                                }
                                form.classList.add('was-validated');
                            });
                        });
                    </script>
                </div>
            </form>
        </div>


    </div>

</div>