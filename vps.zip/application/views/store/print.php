<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta http-equiv="X-UA-Compatible" content="ie=edge">
        <link rel="stylesheet" href="<?= base_url('assets/print/')?>style.css">
        <title>Receipt example</title>
        <style type="text/css">
<!--
.style3 {font-size: 18px}
.style5 {font-size: 16px}
.style6 {font-size: 18}
-->
        </style>
</head>
    <body>
        <div class="ticket">
            <p class="centered"><span class="style3">ใบเสร็จรับเงิน</span>              <br>
                <span class="style5"><span class="style3">แซมอิเล็คทรอนิกส์</span>                <br>
                <span class="style3">สาขา สำนักงานใหญ่</span></span></p>
            <span>
			<span class="style6">Line ID : sam0857707602
			<br>
			E-Mail : samprasat@gmail.com			</span>
			<hr>
			<span class="style6">
			<b>ผู้ขาย</b> sam
			<br>
			<b>ลูกค้า</b> <?= $print_bill['first_name'] .' '.  $print_bill['last_name'] ?> <?= substr($print_bill['packge'], 0 ,3) ?> บาท เริ่ม วันที่ 10 พ.ค. 63-65			</span>
			<hr>
			<span class="style6"><b>รวม:</b> 1 <b>รายการ</b> (1 ชิ้น)
			<br>
			<b>รวม</b> <?= substr($print_bill['packge'], 0 ,3) ?>
			<br>
			<b>รับเงิน</b> <?= substr($print_bill['packge'], 0 ,3) ?> </span>
			<hr>
			<span class="style6">
			<b>วันที่</b> <?= date('d-m-Y H:i')?> </span><br>
			<br>
		  </span>    </div>
        <button id="btnPrint" class="hidden-print">Print</button>
        <script src="<?= base_url('assets/print/')?>script.js"></script>
    </body>
</html>