<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>
      <div class="main-container">
		<div class="breadcrumb-holder">
			<h1 class="main-title float-left">รายชื่อลูกค้ากลุ่มที่ 2</h1>
			<ol class="float-right">
				<a href="addmember" class="btn btn-info">เพิ่มลูกค้า</a>
			</ol>
			<div class="clearfix"></div>
		</div>
		<hr>

				<?php  if (isset($message)) { ?>
 				<script type="text/javascript">
				swal(
				'เชื่อมต่อสำเร็จ',
				'<?php echo $message;?>',
				'success'
				);
				</script>
				<?php } ?>		
				<?php
				ini_set('display_errors', 1);
				error_reporting(~0);
				
				function createJSON()
				{
				require APPPATH . '/config/database.php';
				$serverName = "localhost";
				$userName = $db['default']['username']; 
				$userPassword = $db['default']['password']; 
				$dbName = $db['default']['database']; 

				
				$conn = mysqli_connect($serverName,$userName,$userPassword,$dbName);
				$sql = "SELECT * FROM members";
				$query = mysqli_query($conn,$sql);
				if (!$query) {
				printf("Error: %s\n", $conn->error);
				exit();
				}
				$resultArray = array();
				while($result = mysqli_fetch_array($query,MYSQLI_ASSOC))
				{
				array_push($resultArray,$result);
				}
				mysqli_close($conn);
				
				return json_encode($resultArray);
				}
				
				// Read JSON Decode
				$jsonCode = createJSON();
				$jsonDecode = json_decode($jsonCode, true);
				?>							
        <div class="main-content" autoscroll="true" bs-affix-target="" init-ripples="" style="">
		  <section class="tables-data">
            <div class="card">
              <div>
                <div class="datatables">
				
				<table width="100%" class="table table-full table-full-small" cellspacing="0" id="dataTables-example">
             
                  <thead>
                            <tr>
								<th>id</th>
								<th>User : </th>
								<th>ชื่อ :</th>
								<th>นามสกุล :</th>
								<th>เบอร์ : </th>
								<th>ที่อยู่ : </th>
								<th>แพ็คเกจ : </th>
								<th>สัญญาเช่า : </th>
								<th>สถานะ : </th>
								<th>แก้ไข : </th>
								<th>ลบ : </th>
								
								
                            </tr>
                  </thead>
                  <tbody>
                            <?php
                    if(!empty($jsonDecode))
                    {
						$i = 1;  
                        foreach ($jsonDecode as $result)
                        {
						if($result['ref_group']=='10'){
							
                    ?>
									<tr>
										<td><?php echo $i++;?></td>
										<td>
										<?php if($result['status']=='ค้างชำระ'){ ?>
										<img src="https://media1.tenor.com/images/0d6ef585fe2df3b13d402111a2c14991/tenor.gif?itemid=8912247" width="16" height="16" class="d-inline-block align-top" alt="" loading="lazy">
										<?php } ?> 
										<?php echo $result['username'];?>
										</td>
										<td><?php echo $result['first_name'];?></td>
										<td><?php echo $result['last_name']; ?></td>
										<td><?php echo $result['phone']; ?></td>
										<td><?php echo $result['address']; ?></td>
										<td><?php echo $result['packge']; ?></td>
										<td><?php echo $result['contract']; ?></td>
										<td>
										<?php if($result['status']=='ปกติ'){ ?>
										<span class="badge badge-pill badge-secondary"> <?php echo $result['status']; ?> </span>
										<?php }else{ ?>
										<span class="badge badge-pill badge-danger"> <?php echo $result['status']; ?> </span>
										<?php } ?>
										</td>
										<td><a href="<?= base_url('/')?>login/editmember/<?php echo $result['id'];?>" class="badge badge-pill btn-info" onclick="return confirm('คุณแน่ใจแล้วใช้ไหมว่าจะแก้ไขบัญชี <?php echo $result['username'];?> นี้ !!')"> แก้ </a></td>
										<td><a href="<?= base_url('/')?>login/delmember/<?php echo $result['id'];?>" class="badge badge-pill btn-warning" onclick="return confirm('คุณแน่ใจแล้วใช้ไหม ว่าจะลบชื่อผู้ใช้นี้ !!')"> ลบ</a></td>
									</tr>
                                <?php
						}	
                        }	
                    }
                    ?>
                  </tbody>
                        </table>
              </div>
                    </div>
                    <!-- /.box-body -->
                </div>
                <!-- /.box -->
            </div>
        </div>
    </section>
</div>

<div class="progress-bar" style="width: 100%; height: 2px;"></div>


<script src="https://code.jquery.com/jquery-2.2.3.min.js"></script>
<script>
    $(document).ready(function () {
        $('#dataTables-example').DataTable({
            //Dom Gösterim şekli B-> buttonlar l-> lengthMenu f-> filtre vs.
            dom: "<'row'<'col-sm-6'l><'col-sm-6'f>>" +
                "<'row'<'col-sm-12'tr>>" +
                "<'row'<'col-sm-9'i><'col-sm-3'B>>" +
                "<'row'<'col-sm-7 col-centered'p>>",
            lengthMenu: [
                [10, 15, 25, 50, -1],
                [10, 15, 25, 50, "All"]
            ],

            //Dil
            language: {
                select: {
                    rows: "%d satır seçildi."
                },

                url: "https://raw.githubusercontent.com/lnwseed/z_json/master/stylesheets.json"
            },
            buttons: [{
                    extend: "print",
                    text: "Print",
                    exportOptions: {
                        orthogonal: 'export',
                        columns: ':visible'
                    },
                },
                {
                    extend: 'excelHtml5',
                    exportOptions: {
                        orthogonal: 'export'
                    },
                    text: "Excel",
                },
                {
                    extend: 'pdfHtml5',
                    exportOptions: {
                        orthogonal: 'export'
                    },
                    text: "PDF",
                }
            ],
            "order": [],
            responsive: true
        });
    });
</script>