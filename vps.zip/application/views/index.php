<div class="container">
	<?php if(isset($message)) echo $message; ?>
	<h1>ยินดีต้อนรับเข้าสู่เว็บไซต์</h1>
	<?php for($i=0;$i<1;$i++): ?>
	<p>ตกแต่งเว็บไซต์ของคุณ</p> 
	<?php endfor; ?>
	
	
	
</div>