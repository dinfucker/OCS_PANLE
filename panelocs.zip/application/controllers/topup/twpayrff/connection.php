<?php
/*
* TWPAY.CO Backend API Reciever
* VERSION: 1.0
* Author: TWPAY.CO, Mellowz
*/

include "libs/FluentPDO/FluentPDO.php";

$servername = "localhost";
$username = "root";
$password = "dinfucker";
$dbname = "LTE";

$conStr = 'mysql:host='.$servername.';port=3306;dbname='.$dbname.';charset=UTF8;'; // mysql
//$conStr = 'sqlsrv:Server='.$servername.';Database='.$dbname; // sqlsrv

$pdo = new PDO($conStr, $username, $password);
$DB = new FluentPDO($pdo);
?>
