﻿<?php if (!defined('BASEPATH')) exit('No direct script access allowed'); ?>

<div class="content-wrapper">
   <section class="content-header">
<marquee behavior="alternate"><marquee width="220"><font size="5">♕ยินดีต้อนรับสู่ LIFESTYLE VPN♕</font></marquee></marquee>
    

      <ol class="breadcrumb">
        <li><a href="main"><i class="fa fa-home"></i> หน้าหลัก</a></li>
        <li class="active">กิจกรรมและประกาศ</li>
      </ol>
  </section>
  <section class="content">
<div class="row">
<div class="col-md-12">
<div class="nav-tabs-custom">
<ul class="nav nav-tabs pull-left">
<li class="animated infinite tada active"><a href="#tab_1-1" data-toggle="tab">ประกาศ!!</a></li>
<li class="animated infinite rubberBand"><a href="#tab_2-2" data-toggle="tab">รายละเอียดการใช้</a></li>
<li><span><iframe src="https://free.timeanddate.com/clock/i5yocovd/n28/tlth39/fn6/fs16/ftb/th1" frameborder="0" width="70" height="35"></iframe></span></li>
<li class="pull-left header"><i class="fa fa-th"></i> กิจกรรมและประกาศต่างๆ</li></ul>

<div class="tab-content"> 
<div class="tab-pane active" id="tab_1-1"><br><br><br>
<!--span style="font-size: 25px;" class="badge bg-maroon">ประกาศ!!</span>
<!--h3><b>วันนี้เติมเงินตั้งแต่เวลา<b><font color="red"> 12:00-21:00 </font></b>เอาไปเลยสองเท่า <b><font color="red">X2</font></b> เติมน้อยได้น้อยเติมมากได้มาก ขอบคุณที่มาอุดหนุนน่ะครับ </b></h3-->
<center><h4><b>เซิฟแนะนำ เน้นเกมส์  Youtube TH-VIP รับรองลื่นๆ รับประกัน (เซิฟจาก IDC น่ะครับ)</b></h4>
<!--h4><b>(เปิดทดลองใช้ฟรีแล้ว ก็อย่าใช้แต่ของฟรีล่ะ อย่าลืมอุดหนุนกันน่ะครับ 555)<h4><b!-->
<!----------------------แอพ openVPN-------------------------->
<span style="font-size: 17px;" class="badge bg-purple">แอพและโปรแกรม openVPN</span><br>
<p><b>หากใครที่อัพเดทแอพ OpenVPN Connect &nbsp;
</b><img class="img-circle" src="<?php echo  base_url('asset/img/user1.png') ?>"width="31" height="31"><br>
แล้วใช้ไม่ได้เชื่อมต่อแล้ว error..<br>
ให้โหลดแอพกลับมาเวอร์ชั่นเดิมน่ะครับ..<br>
<b><font color="red">โหลดตรงนี้ได้เลย.. </font></b><br>
<b>แอพ Android</b><a href="/web/apk/openvpn-std.apk"> เวอร์ชั้นเดิม.. </a> <a href="/web/apk/openvpn-mod.apk"> เวอร์ชั้นโม.. </a><br>
<b>โปรแกรม PC</b><a href="/web/exe/openvpn-pc.exe"> OpenVPN.. </a> <a href="/web/exe/Pritunl.exe"> Pritunl.. </a><br>

<font color=green><h6><b>ท่านต้องทำการสมัครโปรโมชั่นเสริมก่อนจึงจะใช้งานVPNได้</font></h6></b>
				
<img src="https://vpn-hispeed.com/help/truemove.jpg" width="80" height="60">
              <font color=red><h5><b>📶 ทรูมูฟ สมัครโปร TrueID</font></h5></b>
<p><u><h5>9บาท / 1วัน +VAT=9.63บาท</u></h5>สมัครแล้ว เชื่อมต่อVPN เล่นเน็ตไม่จำกัด 1 วัน<br>
<strong>วิธีกดสมัคร</strong> :<span class="style3f">*900*3956</span># <button class="animated infinite jello btn btn-sm bg-black "><a href="tel:*900*3956*17327707%23">คลิ๊ก</button></a>📞</p>
<p><u><h5>19บาท / 7วัน +VAT=20.33บาท</u></h5>สมัครแล้ว เชื่อมต่อVPN เล่นเน็ตไม่จำกัด 7 วัน<br>
<strong>วิธีกดสมัคร</strong> :<span class="style3f">*900*3957</span># <button class="animated infinite jello btn btn-sm bg-black "><a href="tel:*900*3957*17327707%23">คลิ๊ก</button></a>📞</p>
<p><u><h5>59บาท / 30วัน +VAT=63.13บาท</u></h5>สมัครแล้ว เชื่อมต่อVPN เล่นเน็ตไม่จำกัด 30 วัน<br>
<strong>วิธีกดสมัคร</strong> :<span class="style3f">*900*3958</span># <button class="animated infinite jello btn btn-sm bg-black "><a href="tel:*900*3958*17327707%23">คลิ๊ก</button></a>📞</p>
<img src="https://vpn-hispeed.com/help/dtac.jpg" width="60" height="40">
<font color=blue><h5><b>📶 ดีแทค สมัครโปร Line</font></h5></b>
<p><u><h5>5 บาท / 1 วัน +VAT=5.35 บาท</u></h5>สมัครแล้ว เชื่อมต่อVPN เล่นเน็ตไม่จำกัด 1 วัน<br>
<strong>วิธีกดสมัคร</strong> :<span class="style3f">*104*431</span># <button class="animated infinite jello btn btn-sm bg-black "><a href="tel:*104*431%23">คลิ๊ก</button></a>📞</p>
<p><u><h5>19บาท / 7วัน +VAT=20.33บาท</u></h5> สมัครแล้ว เชื่อมต่อVPN เล่นเน็ตไม่จำกัด 7 วัน<br>
<strong>วิธีกดสมัคร</strong> :<span class="style3f">*104*421</span># <button class="animated infinite jello btn btn-sm bg-black "><a href="tel:*104*421%23">คลิ๊ก</button></a>📞</p>
 <p> <u><h5>49บาท / 30วัน +VAT=52.43บาท</u></h5>สมัครแล้ว เชื่อมต่อVPN เล่นเน็ตไม่จำกัด 30 วัน<br>
<strong>วิธีกดสมัคร</strong> :<span class="style3f">*104*432*1401096#</span> <button class="animated infinite jello btn btn-sm bg-black "><a href="tel:*104*432*1401096%23">คลิ๊ก</button></a>📞</p>
<!---button class="animated infinite jello btn btn-sm bg-black "><a href="/asset/img/Pro/dtac.png"> &nbsp;&nbsp;สมัคโปรทรูไอดี <i class="fa fa-sign-out"></i></a></button>
<button class="animated infinite jello btn btn-sm bg-black "><a href="/asset/img/Pro/true.png">สมัคโปรไลน์ดีแทค <i class="fa fa-sign-out"></i></a></button---><br>
<b>#หมายเหตุ:</b>มีปัญหาด้านการใช้งานหรืออื่นๆ ติดต่อแอดมิน(เจมส์)
<a href="https://m.me/jamejaturaporn.suriya.5"> กดตรงนี้ครับ. &nbsp; 
<img class="img-circle" src="<?php echo  base_url('asset/img/m2.gif') ?>"width="31" height="31"></a></p></div>



<div class="tab-pane" id="tab_2-2">
<h3><b></b></h3><br><br><br><br>

<!--------------------รายละเอียดการใช้งาน-------------------------->
<center><span style="font-size: 17px;" class="badge bg-maroon">รายละเอียดการใช้งาน</span><br>
				
				<p><b>บริการเช่าอินเตอเน็ตเชื่อมต่อผ่านระบบ VPN <br>รองรับซิมทรูและดีแทคโปรไลน์</p></b></center>
				
				<span style="font-size: 15px;" class="badge bg-purple">ข้อตกลง </span><br>
				<p>การใช้งานความเร็วและความแรงของอินเตอร์เน็ตแต่ละพื้นที่ก็ต่างกันไป ถ้าหากเน็ตของลูกค้าช้าหรือมีปันหาอื่นๆ 
				ก่อนที่จะมาแจ้งปัญหา กรุณาให้ลูกค้าตรวจสอบปัญหาให้แน่ชัดก่อนว่าเกิดจากอะไร ถ้าหากปันหาที่เป็นอยู่เกียวกับพืันที่หรือเครื่องของลูกค้าเองและอื่นๆ
				ที่ไม่เกียวกับเซิฟร์เวอร์ ทางเราก็ไม่สารถแก้ปันหานั้นได้ ทางเราแก้ได้เฉพาะปัญหาที่เกียวกับเซิฟร์เวอร์ของเราเท่านั้น จะเช่าหรือไม่นั้น ทางเราไม่บังคับ
				เป็นการตัดสิ้นใจของลูกค้าเอง เพราะฉะนั้นถ้าเช่าไปแล้ว จะไม่มีการคืนเงินไม่ว่ากรณีใดๆก็ตาม </p>
				
</tr></tbody>
</table>
</div>
</div>
</div>
</div>
</div>

<div class="row">
<div class="col-md-6 col-md-6 col-xs-12">
<div class="info-box bg-info"style="background: url('<?php echo  base_url('asset/img/b2.jpeg') ?>') center center;">
<span class="info-box-icon"><i class="fa fa-ge"></i></span>
<div class="info-box-content">
<span class="info-box-number">ยอดเงินคงเหลือ » <span style="font-size: 16px;" class="info-box-number pull-right badge bg-blue"><?= $user -> saldo ?> บาท</span>
<span class="info-box-number">ชื่อบัญชี » <span style="font-size: 16px;" class="info-box-number pull-right badge bg-blue"><?php echo  $user->username ?></span></span>
<div class="progress">
<div class="progress-bar" style="width: 0%"></div>
</div>
<span class="progress-description">
<a href="<?= base_url('main/'.$_SESSION['username'].'/topups') ?>">เติมเงิน <i class="fa fa-arrow-circle-right"></i></a>
</span>
</div>
</div>
</div>
<div class="col-md-6 col-md-6 col-xs-12">
<div class="info-box bg-info"style="background: url('<?php echo  base_url('asset/img/b2.jpeg') ?>') center center;">
<span class="info-box-icon"><i class="fa fa-user"></i></span>
<div class="info-box-content">
<span class="info-box-number">ID ACCOUNT » <span style="font-size: 16px;" class="info-box-number pull-right badge bg-blue"><?php echo  $user->id ?></span></span>
<span class="info-box-number">Email » <span style="font-size: 10px;" class="info-box-number pull-right badge bg-blue"><?php echo  $user->email ?></span></span>
<div class="progress">
<div class="progress-bar" style="width: 0%"></div>
</div>
<span class="progress-description">
<a href="<?= base_url('main/'.$_SESSION['username'].'/profile') ?>">วิธีใช้สำหรับระบบ Android <i class="fa fa-arrow-circle-right"></i></a>
</span>
</div>
</div>
</div>
</div>





  
  </div>