<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
       แก้ไขชื่อเว็บไซต์
      </h1>
    <ol class="breadcrumb">
        <li><a href="/home"><i class="fa fa-dashboard"></i> หน้าหลัก </a></li>
        <li class="active">แก้ไขชื่อเว็บไซต์</li>
    </ol>
    </section>
    		
			<br>
       
    <div class="row">
    	<div class="col-lg-12">
          <div class="panel panel-primary">
                <div class="panel-heading">
                    <h3 class="panel-title"> แก้ไขชื่อเว็บไซต์ </h3>
                </div>
                
			  <?php if (isset($message)) {echo $message;} ?>
			  <?php if (validation_errors()) : ?>
					<div class="col-md-12">
						<div class="alert alert-danger" role="alert"><?php echo  validation_errors() ?></div>
					</div>
					<?php endif; ?>
					<?php if (isset($error)) : ?>
					<div class="col-md-12">
						<div class="alert alert-danger" role="alert"><?php echo  $error ?></div>
					</div>
			   <?php endif;?>
                <?php echo  form_open() ?>
                <div class="panel-body">
                   <input type="text" name="webname" class="form-control" id="webname" placeholder="ใส่ชื่อเว็บไซต์"/>
                       </div>
                       <div class="form-group">
						<input type="submit" class="btn btn-md btn-block btn-warning" value="ยืนยัน"/>
					</div>
                 </form>
            </div>
        </div>
        
         <div class="col-lg-10">   
				<?php if (!empty($asset)):?>
					<h4 class="page-header">ชื่อเว็บไซต์ที่ตั้งไว้</h4>
					<div class="table-responsive"><table class="table table-hover">
						<thead>
							<tr>
							<th>Web Name</th>
							</tr>
                        </thead>
                        <tbody>
						<?php foreach ($asset as $row): ?>
							<?php if (empty($row['rekening'])):?>
                          	<?php if (empty($row['bank'])):?>
                             	<?php if (empty($row['pemilik'])):?>
							<tr>
								<td><a href="<?php echo base_url('admin/del_req/'.$row['id'])?>">Del</a></td>
								<td><?php echo  $row['webname']?></td>
							</tr>
									<?php endif;?>
							    <?php endif;?>
    						<?php endif;?>
						<?php endforeach; ?>
						</tbody>
					</table></div>
					<?php else: ?>
						<h4 class="page-header">????????????????</h4>
				<?php endif; ?>
			</div>
		</div>
    </div>
    
      </section>
</div>