<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
       Server VPN SSH
      </h1>
    <ol class="breadcrumb">
        <li><a href="/home"><i class="fa fa-dashboard"></i> ????????</a></li>
        <li class="active">??????????????????</li>
    </ol>
    </section>
    		<section class="content">
   			 <div class="row">
                    <div class="col-md-12 text-center">
                        <label class="label label-success">Fast Data Transfer</label>
                        <label class="label label-warning">High Speed Servers</label>
                        <label class="label label-info">Hide Your IP</label>
                        <label class="label label-primary">Premium VPN Server</label>
                        <label class="label label-warning">Worldwide Servers</label>
                        <label class="label label-success">Internet Privacy</label>
                        <label class="label label-info">Exclusive Secure Shell</label>
                        <label class="label label-primary">Security Solutions</label>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-12 text-center">
                        <label class="label label-danger">No DDOS</label>
                        <label class="label label-danger">No BUG</label>
                        <label class="label label-danger">No Hacking</label>
                        <label class="label label-danger">No Carding</label>
                        <label class="label label-danger">No Spamm</label>
                        <label class="label label-danger">No Torrent</label>
                        <label class="label label-danger">No Fraud</label>
                        <label class="label label-danger">No Error</label>
                        <label class="label label-danger">No Repost</label>
                    </div>
                </div>
			<br>
   
    
    <div class="row">
    	<div class="col-sm-6 col-md-4 col-lg-3">
        <div class="box box-widget widget-user">
           <div class="widget-user-header bg-black" style="background: url('<?php echo  base_url('asset/img/photo.jpeg') ?>') center center;">
              <h3 class="widget-user-username"><B>??????????????????????? <B></h3>
              <h4 class="widget-user-desc"><B>  <B></h4>
              
            </div>
            <div class="widget-user-image">
              <img class="img-circle" src="<?php echo  base_url('asset/img/user.png') ?>" alt="User Avatar">
            </div>
                  
       <div class="box-footer no-padding">
      	<div class="description-block"><br><br>
            <span class="description-text"><span style="font-size: 16px;"  class="badge bg-red">??????????</span></span>
         </div>
         
    	<div class="col-sm-6 col-md-4 col-lg-3">
    		 <div class="panel-body">   
				<?php if (!empty($asset)):?>
					<div class="table-responsive">
						<table class="table table-hover">
						<thead>
							<tr><th>#</th><th>FB</th><th>??????</th><th>??????</th></tr>
                        </thead>
                        <tbody>
						<?php foreach ($asset as $row): ?>
							<tr>
								
								<?php if (empty($row['nohp'])):?>
									<?php if (empty($row['webname'])):?>
									<td><a href="<?php echo base_url('admin/del_req/'.$row['id'])?>">Del</a></td>
									<td><?php echo  $row['rekening']?></td>
									<td><?php echo  $row['pemilik']?></td>
									<td><?php echo  $row['bank']?></td>
									<?php endif;?>
								<?php endif; ?>
							</tr>
						<?php endforeach; ?>
						</tbody>
					</table></div>
					<?php else: ?>
						<h4 class="page-header">?????????????????????????</h4>
				<?php endif; ?>
				</div>
			</div>
			
			<div class="col-lg-6">
           	<center>
               <span class="description-text"><span style="font-size: 16px;"  class="badge bg-green">???????????????????????????</span></span>         
              </center>    
			  <?php if (isset($message)) {echo $message;} ?>
			  <?php if (validation_errors()) : ?>
					<div class="col-md-12">
						<div class="alert alert-danger" role="alert"><?php echo  validation_errors() ?></div>
					</div>
					<?php endif; ?>
					<?php if (isset($error)) : ?>
					<div class="col-md-12">
						<div class="alert alert-danger" role="alert"><?php echo  $error ?></div>
					</div>
			   <?php endif;?>
			   <?php echo  form_open() ?>
					<div class="form-group">
						<label for="rekening">FACEBOOK</label>
						<input type="text" name="rekening" class="form-control" id="rekening" placeholder="?????? ID FACEBOOK"/>
						<small class="text-muted">???????? : BeerWaiting</small>
					</div>
						<label for="pemilik">????????????????</label>
						<input type="text" name="pemilik" class="form-control" id="pemilik" placeholder="???????"/>
						
						<label for="bank">????????????????</label>
						<input type="text" name="bank" class="form-control" id="bank" placeholder="???????"/>
						
					<div class="form-group">
						<input type="submit" class="btn btn-md btn-block btn-danger" value="??????"/>
					</div>
			   </form>
		   </div>
		  
    	</div>

      </section>
</div>