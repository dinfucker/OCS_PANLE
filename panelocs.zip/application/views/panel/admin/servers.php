<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
       เซิรฟเวอร์  VPN
      </h1>
    <ol class="breadcrumb">
        <li><a href="/"><i class="fa fa-home"></i> หน้าหลัก </a></li>
        <li class="active"> เซิร์ฟเวอร์ทั้งหมด </li>
    </ol>
    </section>
 
        
   
    <div class="row">
            <div class="col-lg-12">
                <?php if (isset($_SESSION['is_admin'])): ?>
                <a href="<?php echo  base_url('main/administrator/'.str_replace(' ','-',$_SESSION['username']).'/addserver') ?>" class="btn btn-primary pull-right"><i class="fa fa-plus fa-fw"></i> เพิ่มเซิร์ฟเวอร์  </a>
                <?php endif; ?>           
    <br><br><br>
    <div class="row">
            <div class="col-lg-12">
                <?php if (isset($message)) { echo $message;} ?>
            </div>
        <?php foreach($server as $row): ?>
            <div class="col-sm-6">
                <div class="panel panel-info">					 
                    <div class="panel-heading">                      
												<div class="panel-title"><b><?php echo  $row['ServerName']?></b></div>
							<span clas="pull-right">
							<?php if ($row['Status']): ?>
								<a class="btn btn-success btn-sm pull-right" href="<?php echo  base_url('main/administrator/edit/'.str_replace(' ','-',$row['ServerName']).'/'.$row['Id'].'/lock' ) ?>"><i class="fa fa-unlock"></i> เปิดบริการ </a>
								<?php else: ?>
								<a class="btn btn-blue btn-sm pull-right" href="<?php echo  base_url('main/administrator/edit/'.str_replace(' ','-',$row['ServerName']).'/'.$row['Id'].'/unlock' ) ?>"><i class="fa fa-lock"></i> ปิดบรการ </a>
								<?php endif; ?>
							</span>
                    </div>
                    <div class="panel-body">
                    <table class="table table-condensed">
                        <tr>
                            <td> เซิรฟเวอร์ </td><td><?php echo  $row['Location']?></td>
                        </tr>
                        <tr>
                            <td> โฮส </td><td><?php echo  $row['HostName']?></td>
                        </tr>
                        <tr>
                            <td> ราคา </td><td><?php echo  $row['Price']?></td>
                        </tr>
                    </table>  
                    </div>
						
                    <div class="col-sm-12">
                        <a href="<?php echo  base_url('main/administrator/edit/'.str_replace(' ','-',$row['ServerName']).'/'.$row['Id'])?>" class="btn btn-primary btn-sm"><i class="fa fa-edit fa-fw"></i> แก้ไขเซิรฟเวอร์ </a>
                        <a href="<?php echo  base_url('admin/usercheck/'.$row['Id']) ?>" class="btn btn-warning btn-sm"><i class="fa fa-group fa-fw"></i> เพิ่มบัญชี </a>
                        <a href="<?php echo  base_url('main/administrator/edit/'.str_replace(' ','-',$row['ServerName']).'/'.$row['Id'].'/del' ) ?>" class="btn btn-danger btn-sm hapus pull-right"></i> ลบเซิรฟเวอร์</a>
                    </div>
                </div>
            </div>
        <?php endforeach; ?>
      </section>
</div>