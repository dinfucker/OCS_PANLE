<html lang="en" style="height: auto;"><head>
<head>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<meta name="description" content="">
		<meta name="keywords" content="">
		<meta name="author" content="">
		<title>LIFESTYLE VPN</title>
		
<!-- Custom Fonts -->
    <link href='http://fonts.googleapis.com/css?family=Open+Sans:300italic,400italic,600italic,700italic,800italic,400,300,600,700,800' rel='stylesheet' type='text/css'>
    <link href='http://fonts.googleapis.com/css?family=Merriweather:400,300,300italic,400italic,700,700italic,900,900italic' rel='stylesheet' type='text/css'>
    <link href="<?php echo  base_url('asset/font-awesome/css/font-awesome.min.css')?>" rel="stylesheet"/>
    <!-- Plugin CSS -->
    <link href="<?php echo  base_url('asset/css/animate.min.css" type="text/css')?>" rel="stylesheet"/>
    <!-- Custom CSS -->
    <link href="<?php echo  base_url('asset/css/creative.css" type="text/css')?>" rel="stylesheet"/>
  	
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/ionicons/2.0.1/css/ionicons.min.css">
		<script src="https://code.jquery.com/jquery-2.1.3.min.js"></script>
	
		
       
	<LINK REL="SHORTCUT ICON" HREF="<?php echo  base_url('asset/img/i5.png') ?>"
	
		
	</head>
	
	
	<body class="skin-black-light fixed sidebar-mini" id="page-top" style="height: auto;">

<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="description" content="LIFESTYLE VPN">
<meta name="author" content="LIFESTYLE VPN">
<link rel="stylesheet" href="/signup/css/bootstrap.min.css" type="text/css">
<link href="https://fonts.googleapis.com/css?family=Open+Sans:300italic,400italic,600italic,700italic,800italic,400,300,600,700,800" rel="stylesheet" type="text/css">
<link href="https://fonts.googleapis.com/css?family=Merriweather:400,300,300italic,400italic,700,700italic,900,900italic" rel="stylesheet" type="text/css">
<link rel="stylesheet" href="/signup/font-awesome/css/font-awesome.min.css" type="text/css">

<link rel="stylesheet" href="/signup/css/animate.min.css" type="text/css">

<link rel="stylesheet" href="/signup/css/creative.css" type="text/css">



<nav id="mainNav" class="navbar navbar-default bg-dark navbar-fixed-top affix-top">
<div class="container-fluid">
<div class="navbar-header">
<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
<span class="sr-only">Toggle navigation</span>
<span class="icon-bar"></span>
<span class="icon-bar"></span>
<span class="icon-bar"></span>
</button>
<a class="navbar-brand page-scroll" href="/">
<img src="<?php echo  base_url('asset/img/i5.png') ?>" width="25px" style="display:inline; margin:0 2px 3px 0"> LIFESTYLE VPN</a>
</div>
<div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
<ul class="nav navbar-nav navbar-right">
<li>
<a class="page-scroll" href="/register"> สมัครบัญชี </a>
</li>
<li>
<a class="page-scroll" href="https://m.facebook.com/jamejaturaporn.suriya.5">ติดต่อผู้ดูแล</a>
</li>
</ul>
</div>
</div>
</nav><br><br><br>
<section id="services">
<div class="container">
<div class="row">
<div class="col-lg-12 text-center">
<br>
<img class="img-circle" src="https://cdn-images-1.medium.com/max/1600/1*Jj799s3EEUwg_FuN_VGWQQ.gif" width="240" height="240"><br>
<h4><b> L I F E S T Y L E - V P N </b></h4>
<h4><b> WELLCOME TO THAILAND </b></h4><br>
</div>
</div>
</div>
<div class="container">
<div class="row">
<div class="col-md-4 col-md-offset-4">
<form action="/login" method="post">


<div class="login">
<?php if (validation_errors()) : ?>
                    <div class="alert alert-danger"><?php echo  validation_errors() ?></div>
                <?php endif; ?>
                <?php if (isset($error)) : ?>
					<div class="col-md-12">
						<div class="alert alert-danger" role="alert"><?php echo  $error ?></div>
					</div>
				<?php endif; ?>
		
   			 <?php echo  form_open() ?>
<form action="/login" method="post" class="ng-pristine ng-valid">
<div style="margin-bottom: 25px" class="input-group">
<span class="input-group-addon"><i class="glyphicon glyphicon-user"></i></span>
<input required="required" id="username" type="text" class="form-control" onblur="checkText();" name="username" value="" placeholder="Username" minlength="3">
</div>
<div style="margin-bottom: 25px" class="input-group">
<span class="input-group-addon"><i class="glyphicon glyphicon-lock"></i></span>
<input required="required" id="password" type="password" class="form-control" name="password" placeholder="Password">
</div>
<div style="margin-top:15px" class="form-group">

<div class="col-lg-15">
<input type="submit" value=" &nbsp;&nbsp;&nbsp;ล็อคอิน&nbsp;&nbsp;&nbsp; " name="submit" class="btn btn-success pull-left">
</div>
<div class="col-lg-15">
<a href="/register" class="btn btn-info pull-right">สมัครบัญชี</a><br><br>
</div>
</div>


 
    

</body></html>