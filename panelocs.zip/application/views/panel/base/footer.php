<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>
	
<?php foreach ($this->user_model->view_asset() as $row): ?>
      	<?php if (empty($row['rekening'])):?>
      	<?php if (empty($row['bank'])):?>
      	<?php if (empty($row['pemilik'])):?>
<footer class="main-footer text-center">
    <strong>2018 &copy;  <a href="/"><?php echo $row['webname']?></a></strong> 
  </footer>
<?php endif;?> 
    <?php endif;?>
    	<?php endif;?>
			 <?php endforeach; ?>

	<!-- js -->
	<script src="<?php echo base_url('plugins/jQuery/jquery-2.2.3.min.js') ?>"></script>

<script src="https://cdnjs.cloudflare.com/ajax/libs/metisMenu/2.0.0/metisMenu.min.js') ?>"></script>
<link href="<?php echo base_url('../plugins/daterangepicker/daterangepicker.css')?>" rel="stylesheet"/>
<link href="<?php echo base_url('../plugins/datepicker/datepicker3.css')?>" rel="stylesheet"/>
<script src="<?php echo base_url('asset/js/bootstrap.min.js') ?>"></script>
<script src="<?php echo base_url('plugins/slimScroll/jquery.slimscroll.min.js') ?>"></script>
<script src="<?php echo base_url('plugins/fastclick/fastclick.js') ?>"></script>
<script src="<?php echo base_url('asset/dist/js/app.min.js') ?>"></script>
<script src="<?php echo base_url('../plugins/datatables/jquery.dataTables.min.js') ?>"></script>
<script src="<?php echo base_url('../plugins/datatables/dataTables.bootstrap.min.js') ?>"></script>
<script>
  $(function () {
    $('#fornesia').DataTable({
      "paging": true,
      "lengthChange": false,
      "searching": false,
      "ordering": true,
      "info": true,
      "autoWidth": false
    });
  });
</script>
  <script src="<?php echo base_url('asset/js/nouislider.min.js') ?>"></script>
  <script src="<?php echo base_url('../plugins/datepicker/bootstrap-datepicker.js') ?>"></script>
  <script src="<?php echo base_url('asset/js/bootstrap-dialog.min.js') ?>"></script>    
    <script type="text/javascript">
        $('.input-group.date').datepicker({
            format: "yyyy/mm/dd",
            weekStart: 1,
            clearBtn: true,
            language: "id",
            autoclose: true,
            todayHighlight: true
        });
        $('.hapus').click(function(e) {
            e.preventDefault();
            BootstrapDialog.confirm({
                title: 'ลบเซิฟเวอร์',
                message: ' คุณต้องการลบใช่มั้ย ?',
                type: BootstrapDialog.TYPE_DANGER,
                closable: true,
                btnCancelLabel: 'ยกเลิก',
                btnOKLabel: 'ยืนยันลบ',
                btnOKClass: 'btn-danger',
                callback: function(result) {
                    if(result) {
                        location.href = $('.hapus').attr('href');
                    }
                }
            });
        });
        function print_report() {
            window.print();
            return false;
        }
    </script>

</body>
</html>