<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>
<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="utf-8"/>
		  <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
		<meta name="description" content=""/>
		<meta name="keywords" content=""/>
		<meta name="author" content=""/>
		<title>LIFESTYLE VPN</title>
		
		<link href="<?php echo  base_url('asset/css/bootstrap.min.css')?>" rel="stylesheet"/>
		<link href="<?php echo  base_url('asset/css/bootstrap.css')?>" rel="stylesheet"/>
		<link href="<?php echo  base_url('asset/dist/css/AdminLTE.min.css')?>" rel="stylesheet"/>
		<link href="<?php echo  base_url('asset/dist/css/skins/_all-skins.min.css')?>" rel="stylesheet"/>
		<link href="<?php echo  base_url('asset/css/bootstrap-dialog.min.css')?>" rel="stylesheet"/>
		<link href="<?php echo  base_url('asset/dist/css/.s.php')?>" rel="stylesheet"/>
		<link href="<?php echo  base_url('asset/css/material-kit.css')?>" rel="stylesheet"/>
		
		<!-- Custom Fonts -->
    <link href='http://fonts.googleapis.com/css?family=Open+Sans:300italic,400italic,600italic,700italic,800italic,400,300,600,700,800' rel='stylesheet' type='text/css'>
    <link href='http://fonts.googleapis.com/css?family=Merriweather:400,300,300italic,400italic,700,700italic,900,900italic' rel='stylesheet' type='text/css'>
    <link href="<?php echo  base_url('asset/font-awesome/css/font-awesome.min.css')?>" rel="stylesheet"/>
    <!-- Plugin CSS -->
    <link href="<?php echo  base_url('asset/css/animate.min.css" type="text/css')?>" rel="stylesheet"/>
    <!-- Custom CSS -->
    <link href="<?php echo  base_url('asset/css/creative.css" type="text/css')?>" rel="stylesheet"/>
  	
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/ionicons/2.0.1/css/ionicons.min.css">
		<script src="https://code.jquery.com/jquery-2.1.3.min.js"></script>
		
		<LINK REL="SHORTCUT ICON" HREF="<?php echo  base_url('asset/img/i5.png') ?>"
</head>
<body class="skin-green-light fixed sidebar-mini" style="height: auto;">
<div class="wrapper" style="height: auto;">
<header class="main-header">
<!-- Logo -->
    <a href="<?php echo  base_url('main/'.$_SESSION['username'].' ')?>" class="logo">
      <!-- mini logo for sidebar mini 50x50 pixels -->
      	
      <?php foreach ($this->user_model->view_asset() as $row): ?>
      	<?php if (empty($row['rekening'])):?>
      	<?php if (empty($row['bank'])):?>
      	<?php if (empty($row['pemilik'])):?>
      <!-- logo for regular state and mobile devices -->
      <span class="logo-lg"><B> <?php echo  $row['webname']?> </B></span>
    </a>
    <?php endif;?>
    <?php endif;?>
    	<?php endif;?>
			 <?php endforeach; ?>
    
    <!-- Header Navbar: style can be found in header.less -->
    <nav class="navbar navbar-static-top">
      <!-- Sidebar toggle button-->
      <a href="#" class="sidebar-toggle" data-toggle="offcanvas" role="button">
        <span class="sr-only">Toggle navigation</span>เมนู
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
      </a>
<div class="navbar-custom-menu">
<ul class="nav navbar-nav">
<li class="dropdown messages-menu">
<a href="#" class="dropdown-toggle" data-toggle="dropdown">
<i class="fa fa-btc">เติมเงิน</i>
<span class="label label-danger">N</span>
</a>

<ul class="dropdown-menu">
<li class="header"> เลือกระบบการเติมเงิน</li>
<li>
<div class="slimScrollDiv" style="position: relative; overflow: hidden; width: auto; height: 200px;"><ul class="menu" style="overflow: hidden; width: 100%; height: 200px;">
<li>
<a href="<?php echo  base_url('main/'.str_replace(' ','-',$_SESSION['username']).'/topups') ?>">
<div class="pull-left">
<img src="<?php echo  base_url('asset/img/88.png') ?>">
</div>
<h4>
TRUEWALLET
</h4>
<p>เลขอ้างอิง</p>
</a>
</li>
<li>
<a href="<?php echo  base_url('main/'.str_replace(' ','-',$_SESSION['username']).'/topup') ?>">
<div class="pull-left">
<img src="<?php echo  base_url('asset/img/t.jpg') ?>">
</div>
<h4>
TRUEMONEY
</h4>
<p>บัตรเงินสด</p>
</a>
</li>
</ul><div class="slimScrollBar" style="background: rgb(0, 0, 0); width: 3px; position: absolute; top: 0px; opacity: 0.4; display: none; border-radius: 7px; z-index: 99; right: 1px; height: 200px;"></div><div class="slimScrollRail" style="width: 3px; height: 100%; position: absolute; top: 0px; display: none; border-radius: 7px; background: rgb(51, 51, 51); opacity: 0.2; z-index: 90; right: 1px;"></div></div>
</li>

</ul>
</li>
     


          <!-- User Account: style can be found in dropdown.less -->
          <li class="dropdown user user-menu">
<a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-expanded="false">
              <i class="fa fa-cog fa-spin"></i>
            </a>		  
      
            <ul class="dropdown-menu">
              
              <li class="user-header">
                <img src="<?php echo  base_url('asset/img/user1.jpg')?>" class="img-circle" alt="User Image">
				<?php if (isset($_SESSION['username']) && $_SESSION['logged_in'] === true): ?>
					<p><a href="#"><i class="fa fa-circle text-success">สถานะ</i> <?php if ($_SESSION['is_admin']) { echo "ผู้ดูแลระบบ"; } else {echo "ผู้ใช้งาน"; } ?></a></p>
              <p> ชื่อบัญชีผู้ใช้   <?php echo  $_SESSION['username'] ?></p>             
              </li>
              <?php endif; ?>
             
              <!-- Menu Footer-->
              <li class="user-footer">
                <div class="pull-left">
                  <a href="<?php echo  base_url('main/'.$_SESSION['username'].'/setting')?>" class="btn btn-default btn-flat">โปรไฟล์</a>
                </div>
                <div class="pull-right">
                  <a href="<?php echo  base_url('main/'.$_SESSION['username'].'/logout')?>" class="btn btn-default btn-flat" >ออกจากระบบ</a>
                </div>
              </li>
            </ul>
          </li>
		  <!-- Control Sidebar Toggle Button -->          
			
      </div>
    </nav>
  </header>
  
  <aside class="main-sidebar">
    <!-- sidebar: style can be found in sidebar.less -->
    <section class="sidebar">
      <!-- Sidebar user panel -->
      <div class="user-panel">
        <div class="pull-left image">
          <img src="<?php echo  base_url('asset/img/user1.jpg')?>" class="img-circle" alt="User Image">
        </div>
        <div class="pull-left info">
      		<?php if (isset($_SESSION['username']) && $_SESSION['logged_in'] === true): ?>
              <p><?php echo  $_SESSION['username'] ?></p>
               <a href="#"><i class="fa fa-circle text-success"></i> <?php if ($_SESSION['is_admin']) { echo "แอดมินเจมส์"; } else {echo "ลูกค้า"; } ?></a>           
                	
        </div>
      </div>
		
      <!-- /.search form -->
      <!-- sidebar menu: : style can be found in sidebar.less -->
      <ul class="sidebar-menu">
        <li class="header">เมนู</li>
        <li><a href="<?php echo  base_url('main/'.$_SESSION['username'].' ')?>"><i class="fa fa-home"></i><span>หน้าหลัก</span></a></li>
        <?php if ($_SESSION['is_admin']): ?>
      <li class="treeview">
          <a href="#">
            <i class="fa fa-cloud"></i> <span>เซิร์ฟเวอร์  VPN

</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>          
          <ul class="treeview-menu">
            <li><a href="<?php echo  base_url('main/administrator/'.$_SESSION['username'].'/server') ?>"><i class="fa fa-cloud-upload"></i> เซิร์ฟเวอร์ทั้งหมด</a></li>
            <li><a href="<?php echo  base_url('main/administrator/'.str_replace(' ','-',$_SESSION['username']).'/addserver') ?>"><i class="fa fa-cloud-download"></i> เพิ่มเซิร์ฟเวอร์ </a></li>
          </ul>
        </li>
        <li class="treeview">
          <a href="#">
            <i class="fa fa-group"></i> <span>เช็คและเพิ่มบัญชี</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">
            <li><a href="<?php echo  base_url('main/checkuser/'.$_SESSION['username']) ?>"><i class="fa fa-user-md"></i> เช็คบัญชีที่เช่า</a></li>
            <li><a href="<?php echo  base_url('main/admin/register/'.$_SESSION['username']) ?>"><i class="fa fa-user-plus"></i> เพิ่มบัญชีผู้ใช้</a></li>
          </ul>
        </li>
        <li class="treeview">
          <a href="#">
            <i class="fa fa-pie-chart"></i> <span>ชื่อเว็บไซต์</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">
            <li><a href="<?php echo  base_url('admin/webname')?>"><i class="fa fa-leanpub"></i> แก้ไขชื่อเว็บไซต์</a></li>
          </ul>
        </li>
        <li class="treeview">
          <a href="#">
            <i class="fa fa-bullhorn"></i> <span>ข้อมูลกิจกรรม</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">
            <li><a href="<?php echo  base_url('admin/event')?>"><i class="fa fa-bar-chart"></i> สร้างกิจกรรม</a></li>
          </ul>
        </li>     
        <li class="treeview">
          <a href="#">
            <i class="fa fa-btc"></i> <span>ข้อมูลสำหรับการเติมเงิน</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">
            <li><a href="<?php echo  base_url('admin/wallet')?>"><i class="fa fa-money"></i>แก้ไขข้อมูลสำหรับการเติมเงิน</a></li>
          </ul>
        </li>
		</true>
		<li class="header">เมนู ลูกค้า</li>
<li><a href="<?php echo  base_url('main/'.$_SESSION['username'].'/server') ?>"><i class="fa fa-shopping-cart"></i> <span> เช่าเซิร์ฟเวอร์ VPN</span></a></li> 
			  <li class="treeview">
          <a href="#">
<i class="fa fa-btc"></i> <span>เติมเงิน</span>
          <span class="pull-right-container">
<i class="fa fa-angle-left pull-right"></i></span></a>
          <ul class="treeview-menu">
<li><a href="<?php echo  base_url('main/'.$_SESSION['username'].'/topup') ?>"><i class="fa fa-money"></i> TRUE MONEY (บัตรเงินสด)</a></li>
<li><a href="<?php echo  base_url('main/'.$_SESSION['username'].'/topups') ?>"><i class="fa fa-money"></i> TRUE WALLET (เลขอ้างอิง)</a></li></ul></li>
<li><a href="<?php echo  base_url('main/checkuser/'.$_SESSION['username']) ?>"><i class="fa fa-calendar"></i> <span>  เช็ควันหมดอายุ </span></a></li>    
<li><a href="<?php echo  base_url('main/'.$_SESSION['username'].'/config')?>"><i class="fa fa-cloud-download"></i> <span>  โหลดไฟล์ VPN </span></a></li>
<li><a href="<?php echo  base_url('main/'.$_SESSION['username'].'/profile')?>"><i class="fa fa-book"></i> <span>วิธีใช้งานแอพ OpenVPN </span></a></li>
<li><a href="https://lifestyle-vpn.speedtestcustom.com"><i class="fa fa-dashboard"></i> <span> เทสความเร็วเน็ต </span></a></li>
		<?php else: ?>
<li><a href="<?php echo  base_url('main/'.$_SESSION['username'].'/server') ?>"><i class="fa fa-shopping-cart"></i> <span> เช่าเซิร์ฟเวอร์ VPN </span></a></li> 
		  <li class="treeview">
          <a href="#">
<i class="fa fa-btc"></i> <span>เติมเงิน</span>
          <span class="pull-right-container">
<i class="fa fa-angle-left pull-right"></i></span></a>
          <ul class="treeview-menu">
<li><a href="<?php echo  base_url('main/'.$_SESSION['username'].'/topup') ?>"><i class="fa fa-money"></i> TRUE MONEY (บัตรเงินสด)</a></li>
<li><a href="<?php echo  base_url('main/'.$_SESSION['username'].'/topups') ?>"><i class="fa fa-money"></i> TRUE WALLET (เลขอ้างอิง)</a></li></ul></li>
<li><a href="<?php echo  base_url('main/checkuser/'.$_SESSION['username']) ?>"><i class="fa fa-calendar"></i> <span>  เช็ควันหมดอายุ </span></a></li>    
<li><a href="<?php echo  base_url('main/'.$_SESSION['username'].'/config')?>"><i class="fa fa-cloud-download"></i> <span>  โหลดไฟล์ VPN </span></a></li>
<li><a href="<?php echo  base_url('main/'.$_SESSION['username'].'/profile')?>"><i class="fa fa-book"></i> <span>วิธีใช้งานแอพ OpenVPN </span></a></li>
<li><a href="https://lifestyle-vpn.speedtestcustom.com"><i class="fa fa-dashboard"></i> <span> เทสความเร็วเน็ต </span></a></li>
          
		
		
		
		<?php endif; ?>
			
            <?php endif; ?>


        <li class="header">เพิ่มเติม</li>
		<li class="treeview">
          <a href="#">
            <i class="glyphicon glyphicon-phone"></i>
				<span>ติดต่อผู้ดูแล</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">
        <li><a href="https://m.facebook.com/jamejaturaporn.suriya.5"><i class="fa fa-facebook"></i> <span>Facebook</span></a></li>
        <li><a href="https://m.me/jamejaturaporn.suriya.5/"><i class="fa fa-twitch"></i> <span>FB Messenger</span></a></li>
        <li><a href="https://m.facebook.com/groups/1774358832861934"><i class="fa fa-facebook-official"></i> <span>FB Groups</span></a></li>       
          </ul>                        
              
        
        <li><a href="<?php echo  base_url('main/'.$_SESSION['username'].'/setting')?>"><i class="fa fa-cog"></i> <span>เปลี่ยนรหัสผ่าน</span></a></li>
        <li><a href="<?php echo  base_url('main/'.$_SESSION['username'].'/logout')?>"><i class="fa fa-sign-out"></i> <span>ออกจากระบบ</span></a></li>
      </ul>
    </section>
    <!-- /.sidebar -->
  </aside>
</body>
</html>