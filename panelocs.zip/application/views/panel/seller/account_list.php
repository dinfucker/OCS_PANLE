<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
      ประวัติการเช่าทั้งหมด
      </h1>
    <ol class="breadcrumb">
        <li><a href="/"><i class="fa fa-home"></i>หน้าหลัก</a></li>
        <li class="active">ประวัติการเช่า</li>
    </ol>
    </section>

			    <!-- Main content -->
  		 

    <div class="row">
  <section class="content">
       <div class="col-sm-12">    
        <div class="box box-widget widget-user">
           <div class="widget-user-header bg-black" style="background: url('<?php echo  base_url('asset/img/8.png') ?>') center center;">
              <CENTER><h3 class="widget-user-username"><i class="fa fa-user-circle"></i> ประวัติการเช่าของคุณ</h3></CENTER>
            </div>
            <div class="widget-user-image">
              <img class="img-circle" src="<?php echo  base_url('asset/img/user1.jpg') ?>" alt="User Avatar">
            </div>
                          
	    <br><br><div class="description-block">
            <span class="description-text"><span class="label label-danger"> รายละเอียดการเช่า </span></span>
         </div>
        
              
                <div class="box-body">
                    <div class="table-responsive">
                        <table class="table table-hover">
                            <thead>
                                <tr>     
                                    <th>ชื่อบัญชี</th>                                   
                                    <th>ไอพีเซิร์ฟเวอร์</th>
                                    <th>วันที่เช่า</th>
                                    <th>วันหมดอายุ</th>
                                    <th>ราคา</th>
                                    <th>ลบบัญชี</th>
                                    </tr>
                               </thead>
                            <tbody>
                                <?php if(!empty($account)):?>
										<?php $jumlah=0; $counter=0; ?>
                                        <?php foreach ($account as $row): ?>
											<?php $counter++; ?>
                                            <tr>
                        
                                                <td><?php echo  $row['username'] ?></td>
                                                <td><?php echo $row['hostname']?></td>
                                                <td><?php echo  $row['created_at']?></td>
                                               <td><?php  $today=date('Y-m-d'); $expire=date('Y-m-d', strtotime($row['created_at']. '+30 days')); if ($today>=$expire){ echo $expire; } else{ echo $expire; } ?></td>
                                                <td><?php echo  $row['price']?></td>
                                                <td>
                                                    <a href="<?php echo  base_url('seller/delet_account/'. $row['id'])?>" class="btn btn-danger"><span class="fa fa-trash-o fa-sm"></span></a>

                                                </td>
                                             </tr>
                                             <?php $jumlah = $jumlah + $row['price']; ?>
                                       <?php endforeach; ?>
                                    <?php else: ?>
                                   
                                        <tr>
                                            <td class="text-muted text-center" colspan="6"> </td>
                                        </tr>
                                   <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
				<div class="box-footer"><B> <?php if (isset($counter)) {echo 'บัญชีทั้งหมด: '. $counter; } ?> บัญชี | <?php if (isset($jumlah)) {echo 'รวมเป็นเงินทั้งสิ้น : '. $jumlah; } ?> บาท <B></div>
            </div>
        </div>
    </div>            
 </section>  
</div>
  <!-- /.content-wrapper -->