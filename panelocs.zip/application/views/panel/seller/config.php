<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
      ไฟล์ CONFIG VPN
      </h1>
    <ol class="breadcrumb">
        <li><a href="/"><i class="fa fa-home"></i>หน้าหลัก</a></li>
        <li class="active">CONFIG VPN</li>
    </ol>
    </section>
    <br>
    <!-- Main content -->
    <div class="row">
  <section class="content">   
       <div class="col-sm-12 ">    
        <div class="box box-widget widget-user">
           <div class="widget-user-header bg-black" style="background: url('<?php echo  base_url('asset/img/8.png') ?>') center center;">
              <h3 class="widget-user-username"><B><B></h3>
			  <center><span class="description-text"><span style="font-size: 16px;"  class="badge bg-maroon">CONFIG OPENVPN</span></center>
              <h4 class="widget-user-desc"><B><B></h4>
              <p>     </p>
            </div>
            <div class="widget-user-image">
              <img class="img-circle" src="<?php echo  base_url('asset/img/user1.png') ?>" alt="User Avatar">
            </div>
                  
       <div class="box-footer no-padding">
      	<div class="description-block"><br><br>
            <span class="description-text"><span style="font-size: 16px;"  class="badge bg-maroon">โหลดไฟล์ VPN</span></span>
         </div>
         
		 
		 
		 <ul class="nav nav-stacked">
<div class="box-body">
<center>
</center><table class="table">
<tbody><tr>
<td><span class="label label-success">ชื่อเซิร์ฟเวอร์ </span></td>
<td><span class="label label-danger">ไฟล์ซิมทรูมูฟ TRUE</span></td>
<td><span class="label label-info">ไฟล์ซิมดีแทค DTAC</span></td>
</tr>
		

		<tr> 
<td><b> SG-1-LIFESTYLE </b></td>
<td><b><a href="/web/vpn/TRUE/TRUE-SG-1-LIFESTYLE.ovpn" class="btn btn-danger">TRUE</a><b></b></b></td>
<td><b><a href="/web/vpn/DTAC/DTAC-SG-1-LIFESTYLE.ovpn" class="btn btn-info">DTAC</a><b></b></b></td>
</tr>
<tr> 
<td><b> SG-2-LIFESTYLE </b></td>
<td><b><a href="/web/vpn/TRUE/TRUE-SG-2-LIFESTYLE.ovpn" class="btn btn-danger">TRUE</a><b></b></b></td>
<td><b><a href="/web/vpn/DTAC/DTAC-SG-2-LIFESTYLE.ovpn" class="btn btn-info">DTAC</a><b></b></b></td>
</tr>
<td><b> TH-VIP1-LIFESTYLE </b></td>
<td><b><a href="/web/vpn/TRUE/TRUE-TH-VIP1-LIFESTYLE.ovpn" class="btn btn-danger">TRUE</a><b></b></b></td>
<td><b><a href="/web/vpn/DTAC/DTAC-TH-VIP1-LIFESTYLE.ovpn" class="btn btn-info">DTAC</a><b></b></b></td>
</tr>
<td><b> TH-VIP2-LIFESTYLE </b></td>
<td><b><a href="/web/vpn/TRUE/TRUE-TH-VIP2-LIFESTYLE.ovpn" class="btn btn-danger">TRUE</a><b></b></b></td>
<td><b><a href="/web/vpn/DTAC/DTAC-TH-VIP2-LIFESTYLE.ovpn" class="btn btn-info">DTAC</a><b></b></b></td>
</tr>
<td><b> TH-PC1-LIFESTYLE </b></td> 
<td><b><a href="/web/vpn/TRUE/TRUE-TH-PC1-LIFESTYLE.ovpn" class="btn btn-danger">TRUE</a><b></b></b></td>
<td><b><a href="/web/vpn/DTAC/DTAC-TH-PC1-LIFESTYLE.ovpn" class="btn btn-info">DTAC</a><b></b></b></td>
</tr>
<td><b> TH-PC2-LIFESTYLE </b></td> 
<td><b><a href="/web/vpn/TRUE/TRUE-TH-PC2-LIFESTYLE.ovpn" class="btn btn-danger">TRUE</a><b></b></b></td>
<td><b><a href="/web/vpn/DTAC/DTAC-TH-PC2-LIFESTYLE.ovpn" class="btn btn-info">DTAC</a><b></b></b></td>
</tr>
<!--td><b> เซิร์ฟเวอร์ SG เทสฟรี </b></td>
<td><b><a href="/web/vpn/TRUE/TestSG-True.ovpn" class="btn btn-danger">TRUE</a><b></b></b></td>
<td><b><a href="/web/vpn/DTAC/TestSG-Dtac.ovpn" class="btn btn-info">DTAC</a><b></b></b></td>
</tr>	 
<td><b> เซิร์ฟเวอร์ TH Best IDC</b></td>
<td><b><a href="/web/vpn/TRUE/TestTH-True.ovpn" class="btn btn-danger">TRUE</a><b></b></b></td>
<td><b><a href="/web/vpn/DTAC/TestTH-Dtac.ovpn" class="btn btn-info">DTAC</a><b></b></b></td>
</tr!-->	
		 
</tbody>
</table>
</div>
</ul>
</div>
       
                        <!--center>
                        <tr>
                        <td><span class="description-text"><span style="font-size: 16px;"  class="badge bg-green"><i class="fa fa-cloud-download"></i> ชื่อเซิร์ฟเวอร์  </span></td>
						<td>   
                        <span class="description-text"><span style="font-size: 16px;"  class="badge bg-green"> <i class="fa fa-cloud-download"></i> ไฟล์ซิมทรูมูฟ </span></td></td>              
                        </tr>
						
						
						
						
						
                        <tr>
                            
<td><b>SG-1-LIFESTYLE</b></td><td><b><a href="/web/vpn/TRUE/TRUE-SG-1-LIFESTYLE-VPN.ovpn " class="btn btn-sm btn-danger"><i class="fa fa-send"></i> True VPN</a><b></td><td><b></a><b></td>
                        </tr>
                        <tr>
<td><b>TH-VIP3-LIFESTYLE</b></td><td><b><a href="/web/vpn/TRUE/TRUE-TH-VIP3-LIFESTYLE-VPN.ovpn" class="btn btn-sm btn-danger"><i class="fa fa-send"></i> True VPN</a><b></td><td><b>
                        </tr>
<td><b>TH-VIP5-LIFESTYLE</b></td><td><b><a href="/web/vpn/TRUE/TRUE-TH-VIP5-LIFESTYLE-VPN.ovpn " class="btn btn-sm btn-danger"><i class="fa fa-send"></i> True VPN</a><b></td><td><b></a><b></td>
                        </tr>
<td><b>TH-PC1-LIFESTYLE</b></td><td><b><a href="/web/vpn/TRUE/TRUE-TH-PC1-LIFESTYLE-VPN.ovpn" class="btn btn-sm btn-danger"><i class="fa fa-send"></i> True VPN</a><b></td><td><b></a><b></td>
                        </tr>
<td><b> เซิร์ฟเวอร์เทสฟรี </b></td><td><b><a href="/web/vpn/TRUE/TRUE-TEST.ovpn" class="btn btn-sm btn-danger"><i class="fa fa-send"></i> True VPN</a><b></td><td><b></a><b></td>
                        </tr>
						
						
						
						
						
<tr>


                        <td><span class="description-text"><span style="font-size: 16px;"  class="badge bg-green"><i class="fa fa-cloud-download"></i> ชื่อเซิร์ฟเวอร์  </span></td>
						<td>   
                        <span class="description-text"><span style="font-size: 16px;"  class="badge bg-green"> <i class="fa fa-cloud-download"></i> ไฟล์ซิมดีแทค </span></td></td>              
                        </tr>
						
						
<td><b>SG-1-LIFESTYLE</b></td><td><b><a href="/web/vpn/DTAC/DTAC-SG-1-LIFESTYLE-VPN.ovpn " class="btn btn-sm btn-info"><i class="fa fa-send"></i> Dtac VPN</a><b></td><td><b></a><b></td>
                        </tr>
                        <tr>
<td><b>TH-VIP3-LIFESTYLE</b></td><td><b><a href="/web/vpn/DTAC/DTAC-TH-VIP3-LIFESTYLE-VPN.ovpn" class="btn btn-sm btn-info"><i class="fa fa-send"></i> Dtac VPN</a><b></td><td><b>
                        </tr>
<td><b>TH-VIP5-LIFESTYLE</b></td><td><b><a href="/web/vpn/DTAC/DTAC-TH-VIP5-LIFESTYLE-VPN.ovpn " class="btn btn-sm btn-info"><i class="fa fa-send"></i> Dtac VPN</a><b></td><td><b></a><b></td>
                        </tr>
<td><b>TH-PC1-LIFESTYLE</b></td><td><b><a href="/web/vpn/DTAC/DTAC-TH-PC1-LIFESTYLE-VPN.ovpn" class="btn btn-sm btn-info"><i class="fa fa-send"></i> Dtac VPN</a><b></td><td><b></a><b></td>
                        </tr>
<td><b> เซิร์ฟเวอร์เทสฟรี </b></td><td><b><a href="/web/vpn/DTAC/DTAC-TEST.ovpn" class="btn btn-sm btn-info"><i class="fa fa-send"></i> True VPN</a><b></td><td><b></a><b></td>
                        </tr--->

						      </center> 
                   	    </table>
        			  </div>
        			</ul>
				  </div>
 	        </div>
 		
 
       </section>      
  </div>