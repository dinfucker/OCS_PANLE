<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
       เซิร์ฟเวอร์ทั้ง VPN SSH
      </h1>
    <ol class="breadcrumb">
        <li><a href="/"><i class="fa fa-dashboard"></i> หน้าหลัก</a></li>
        <li class="active">เซิร์ฟเวอร์ทั้งหมด</li>
    </ol>
    </section><br>
	
    		<div class="row">
			<?php if (isset($message)) {echo $message; }?>   
		</div>
		

<div class="col-sm-12"> 
<div class="info-box bg-info"style="background: url('<?php echo  base_url('asset/img/b2.jpeg') ?>') center center;">
<span class="info-box-icon"><i class="fa fa-ge"></i></span>
<div class="info-box-content">
<span class="info-box-number">ยอดเงินคงเหลือ » <span style="font-size: 16px;" class="info-box-number pull-right badge bg-blue"><?= $user -> saldo ?> บาท</span>
<span class="info-box-number">ชื่อบัญชี » <span style="font-size: 16px;" class="info-box-number pull-right badge bg-blue"><?php echo  $user->username ?></span></span>
<div class="progress">
<div class="progress-bar" style="width: 0%"></div>
</div>
<span class="progress-description">
<a href="<?= base_url('main/'.$_SESSION['username'].'/topups') ?>">เติมเงิน <i class="fa fa-arrow-circle-right"></i></a>
</span>
</div>
</div>
</div>

		<div class="row">
		<?php if (isset($message)) {echo $message; }?>   
		</div><br>
		
        <?php foreach($server as $row): ?>
		 
       <div class="col-sm-6 col-md-6 col-lg-6">    
       <div class="box box-widget widget-user">
		
           <div class="widget-user-header bg-black" style="background: url('<?php echo  base_url('asset/img/B/B4.jpg') ?>') center center;">
		   <h3 class="widget-user-username"><b><?php echo  $row['ServerName']?></span><B></h3>
       
              <h4 class="widget-user-desc"><B><?php echo  $row['Expired']?> วัน <?php echo  $row['Price']?> บาท <B></h4>
			  <span style="font-size: 16px;" class="badge bg-navy"><?php if ($row['Status']) { echo 'ว่าง';} else {echo "เซิร์ฟเวอร์เต็ม";}?></span>
             <!--span style="font-size: 16px;"  class="badge bg-navy"> <?php if ($row['Status']) { echo '';} else {echo "เซิร์ฟเวอร์เต็ม";}?></span-->
            </div>  
            <div class="widget-user-image">
              <img class="img-circle" src="<?php echo  base_url('asset/img/i5.png') ?>" alt="User Avatar">
            </div>
                  
       <div class="box-footer no-padding">
      	<div class="description-block"><br><br>
            <span class="description-text"><span style="font-size: 16px;"  class="badge bg-red">รายละเอียดเซิร์ฟเวอร์</span></span>
         </div>
         
              <ul class="nav nav-stacked">
                <li><a href="#"><B> เซิร์ฟเวอร์ </B><span class="pull-right">IP HOST</span></a></li>
                <li><a href="#"><span style="font-size: 16px;" class="badge bg-aqua"><?php echo  $row['Location']?></span> <span style="font-size: 16px;" class="pull-right badge bg-purple">แสดงเมื่อเช่าแล้ว</span></a></li>
                
                <li><a href="#"> PORT <span class="pull-right">จำกัดการเชื่อมต่อ</span></a></li>
                <li><a href="#"><span style="font-size: 16px;" class="badge bg-maroon"><?php echo  $row['OpenSSH']?>, <?php echo  $row['Dropbear']?></span><span style="font-size: 16px;" class="pull-right badge bg-navy"> VPN <?php echo  $row['limitvpn']?> เครื่อง <!--?php echo  $row['limitssh']?--></span></a></li>
                
                <li><a href="#"> วันใช้งาน <span class="pull-right"> จำกัด </span></a></li>
                <li><a href="#"><span style="font-size: 16px;" class="badge bg-purple"><?php echo  $row['Expired']?> วัน </span><span style="font-size: 16px;" class="pull-right badge bg-blue">20<!--?php echo  $row['MaxUser']?--> คน/วัน </span></a></li>
                
                <li><a href="#"> ราคา <span class="pull-right"> สถานะเซิร์ฟเวอร์ </span></a></li>
                <li><a href="#"><span style="font-size: 16px;" class="badge bg-green"><?php echo  $row['Price']?> บาท </span><span style="font-size: 16px;" class="pull-right badge bg-orange"> <?php if ($row['Status']) { echo 'ออนไลน์';} else {echo "เซิร์ฟเวอร์เต็ม";}?></span></a></li>
                
              </ul>
            </div>
						 
                    <div class="box-footer text-center">
                    	<button class="btn btn-sm btn-primary" data-toggle="modal" data-target="#<?php echo  $row['Id']?>"><i class="fa fa-shopping-cart"></i>
  เช่าเซิร์ฟเวอร์
						</button>
                        
                        <a href=" <?php echo  base_url('main/'.$_SESSION['username'].'/config')?>" class="btn btn-sm btn-warning"><i class="fa fa-cloud-download"></i> โหลดไฟล์ VPN</a>
                        <!---a href="<?php echo  base_url('web/http/'.str_replace(' ','-',$row['configssh']).' ') ?>" class="btn btn-sm btn-info"><i class="fa fa-cloud-upload"></i>???? SSH</a-->
                    </div>
                                        
<div class="modal fade" id="<?php echo  $row['Id']?>" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
        <h4 class="modal-title" id="myModalLabel">ข้อครวจำ!!!</h4>
      </div>
      <div class="modal-body">
        ไฟล์ VPN สามารถต่อได้ 1 เครื่องต่อไฟล์ กรุณาใช้ไฟล์ให้ถูกการใช้งาน เพื่อไม่ให้ส่งผลกระทบต่อลูกค้าท่านอื่น ถ้าพบเห็นการใช้งานที่ผิดปกติแอดมินสามารถระงับการใช้งาน ได้โดยไม่แจ้งล่วงหน้าครับผม
      </div>
      <div class="modal-footer">
        <a href="<?php echo  base_url('main/seller/'.$_SESSION['username'].'/buy/'.str_replace(' ','-',$row['ServerName']).'/'.$row['Id']) ?>" class="btn btn-info"><i class="fa fa-shopping-cart fa-fw"></i>ยืนยันการเช่า</a>
        <button type="button" class="btn btn-danger btn-simple" data-dismiss="modal">ยกเลิก</button>
      </div>
    </div>
  </div>
</div>
                    
                    
                    
                </div>
            </div>
        <?php endforeach; ?>
    </div>     
    </section>
</div>