<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>
  <div class="content-wrapper">
    <section class="content-header">
      <h1>
      ระบบเติมเงิน อัตโนมัติ
      </h1>
    <ol class="breadcrumb">
        <li><a href="/home"><i class="fa fa-dashboard"></i> หน้าหลัก</a></li>
        <li class="active">เติมเงิน</li>
    </ol>
    </section>
<br>
		<div class="row">
			<?php if (isset($message)) {echo $message; }?>   
		</div>
   
    <!-- Main content -->
    <section class="content">
        
	<div class="row">
<div class="col-md-12">
<div class="box box-widget widget-user">
<div class="widget-user-header bg-black" style="background: url('<?php echo  base_url('asset/img/6.png') ?>') center center;">

<span class="info-box-number">ยอดเงินคงเหลือ » <span style="font-size: 16px;" class="info-box-number pull-right badge bg-blue"><?= $user -> saldo ?> บาท</span>
<span class="info-box-number">ชื่อบัญชี » <span style="font-size: 16px;" class="info-box-number pull-right badge bg-blue"><?php echo  $user->username ?></span></span>

</b></div><b>
<div class="widget-user-image">
<img class="img-circle" src="https://upload.wikimedia.org/wikipedia/commons/5/50/Bitcoin.png" alt="User Avatar">
</div>
             
             <div class="box-body text-center">
                    <table class="table">
                    <tr><br><br>
<!--br><center><img src="<?php echo  base_url('asset/img/twallet.png') ?>"><br></center> <br-->
                    <form action="/topup/input.php" method="post">
						
							<input name="user" type="hidden" value="<?php echo  $user->username ?>" id="user">
					<small class="text-muted" style="font-size: 16px;">เติมเท่าไหร่ก้อได้ ไม่มีขั้นต่ำ</small><p>
					
					
    <h4><b>ชื่อบัญชี wallet</b></h4>
	<span style="font-size: 18px;" class="badge bg-purple">จตุรพร สุริยา</span><br>
					
	<h4><b>เบอร์ WALLET</b></h4>
									<?php foreach ($this->user_model->view_asset() as $row): ?>
									<?php if (!empty($row['nohp'])): ?>
									<span style="font-size: 18px;" class="badge bg-purple"><?php echo  $row['nohp']?></span><br> 
									<?php endif; ?>					
			  					 <?php endforeach; ?>

					  <div class="form-group text-center">	 
			 			<button type="submit" class="btn btn-success btn-block btn-main btn-round">ยืนยันเลขอ้างอิง</button>         				
						<label class="label label-danger" style="font-size: 14px;">อยากเติมเท่าไหร่ก้อเติม เอาที่สบายใจ</label>
								 
                        </tr>
                    </table>
                  </div>
             </form>
		</div>      
       
	</div>                
 </section>  
</div>