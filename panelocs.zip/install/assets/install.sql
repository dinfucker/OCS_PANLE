-- phpMyAdmin SQL Dump
-- version 3.4.11.1deb2+deb7u8
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Apr 18, 2018 at 08:37 AM
-- Server version: 5.5.59
-- PHP Version: 5.4.45-0+deb7u13

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `OCS_PANEL`
--

-- --------------------------------------------------------

--
-- Table structure for table `asset`
--

CREATE TABLE IF NOT EXISTS `asset` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `rekening` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `bank` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `pemilik` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `nohp` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `provider` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `webname` varchar(50) CHARACTER SET utf8 DEFAULT NULL COMMENT 'LNWSEED',
  `fbchat` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `fbface` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `fbgroup` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=72 ;

--
-- Dumping data for table `asset`
--

INSERT INTO `asset` (`id`, `rekening`, `bank`, `pemilik`, `nohp`, `provider`, `webname`, `fbchat`, `fbface`, `fbgroup`) VALUES
(66, NULL, NULL, NULL, NULL, NULL, 'MEMBER I VIP', NULL, NULL, NULL),
(71, NULL, NULL, NULL, NULL, NULL, '', 'https://www.m.me/100013163170272', 'https://www.facebook.com/100013163170272', 'https://www.facebook.com/100013163170272');

-- --------------------------------------------------------

--
-- Table structure for table `ci_sessions`
--

CREATE TABLE IF NOT EXISTS `ci_sessions` (
  `id` varchar(40) CHARACTER SET utf8 NOT NULL,
  `ip_address` varchar(45) CHARACTER SET utf8 NOT NULL,
  `timestamp` int(10) unsigned NOT NULL DEFAULT '0',
  `data` blob NOT NULL,
  PRIMARY KEY (`id`),
  KEY `ci_sessions_timestamp` (`timestamp`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `continent`
--

CREATE TABLE IF NOT EXISTS `continent` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `Name` varchar(20) CHARACTER SET utf8 DEFAULT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

--
-- Dumping data for table `continent`
--

INSERT INTO `continent` (`Id`, `Name`) VALUES
(1, 'Asia'),
(2, 'North America'),
(3, 'Europe'),
(4, 'South America'),
(5, 'Africa'),
(6, 'Oceania');

-- --------------------------------------------------------

--
-- Table structure for table `country`
--

CREATE TABLE IF NOT EXISTS `country` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `Name` varchar(20) CHARACTER SET utf8 DEFAULT NULL,
  `Country` varchar(20) CHARACTER SET utf8 DEFAULT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=17 ;

--
-- Dumping data for table `country`
--

INSERT INTO `country` (`Id`, `Name`, `Country`) VALUES
(1, 'Asia', 'Singapore'),
(2, 'Asia', 'Thailand'),
(3, 'Asia', 'Japan'),
(4, 'Asia', 'Hongkong'),
(5, 'Europe', 'Netherlands'),
(6, 'Europe', 'Germani'),
(7, 'Europe', 'France'),
(8, 'Europe', 'Luxembourg'),
(9, 'North-America', 'NY-USA'),
(10, 'North-America', 'Canada'),
(11, 'North-America', 'LA-USA'),
(12, 'South-America', 'NY-USA'),
(14, 'Africa', 'Johanesburg'),
(15, 'Oceania', 'Australia'),
(16, 'North-America', 'Austria');

-- --------------------------------------------------------

--
-- Table structure for table `deposit`
--

CREATE TABLE IF NOT EXISTS `deposit` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userid` int(11) NOT NULL,
  `pesan` text CHARACTER SET utf8 NOT NULL,
  `is_confirmed` tinyint(1) NOT NULL DEFAULT '0',
  `jumlah` int(11) DEFAULT NULL,
  `created_at` date NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `histrory`
--

CREATE TABLE IF NOT EXISTS `histrory` (
  `money` float NOT NULL,
  `username` varchar(255) NOT NULL,
  `status` int(11) NOT NULL,
  `id` int(11) NOT NULL,
  `NumberWallet` varchar(14) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `server`
--

CREATE TABLE IF NOT EXISTS `server` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `HostName` varchar(23) CHARACTER SET utf8 DEFAULT NULL,
  `RootPasswd` varchar(25) CHARACTER SET utf8 NOT NULL,
  `MaxUser` int(11) NOT NULL DEFAULT '50',
  `Expired` int(11) NOT NULL DEFAULT '7',
  `ServerName` varchar(20) CHARACTER SET utf8 DEFAULT NULL,
  `Location` varchar(20) CHARACTER SET utf8 DEFAULT NULL,
  `OpenSSH` varchar(20) CHARACTER SET utf8 NOT NULL DEFAULT '22',
  `Dropbear` varchar(20) CHARACTER SET utf8 NOT NULL DEFAULT '443',
  `Price` int(10) DEFAULT '10',
  `Status` int(11) NOT NULL DEFAULT '1',
  `limitssh` varchar(20) CHARACTER SET utf8 NOT NULL DEFAULT '2',
  `limitvpn` varchar(20) CHARACTER SET utf8 NOT NULL DEFAULT '1',
  `configssh` varchar(255) CHARACTER SET utf8 NOT NULL DEFAULT '.ehi',
  `configvpn` varchar(255) CHARACTER SET utf8 NOT NULL DEFAULT '.ovpn',
  PRIMARY KEY (`Id`)
) ENGINE=MyISAM  DEFAULT CHARSET=tis620 AUTO_INCREMENT=42 ;

-- --------------------------------------------------------

--
-- Table structure for table `sshuser`
--

CREATE TABLE IF NOT EXISTS `sshuser` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) CHARACTER SET utf8 NOT NULL,
  `hostname` varchar(20) CHARACTER SET utf8 NOT NULL,
  `created_by` varchar(20) CHARACTER SET utf8 NOT NULL,
  `created_at` date NOT NULL,
  `expired_at` int(11) NOT NULL DEFAULT '30',
  `serverid` int(11) NOT NULL,
  `price` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=667 ;

-- --------------------------------------------------------

--
-- Table structure for table `userlimit`
--

CREATE TABLE IF NOT EXISTS `userlimit` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `Hostname` varchar(23) CHARACTER SET utf8 DEFAULT NULL,
  `Counter` int(11) DEFAULT NULL,
  `Date` date DEFAULT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `username` varchar(255) CHARACTER SET utf8 NOT NULL DEFAULT '',
  `email` varchar(255) CHARACTER SET utf8 NOT NULL DEFAULT '',
  `password` varchar(255) CHARACTER SET utf8 NOT NULL DEFAULT '',
  `avatar` varchar(255) CHARACTER SET utf8 DEFAULT 'default.jpg',
  `saldo` int(11) NOT NULL DEFAULT '0',
  `created_at` datetime NOT NULL,
  `is_admin` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `is_confirmed` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `active` int(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=677 ;

-- --------------------------------------------------------

--
-- Table structure for table `website`
--

CREATE TABLE IF NOT EXISTS `website` (
  `brand` varchar(20) CHARACTER SET utf8 NOT NULL DEFAULT 'lnw-service',
  `author` varchar(20) CHARACTER SET utf8 NOT NULL,
  `title` text CHARACTER SET utf8,
  `description` text CHARACTER SET utf8 NOT NULL,
  `keyword` text CHARACTER SET utf8 NOT NULL,
  PRIMARY KEY (`brand`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
