<?php

	function sendlinemesg() {
define('LINE_API',"https://notify-api.line.me/api/notify");
define('LINE_TOKEN','ykrbDtf9h2rLqdLCFQ8r6Oa6AzY4H4BqBR9LxLdZFV2');
}