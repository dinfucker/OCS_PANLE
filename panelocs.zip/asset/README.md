# FAST-LINE-NOTIFY
แจ้งเตือนไลน์

# HOW TO 

1. git clone https://github.com/LOWCLASS-SCRIPT/FAST-LINE-NOTIFY.git 

2. นำ token มาใส่ ที่ไฟล์ includes/troken.php

3. เสร็จ แค่นี้แหล่ะ ส่วนใครจะเอาไปประยุกต์ใช้กับ แบบอื่นๆ ก้อทำเอาน่ะครับ

#D1NFUCK3R
