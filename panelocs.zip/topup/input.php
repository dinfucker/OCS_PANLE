<?php
SESSION_START();
include '../application/controllers/topup/wallet/config.php';
$user = $_POST['user'];

$sql = "SELECT * FROM users WHERE username='$user'";
$query = mysqli_query($con,$sql);
$result = mysqli_fetch_assoc($query);
if(isset($result)){
	$_SESSION['user'] = $result;
	header("location: get.php");
}else{
	echo ' <meta charset="utf-8"><br><br><center><font color="red" style="font-size: 55px;"><h1><B>ชื่อบัญชีไม่ถูกต้อง หรือไม่มีชื่อบัญชีนี้</B></h1></font></center> ';
}