﻿<?php
SESSION_START();
include '../application/controllers/topup/wallet/config.php';

if($wallet->login($username,$password)){

	$profile = $wallet->get_profile();
	$transaction = $wallet->get_transactions();
	
	for($i = 0;$i < 20;$i++){

			$report = $wallet->get_report($transaction[$i]->reportID);
			$checkid = $report->section4->column2->cell1->value;
			$money = $report->section3->column1->cell1->value;
			
			if($walletmoney == $checkid && $money == 10){
				$sql = "select * from users where username='".$_SESSION['user']['username']."'";
				$sqle = "SELECT * FROM histrory WHERE NumberWallet='$walletmoney'";
				$query = mysqli_query($con,$sqle);
				$result = mysqli_fetch_assoc($query);
				// ถ้า status กับเลขที่อ้างอิง ไม่มี
				if($result['status'] == ''){
					echo "<center><B style='font-size: 60px;'><h1 style='color:green'>เติมเงินเรียบร้อย</h1>
					<h1>จำนวนเงิน ที่คุณเติมคือ $money บาท</h1>
					<h1>ขอบคุณที่ใช้บริการครับ !</h1></B>  
					<p><a href='/main'>[ไปเช่าเน็ตกันเถอะ]</a> </p></center>";
					$sql = "insert into histrory (NumberWallet,money,username,status) values ('$walletmoney','$money','".$_SESSION['user']['username']."',1)";
					mysqli_query($con,$sql);
					$sql1 = "insert into users (saldo) values ('$money') where username='".$_SESSION['user']['username']."'";
					$sql1 = "update users set saldo=saldo+'".$money."'where username='".$_SESSION['user']['username']."'";
					mysqli_query($con,$sql1) or die; ('Error Query');
				}else{
					echo "<center><B style='color:red'><h1 style='font-size: 80px;'>เกิดข้อผิดพลาด</h1>
		<h1 style='font-size: 80px;'>หมายเลขอ้างอิงนี้</h1>
		<h1 style='font-size: 80px;'>ถูกใช้งานแล้ว</h1></B>
		<p><a href='/topup/get.php'>[กลับไปลองอีกครั้ง]</a> </p></center>";
				}
				break;
				}else if($walletmoney == $checkid && $money == 2){
				$sql = "select * from users where username='".$_SESSION['user']['username']."'";
				$sqle = "SELECT * FROM histrory WHERE NumberWallet='$walletmoney'";
				$query = mysqli_query($con,$sqle);
				$result = mysqli_fetch_assoc($query);
				if($result['status'] == ''){
					echo "<center><B style='font-size: 60px;'><h1 style='color:green'>เติมเงินเรียบร้อย</h1>
					<h1>จำนวนเงิน ที่คุณเติมคือ $money บาท</h1>
					<h1>ขอบคุณที่ใช้บริการครับ !</h1></B>  
					<p><a href='/main'>[ไปเช่าเน็ตกันเถอะ]</a> </p></center>";
					$sql = "insert into histrory (NumberWallet,money,username,status) values ('$walletmoney','$money','".$_SESSION['user']['username']."',1)";
					mysqli_query($con,$sql);
					$sql1 = "insert into users (saldo) values ('$money') where username='".$_SESSION['user']['username']."'";
					$sql1 = "update users set saldo=saldo+'".$money."'where username='".$_SESSION['user']['username']."'";
					mysqli_query($con,$sql1) or die; ('Error Query');
				}else{
					echo "<center><B style='color:red'><h1 style='font-size: 80px;'>เกิดข้อผิดพลาด</h1>
		<h1 style='font-size: 80px;'>หมายเลขอ้างอิงนี้</h1>
		<h1 style='font-size: 80px;'>ถูกใช้งานแล้ว</h1></B>
		<p><a href='/topup/get.php'>[กลับไปลองอีกครั้ง]</a> </p></center>";
				}
				break;
				}else if($walletmoney == $checkid && $money == 3){
				$sql = "select * from users where username='".$_SESSION['user']['username']."'";
				$sqle = "SELECT * FROM histrory WHERE NumberWallet='$walletmoney'";
				$query = mysqli_query($con,$sqle);
				$result = mysqli_fetch_assoc($query);
				if($result['status'] == ''){
					echo "<center><B style='font-size: 60px;'><h1 style='color:green'>เติมเงินเรียบร้อย</h1>
					<h1>จำนวนเงิน ที่คุณเติมคือ $money บาท</h1>
					<h1>ขอบคุณที่ใช้บริการครับ !</h1></B>  
					<p><a href='/main'>[ไปเช่าเน็ตกันเถอะ]</a> </p></center>";
					$sql = "insert into histrory (NumberWallet,money,username,status) values ('$walletmoney','$money','".$_SESSION['user']['username']."',1)";
					mysqli_query($con,$sql);
					$sql1 = "insert into users (saldo) values ('$money') where username='".$_SESSION['user']['username']."'";
					$sql1 = "update users set saldo=saldo+'".$money."'where username='".$_SESSION['user']['username']."'";
					mysqli_query($con,$sql1) or die; ('Error Query');
				}else{
					echo "<center><B style='color:red'><h1 style='font-size: 80px;'>เกิดข้อผิดพลาด</h1>
		<h1 style='font-size: 80px;'>หมายเลขอ้างอิงนี้</h1>
		<h1 style='font-size: 80px;'>ถูกใช้งานแล้ว</h1></B>
		<p><a href='/topup/get.php'>[กลับไปลองอีกครั้ง]</a> </p></center>";
				}
				break;
				}else if($walletmoney == $checkid && $money == 4){
				$sql = "select * from users where username='".$_SESSION['user']['username']."'";
				$sqle = "SELECT * FROM histrory WHERE NumberWallet='$walletmoney'";
				$query = mysqli_query($con,$sqle);
				$result = mysqli_fetch_assoc($query);
				if($result['status'] == ''){
					echo "<center><B style='font-size: 60px;'><h1 style='color:green'>เติมเงินเรียบร้อย</h1>
					<h1>จำนวนเงิน ที่คุณเติมคือ $money บาท</h1>
					<h1>ขอบคุณที่ใช้บริการครับ !</h1></B>  
					<p><a href='/main'>[ไปเช่าเน็ตกันเถอะ]</a> </p></center>";
					$sql = "insert into histrory (NumberWallet,money,username,status) values ('$walletmoney','$money','".$_SESSION['user']['username']."',1)";
					mysqli_query($con,$sql);
					$sql1 = "insert into users (saldo) values ('$money') where username='".$_SESSION['user']['username']."'";
					$sql1 = "update users set saldo=saldo+'".$money."'where username='".$_SESSION['user']['username']."'";
					mysqli_query($con,$sql1) or die; ('Error Query');
				}else{
					echo "<center><B style='color:red'><h1 style='font-size: 80px;'>เกิดข้อผิดพลาด</h1>
		<h1 style='font-size: 80px;'>หมายเลขอ้างอิงนี้</h1>
		<h1 style='font-size: 80px;'>ถูกใช้งานแล้ว</h1></B>
		<p><a href='/topup/get.php'>[กลับไปลองอีกครั้ง]</a> </p></center>";
				}
				break;
				}else if($walletmoney == $checkid && $money == 5){
				$sql = "select * from users where username='".$_SESSION['user']['username']."'";
				$sqle = "SELECT * FROM histrory WHERE NumberWallet='$walletmoney'";
				$query = mysqli_query($con,$sqle);
				$result = mysqli_fetch_assoc($query);
				if($result['status'] == ''){
					echo "<center><B style='font-size: 60px;'><h1 style='color:green'>เติมเงินเรียบร้อย</h1>
					<h1>จำนวนเงิน ที่คุณเติมคือ $money บาท</h1>
					<h1>ขอบคุณที่ใช้บริการครับ !</h1></B>  
					<p><a href='/main'>[ไปเช่าเน็ตกันเถอะ]</a> </p></center>";
					$sql = "insert into histrory (NumberWallet,money,username,status) values ('$walletmoney','$money','".$_SESSION['user']['username']."',1)";
					mysqli_query($con,$sql);
					$sql1 = "insert into users (saldo) values ('$money') where username='".$_SESSION['user']['username']."'";
					$sql1 = "update users set saldo=saldo+'".$money."'where username='".$_SESSION['user']['username']."'";
					mysqli_query($con,$sql1) or die; ('Error Query');
				}else{
					echo "<center><B style='color:red'><h1 style='font-size: 80px;'>เกิดข้อผิดพลาด</h1>
		<h1 style='font-size: 80px;'>หมายเลขอ้างอิงนี้</h1>
		<h1 style='font-size: 80px;'>ถูกใช้งานแล้ว</h1></B>
		<p><a href='/topup/get.php'>[กลับไปลองอีกครั้ง]</a> </p></center>";
				}
				break;
				}else if($walletmoney == $checkid && $money == 6){
				$sql = "select * from users where username='".$_SESSION['user']['username']."'";
				$sqle = "SELECT * FROM histrory WHERE NumberWallet='$walletmoney'";
				$query = mysqli_query($con,$sqle);
				$result = mysqli_fetch_assoc($query);
				if($result['status'] == ''){
					echo "<center><B style='font-size: 60px;'><h1 style='color:green'>เติมเงินเรียบร้อย</h1>
					<h1>จำนวนเงิน ที่คุณเติมคือ $money บาท</h1>
					<h1>ขอบคุณที่ใช้บริการครับ !</h1></B>  
					<p><a href='/main'>[ไปเช่าเน็ตกันเถอะ]</a> </p></center>";
					$sql = "insert into histrory (NumberWallet,money,username,status) values ('$walletmoney','$money','".$_SESSION['user']['username']."',1)";
					mysqli_query($con,$sql);
					$sql1 = "insert into users (saldo) values ('$money') where username='".$_SESSION['user']['username']."'";
					$sql1 = "update users set saldo=saldo+'".$money."'where username='".$_SESSION['user']['username']."'";
					mysqli_query($con,$sql1) or die; ('Error Query');
				}else{
					echo "<center><B style='color:red'><h1 style='font-size: 80px;'>เกิดข้อผิดพลาด</h1>
		<h1 style='font-size: 80px;'>หมายเลขอ้างอิงนี้</h1>
		<h1 style='font-size: 80px;'>ถูกใช้งานแล้ว</h1></B>
		<p><a href='/topup/get.php'>[กลับไปลองอีกครั้ง]</a> </p></center>";
				}
				break;
				}else if($walletmoney == $checkid && $money == 7){
				$sql = "select * from users where username='".$_SESSION['user']['username']."'";
				$sqle = "SELECT * FROM histrory WHERE NumberWallet='$walletmoney'";
				$query = mysqli_query($con,$sqle);
				$result = mysqli_fetch_assoc($query);
				if($result['status'] == ''){
					echo "<center><B style='font-size: 60px;'><h1 style='color:green'>เติมเงินเรียบร้อย</h1>
					<h1>จำนวนเงิน ที่คุณเติมคือ $money บาท</h1>
					<h1>ขอบคุณที่ใช้บริการครับ !</h1></B>  
					<p><a href='/main'>[ไปเช่าเน็ตกันเถอะ]</a> </p></center>";
					$sql = "insert into histrory (NumberWallet,money,username,status) values ('$walletmoney','$money','".$_SESSION['user']['username']."',1)";
					mysqli_query($con,$sql);
					$sql1 = "insert into users (saldo) values ('$money') where username='".$_SESSION['user']['username']."'";
					$sql1 = "update users set saldo=saldo+'".$money."'where username='".$_SESSION['user']['username']."'";
					mysqli_query($con,$sql1) or die; ('Error Query');
				}else{
					echo "<center><B style='color:red'><h1 style='font-size: 80px;'>เกิดข้อผิดพลาด</h1>
		<h1 style='font-size: 80px;'>หมายเลขอ้างอิงนี้</h1>
		<h1 style='font-size: 80px;'>ถูกใช้งานแล้ว</h1></B>
		<p><a href='/topup/get.php'>[กลับไปลองอีกครั้ง]</a> </p></center>";
				}
				break;
				}else if($walletmoney == $checkid && $money == 8){
				$sql = "select * from users where username='".$_SESSION['user']['username']."'";
				$sqle = "SELECT * FROM histrory WHERE NumberWallet='$walletmoney'";
				$query = mysqli_query($con,$sqle);
				$result = mysqli_fetch_assoc($query);
				if($result['status'] == ''){
					echo "<center><B style='font-size: 60px;'><h1 style='color:green'>เติมเงินเรียบร้อย</h1>
					<h1>จำนวนเงิน ที่คุณเติมคือ $money บาท</h1>
					<h1>ขอบคุณที่ใช้บริการครับ !</h1></B>  
					<p><a href='/main'>[ไปเช่าเน็ตกันเถอะ]</a> </p></center>";
					$sql = "insert into histrory (NumberWallet,money,username,status) values ('$walletmoney','$money','".$_SESSION['user']['username']."',1)";
					mysqli_query($con,$sql);
					$sql1 = "insert into users (saldo) values ('$money') where username='".$_SESSION['user']['username']."'";
					$sql1 = "update users set saldo=saldo+'".$money."'where username='".$_SESSION['user']['username']."'";
					mysqli_query($con,$sql1) or die; ('Error Query');
				}else{
					echo "<center><B style='color:red'><h1 style='font-size: 80px;'>เกิดข้อผิดพลาด</h1>
		<h1 style='font-size: 80px;'>หมายเลขอ้างอิงนี้</h1>
		<h1 style='font-size: 80px;'>ถูกใช้งานแล้ว</h1></B>
		<p><a href='/topup/get.php'>[กลับไปลองอีกครั้ง]</a> </p></center>";
				}
				break;
				}else if($walletmoney == $checkid && $money == 9){
				$sql = "select * from users where username='".$_SESSION['user']['username']."'";
				$sqle = "SELECT * FROM histrory WHERE NumberWallet='$walletmoney'";
				$query = mysqli_query($con,$sqle);
				$result = mysqli_fetch_assoc($query);
				if($result['status'] == ''){
					echo "<center><B style='font-size: 60px;'><h1 style='color:green'>เติมเงินเรียบร้อย</h1>
					<h1>จำนวนเงิน ที่คุณเติมคือ $money บาท</h1>
					<h1>ขอบคุณที่ใช้บริการครับ !</h1></B>  
					<p><a href='/main'>[ไปเช่าเน็ตกันเถอะ]</a> </p></center>";
					$sql = "insert into histrory (NumberWallet,money,username,status) values ('$walletmoney','$money','".$_SESSION['user']['username']."',1)";
					mysqli_query($con,$sql);
					$sql1 = "insert into users (saldo) values ('$money') where username='".$_SESSION['user']['username']."'";
					$sql1 = "update users set saldo=saldo+'".$money."'where username='".$_SESSION['user']['username']."'";
					mysqli_query($con,$sql1) or die; ('Error Query');
				}else{
					echo "<center><B style='color:red'><h1 style='font-size: 80px;'>เกิดข้อผิดพลาด</h1>
		<h1 style='font-size: 80px;'>หมายเลขอ้างอิงนี้</h1>
		<h1 style='font-size: 80px;'>ถูกใช้งานแล้ว</h1></B>
		<p><a href='/topup/get.php'>[กลับไปลองอีกครั้ง]</a> </p></center>";
				}
				break;
				}else if($walletmoney == $checkid && $money == 1){
				$sql = "select * from users where username='".$_SESSION['user']['username']."'";
				$sqle = "SELECT * FROM histrory WHERE NumberWallet='$walletmoney'";
				$query = mysqli_query($con,$sqle);
				$result = mysqli_fetch_assoc($query);
				if($result['status'] == ''){
					echo "<center><B style='font-size: 60px;'><h1 style='color:green'>เติมเงินเรียบร้อย</h1>
					<h1>จำนวนเงิน ที่คุณเติมคือ $money บาท</h1>
					<h1>ขอบคุณที่ใช้บริการครับ !</h1></B>  
					<p><a href='/main'>[ไปเช่าเน็ตกันเถอะ]</a> </p></center>";
					$sql = "insert into histrory (NumberWallet,money,username,status) values ('$walletmoney','$money','".$_SESSION['user']['username']."',1)";
					mysqli_query($con,$sql);
					$sql1 = "insert into users (saldo) values ('$money') where username='".$_SESSION['user']['username']."'";
					$sql1 = "update users set saldo=saldo+'".$money."'where username='".$_SESSION['user']['username']."'";
					mysqli_query($con,$sql1) or die; ('Error Query');
				}else{
					echo "<center><B style='color:red'><h1 style='font-size: 80px;'>เกิดข้อผิดพลาด</h1>
		<h1 style='font-size: 80px;'>หมายเลขอ้างอิงนี้</h1>
		<h1 style='font-size: 80px;'>ถูกใช้งานแล้ว</h1></B>
		<p><a href='/topup/get.php'>[กลับไปลองอีกครั้ง]</a> </p></center>";
				}
				break;
				}else if($walletmoney == $checkid && $money == 11){
				$sql = "select * from users where username='".$_SESSION['user']['username']."'";
				$sqle = "SELECT * FROM histrory WHERE NumberWallet='$walletmoney'";
				$query = mysqli_query($con,$sqle);
				$result = mysqli_fetch_assoc($query);
				if($result['status'] == ''){
					echo "<center><B style='font-size: 60px;'><h1 style='color:green'>เติมเงินเรียบร้อย</h1>
					<h1>จำนวนเงิน ที่คุณเติมคือ $money บาท</h1>
					<h1>ขอบคุณที่ใช้บริการครับ !</h1></B>  
					<p><a href='/main'>[ไปเช่าเน็ตกันเถอะ]</a> </p></center>";
					$sql = "insert into histrory (NumberWallet,money,username,status) values ('$walletmoney','$money','".$_SESSION['user']['username']."',1)";
					mysqli_query($con,$sql);
					$sql1 = "insert into users (saldo) values ('$money') where username='".$_SESSION['user']['username']."'";
					$sql1 = "update users set saldo=saldo+'".$money."'where username='".$_SESSION['user']['username']."'";
					mysqli_query($con,$sql1) or die; ('Error Query');
				}else{
					echo "<center><B style='color:red'><h1 style='font-size: 80px;'>เกิดข้อผิดพลาด</h1>
		<h1 style='font-size: 80px;'>หมายเลขอ้างอิงนี้</h1>
		<h1 style='font-size: 80px;'>ถูกใช้งานแล้ว</h1></B>
		<p><a href='/topup/get.php'>[กลับไปลองอีกครั้ง]</a> </p></center>";
				}
				break;
				}else if($walletmoney == $checkid && $money == 12){
				$sql = "select * from users where username='".$_SESSION['user']['username']."'";
				$sqle = "SELECT * FROM histrory WHERE NumberWallet='$walletmoney'";
				$query = mysqli_query($con,$sqle);
				$result = mysqli_fetch_assoc($query);
				if($result['status'] == ''){
					echo "<center><B style='font-size: 60px;'><h1 style='color:green'>เติมเงินเรียบร้อย</h1>
					<h1>จำนวนเงิน ที่คุณเติมคือ $money บาท</h1>
					<h1>ขอบคุณที่ใช้บริการครับ !</h1></B>  
					<p><a href='/main'>[ไปเช่าเน็ตกันเถอะ]</a> </p></center>";
					$sql = "insert into histrory (NumberWallet,money,username,status) values ('$walletmoney','$money','".$_SESSION['user']['username']."',1)";
					mysqli_query($con,$sql);
					$sql1 = "insert into users (saldo) values ('$money') where username='".$_SESSION['user']['username']."'";
					$sql1 = "update users set saldo=saldo+'".$money."'where username='".$_SESSION['user']['username']."'";
					mysqli_query($con,$sql1) or die; ('Error Query');
				}else{
					echo "<center><B style='color:red'><h1 style='font-size: 80px;'>เกิดข้อผิดพลาด</h1>
		<h1 style='font-size: 80px;'>หมายเลขอ้างอิงนี้</h1>
		<h1 style='font-size: 80px;'>ถูกใช้งานแล้ว</h1></B>
		<p><a href='/topup/get.php'>[กลับไปลองอีกครั้ง]</a> </p></center>";
				}
				break;
				}else if($walletmoney == $checkid && $money == 13){
				$sql = "select * from users where username='".$_SESSION['user']['username']."'";
				$sqle = "SELECT * FROM histrory WHERE NumberWallet='$walletmoney'";
				$query = mysqli_query($con,$sqle);
				$result = mysqli_fetch_assoc($query);
				if($result['status'] == ''){
					echo "<center><B style='font-size: 60px;'><h1 style='color:green'>เติมเงินเรียบร้อย</h1>
					<h1>จำนวนเงิน ที่คุณเติมคือ $money บาท</h1>
					<h1>ขอบคุณที่ใช้บริการครับ !</h1></B>  
					<p><a href='/main'>[ไปเช่าเน็ตกันเถอะ]</a> </p></center>";
					$sql = "insert into histrory (NumberWallet,money,username,status) values ('$walletmoney','$money','".$_SESSION['user']['username']."',1)";
					mysqli_query($con,$sql);
					$sql1 = "insert into users (saldo) values ('$money') where username='".$_SESSION['user']['username']."'";
					$sql1 = "update users set saldo=saldo+'".$money."'where username='".$_SESSION['user']['username']."'";
					mysqli_query($con,$sql1) or die; ('Error Query');
				}else{
					echo "<center><B style='color:red'><h1 style='font-size: 80px;'>เกิดข้อผิดพลาด</h1>
		<h1 style='font-size: 80px;'>หมายเลขอ้างอิงนี้</h1>
		<h1 style='font-size: 80px;'>ถูกใช้งานแล้ว</h1></B>
		<p><a href='/topup/get.php'>[กลับไปลองอีกครั้ง]</a> </p></center>";
				}
				break;
				}else if($walletmoney == $checkid && $money == 14){
				$sql = "select * from users where username='".$_SESSION['user']['username']."'";
				$sqle = "SELECT * FROM histrory WHERE NumberWallet='$walletmoney'";
				$query = mysqli_query($con,$sqle);
				$result = mysqli_fetch_assoc($query);
				if($result['status'] == ''){
					echo "<center><B style='font-size: 60px;'><h1 style='color:green'>เติมเงินเรียบร้อย</h1>
					<h1>จำนวนเงิน ที่คุณเติมคือ $money บาท</h1>
					<h1>ขอบคุณที่ใช้บริการครับ !</h1></B>  
					<p><a href='/main'>[ไปเช่าเน็ตกันเถอะ]</a> </p></center>";
					$sql = "insert into histrory (NumberWallet,money,username,status) values ('$walletmoney','$money','".$_SESSION['user']['username']."',1)";
					mysqli_query($con,$sql);
					$sql1 = "insert into users (saldo) values ('$money') where username='".$_SESSION['user']['username']."'";
					$sql1 = "update users set saldo=saldo+'".$money."'where username='".$_SESSION['user']['username']."'";
					mysqli_query($con,$sql1) or die; ('Error Query');
				}else{
					echo "<center><B style='color:red'><h1 style='font-size: 80px;'>เกิดข้อผิดพลาด</h1>
		<h1 style='font-size: 80px;'>หมายเลขอ้างอิงนี้</h1>
		<h1 style='font-size: 80px;'>ถูกใช้งานแล้ว</h1></B>
		<p><a href='/topup/get.php'>[กลับไปลองอีกครั้ง]</a> </p></center>";
				}
				break;
				}else if($walletmoney == $checkid && $money == 15){
				$sql = "select * from users where username='".$_SESSION['user']['username']."'";
				$sqle = "SELECT * FROM histrory WHERE NumberWallet='$walletmoney'";
				$query = mysqli_query($con,$sqle);
				$result = mysqli_fetch_assoc($query);
				if($result['status'] == ''){
					echo "<center><B style='font-size: 60px;'><h1 style='color:green'>เติมเงินเรียบร้อย</h1>
					<h1>จำนวนเงิน ที่คุณเติมคือ $money บาท</h1>
					<h1>ขอบคุณที่ใช้บริการครับ !</h1></B>  
					<p><a href='/main'>[ไปเช่าเน็ตกันเถอะ]</a> </p></center>";
					$sql = "insert into histrory (NumberWallet,money,username,status) values ('$walletmoney','$money','".$_SESSION['user']['username']."',1)";
					mysqli_query($con,$sql);
					$sql1 = "insert into users (saldo) values ('$money') where username='".$_SESSION['user']['username']."'";
					$sql1 = "update users set saldo=saldo+'".$money."'where username='".$_SESSION['user']['username']."'";
					mysqli_query($con,$sql1) or die; ('Error Query');
				}else{
					echo "<center><B style='color:red'><h1 style='font-size: 80px;'>เกิดข้อผิดพลาด</h1>
		<h1 style='font-size: 80px;'>หมายเลขอ้างอิงนี้</h1>
		<h1 style='font-size: 80px;'>ถูกใช้งานแล้ว</h1></B>
		<p><a href='/topup/get.php'>[กลับไปลองอีกครั้ง]</a> </p></center>";
				}
				break;
				}else if($walletmoney == $checkid && $money == 16){
				$sql = "select * from users where username='".$_SESSION['user']['username']."'";
				$sqle = "SELECT * FROM histrory WHERE NumberWallet='$walletmoney'";
				$query = mysqli_query($con,$sqle);
				$result = mysqli_fetch_assoc($query);
				if($result['status'] == ''){
					echo "<center><B style='font-size: 60px;'><h1 style='color:green'>เติมเงินเรียบร้อย</h1>
					<h1>จำนวนเงิน ที่คุณเติมคือ $money บาท</h1>
					<h1>ขอบคุณที่ใช้บริการครับ !</h1></B>  
					<p><a href='/main'>[ไปเช่าเน็ตกันเถอะ]</a> </p></center>";
					$sql = "insert into histrory (NumberWallet,money,username,status) values ('$walletmoney','$money','".$_SESSION['user']['username']."',1)";
					mysqli_query($con,$sql);
					$sql1 = "insert into users (saldo) values ('$money') where username='".$_SESSION['user']['username']."'";
					$sql1 = "update users set saldo=saldo+'".$money."'where username='".$_SESSION['user']['username']."'";
					mysqli_query($con,$sql1) or die; ('Error Query');
				}else{
					echo "<center><B style='color:red'><h1 style='font-size: 80px;'>เกิดข้อผิดพลาด</h1>
		<h1 style='font-size: 80px;'>หมายเลขอ้างอิงนี้</h1>
		<h1 style='font-size: 80px;'>ถูกใช้งานแล้ว</h1></B>
		<p><a href='/topup/get.php'>[กลับไปลองอีกครั้ง]</a> </p></center>";
				}
				break;
				}else if($walletmoney == $checkid && $money == 17){
				$sql = "select * from users where username='".$_SESSION['user']['username']."'";
				$sqle = "SELECT * FROM histrory WHERE NumberWallet='$walletmoney'";
				$query = mysqli_query($con,$sqle);
				$result = mysqli_fetch_assoc($query);
				if($result['status'] == ''){
					echo "<center><B style='font-size: 60px;'><h1 style='color:green'>เติมเงินเรียบร้อย</h1>
					<h1>จำนวนเงิน ที่คุณเติมคือ $money บาท</h1>
					<h1>ขอบคุณที่ใช้บริการครับ !</h1></B>  
					<p><a href='/main'>[ไปเช่าเน็ตกันเถอะ]</a> </p></center>";
					$sql = "insert into histrory (NumberWallet,money,username,status) values ('$walletmoney','$money','".$_SESSION['user']['username']."',1)";
					mysqli_query($con,$sql);
					$sql1 = "insert into users (saldo) values ('$money') where username='".$_SESSION['user']['username']."'";
					$sql1 = "update users set saldo=saldo+'".$money."'where username='".$_SESSION['user']['username']."'";
					mysqli_query($con,$sql1) or die; ('Error Query');
				}else{
					echo "<center><B style='color:red'><h1 style='font-size: 80px;'>เกิดข้อผิดพลาด</h1>
		<h1 style='font-size: 80px;'>หมายเลขอ้างอิงนี้</h1>
		<h1 style='font-size: 80px;'>ถูกใช้งานแล้ว</h1></B>
		<p><a href='/topup/get.php'>[กลับไปลองอีกครั้ง]</a> </p></center>";
				}
				break;
				}else if($walletmoney == $checkid && $money == 18){
				$sql = "select * from users where username='".$_SESSION['user']['username']."'";
				$sqle = "SELECT * FROM histrory WHERE NumberWallet='$walletmoney'";
				$query = mysqli_query($con,$sqle);
				$result = mysqli_fetch_assoc($query);
				if($result['status'] == ''){
					echo "<center><B style='font-size: 60px;'><h1 style='color:green'>เติมเงินเรียบร้อย</h1>
					<h1>จำนวนเงิน ที่คุณเติมคือ $money บาท</h1>
					<h1>ขอบคุณที่ใช้บริการครับ !</h1></B>  
					<p><a href='/main'>[ไปเช่าเน็ตกันเถอะ]</a> </p></center>";
					$sql = "insert into histrory (NumberWallet,money,username,status) values ('$walletmoney','$money','".$_SESSION['user']['username']."',1)";
					mysqli_query($con,$sql);
					$sql1 = "insert into users (saldo) values ('$money') where username='".$_SESSION['user']['username']."'";
					$sql1 = "update users set saldo=saldo+'".$money."'where username='".$_SESSION['user']['username']."'";
					mysqli_query($con,$sql1) or die; ('Error Query');
				}else{
					echo "<center><B style='color:red'><h1 style='font-size: 80px;'>เกิดข้อผิดพลาด</h1>
		<h1 style='font-size: 80px;'>หมายเลขอ้างอิงนี้</h1>
		<h1 style='font-size: 80px;'>ถูกใช้งานแล้ว</h1></B>
		<p><a href='/topup/get.php'>[กลับไปลองอีกครั้ง]</a> </p></center>";
				}
				break;
			}else if($walletmoney == $checkid && $money == 19){
				$sql = "select * from users where username='".$_SESSION['user']['username']."'";
				$sqle = "SELECT * FROM histrory WHERE NumberWallet='$walletmoney'";
				$query = mysqli_query($con,$sqle);
				$result = mysqli_fetch_assoc($query);
				if($result['status'] == ''){
					echo "<center><B style='font-size: 60px;'><h1 style='color:green'>เติมเงินเรียบร้อย</h1>
					<h1>จำนวนเงิน ที่คุณเติมคือ $money บาท</h1>
					<h1>ขอบคุณที่ใช้บริการครับ !</h1></B>  
					<p><a href='/main'>[ไปเช่าเน็ตกันเถอะ]</a> </p></center>";
					$sql = "insert into histrory (NumberWallet,money,username,status) values ('$walletmoney','$money','".$_SESSION['user']['username']."',1)";
					mysqli_query($con,$sql);
					$sql1 = "insert into users (saldo) values ('$money') where username='".$_SESSION['user']['username']."'";
					$sql1 = "update users set saldo=saldo+'".$money."'where username='".$_SESSION['user']['username']."'";
					mysqli_query($con,$sql1) or die; ('Error Query');
				}else{
					echo "<center><B style='color:red'><h1 style='font-size: 80px;'>เกิดข้อผิดพลาด</h1>
		<h1 style='font-size: 80px;'>หมายเลขอ้างอิงนี้</h1>
		<h1 style='font-size: 80px;'>ถูกใช้งานแล้ว</h1></B>
		<p><a href='/topup/get.php'>[กลับไปลองอีกครั้ง]</a> </p></center>";
				}
				break;
			}else if($walletmoney == $checkid && $money == 20){
				$sql = "select * from users where username='".$_SESSION['user']['username']."'";
				$sqle = "SELECT * FROM histrory WHERE NumberWallet='$walletmoney'";
				$query = mysqli_query($con,$sqle);
				$result = mysqli_fetch_assoc($query);
				if($result['status'] == ''){
					echo "<center><B style='font-size: 60px;'><h1 style='color:green'>เติมเงินเรียบร้อย</h1>
					<h1>จำนวนเงิน ที่คุณเติมคือ $money บาท</h1>
					<h1>ขอบคุณที่ใช้บริการครับ !</h1></B>  
					<p><a href='/main'>[ไปเช่าเน็ตกันเถอะ]</a> </p></center>";
					$sql = "insert into histrory (NumberWallet,money,username,status) values ('$walletmoney','$money','".$_SESSION['user']['username']."',1)";
					mysqli_query($con,$sql);
					$sql1 = "insert into users (saldo) values ('$money') where username='".$_SESSION['user']['username']."'";
					$sql1 = "update users set saldo=saldo+'".$money."'where username='".$_SESSION['user']['username']."'";
					mysqli_query($con,$sql1) or die; ('Error Query');
				}else{
					echo "<center><B style='color:red'><h1 style='font-size: 80px;'>เกิดข้อผิดพลาด</h1>
		<h1 style='font-size: 80px;'>หมายเลขอ้างอิงนี้</h1>
		<h1 style='font-size: 80px;'>ถูกใช้งานแล้ว</h1></B>
		<p><a href='/topup/get.php'>[กลับไปลองอีกครั้ง]</a> </p></center>";
				}
				break;
				}else if($walletmoney == $checkid && $money == 21){
				$sql = "select * from users where username='".$_SESSION['user']['username']."'";
				$sqle = "SELECT * FROM histrory WHERE NumberWallet='$walletmoney'";
				$query = mysqli_query($con,$sqle);
				$result = mysqli_fetch_assoc($query);
				if($result['status'] == ''){
					echo "<center><B style='font-size: 60px;'><h1 style='color:green'>เติมเงินเรียบร้อย</h1>
					<h1>จำนวนเงิน ที่คุณเติมคือ $money บาท</h1>
					<h1>ขอบคุณที่ใช้บริการครับ !</h1></B>  
					<p><a href='/main'>[ไปเช่าเน็ตกันเถอะ]</a> </p></center>";
					$sql = "insert into histrory (NumberWallet,money,username,status) values ('$walletmoney','$money','".$_SESSION['user']['username']."',1)";
					mysqli_query($con,$sql);
					$sql1 = "insert into users (saldo) values ('$money') where username='".$_SESSION['user']['username']."'";
					$sql1 = "update users set saldo=saldo+'".$money."'where username='".$_SESSION['user']['username']."'";
					mysqli_query($con,$sql1) or die; ('Error Query');
				}else{
					echo "<center><B style='color:red'><h1 style='font-size: 80px;'>เกิดข้อผิดพลาด</h1>
		<h1 style='font-size: 80px;'>หมายเลขอ้างอิงนี้</h1>
		<h1 style='font-size: 80px;'>ถูกใช้งานแล้ว</h1></B>
		<p><a href='/topup/get.php'>[กลับไปลองอีกครั้ง]</a> </p></center>";
				}
				break;
				}else if($walletmoney == $checkid && $money == 22){
				$sql = "select * from users where username='".$_SESSION['user']['username']."'";
				$sqle = "SELECT * FROM histrory WHERE NumberWallet='$walletmoney'";
				$query = mysqli_query($con,$sqle);
				$result = mysqli_fetch_assoc($query);
				if($result['status'] == ''){
					echo "<center><B style='font-size: 60px;'><h1 style='color:green'>เติมเงินเรียบร้อย</h1>
					<h1>จำนวนเงิน ที่คุณเติมคือ $money บาท</h1>
					<h1>ขอบคุณที่ใช้บริการครับ !</h1></B>  
					<p><a href='/main'>[ไปเช่าเน็ตกันเถอะ]</a> </p></center>";
					$sql = "insert into histrory (NumberWallet,money,username,status) values ('$walletmoney','$money','".$_SESSION['user']['username']."',1)";
					mysqli_query($con,$sql);
					$sql1 = "insert into users (saldo) values ('$money') where username='".$_SESSION['user']['username']."'";
					$sql1 = "update users set saldo=saldo+'".$money."'where username='".$_SESSION['user']['username']."'";
					mysqli_query($con,$sql1) or die; ('Error Query');
				}else{
					echo "<center><B style='color:red'><h1 style='font-size: 80px;'>เกิดข้อผิดพลาด</h1>
		<h1 style='font-size: 80px;'>หมายเลขอ้างอิงนี้</h1>
		<h1 style='font-size: 80px;'>ถูกใช้งานแล้ว</h1></B>
		<p><a href='/topup/get.php'>[กลับไปลองอีกครั้ง]</a> </p></center>";
				}
				break;
				}else if($walletmoney == $checkid && $money == 23){
				$sql = "select * from users where username='".$_SESSION['user']['username']."'";
				$sqle = "SELECT * FROM histrory WHERE NumberWallet='$walletmoney'";
				$query = mysqli_query($con,$sqle);
				$result = mysqli_fetch_assoc($query);
				if($result['status'] == ''){
					echo "<center><B style='font-size: 60px;'><h1 style='color:green'>เติมเงินเรียบร้อย</h1>
					<h1>จำนวนเงิน ที่คุณเติมคือ $money บาท</h1>
					<h1>ขอบคุณที่ใช้บริการครับ !</h1></B>  
					<p><a href='/main'>[ไปเช่าเน็ตกันเถอะ]</a> </p></center>";
					$sql = "insert into histrory (NumberWallet,money,username,status) values ('$walletmoney','$money','".$_SESSION['user']['username']."',1)";
					mysqli_query($con,$sql);
					$sql1 = "insert into users (saldo) values ('$money') where username='".$_SESSION['user']['username']."'";
					$sql1 = "update users set saldo=saldo+'".$money."'where username='".$_SESSION['user']['username']."'";
					mysqli_query($con,$sql1) or die; ('Error Query');
				}else{
					echo "<center><B style='color:red'><h1 style='font-size: 80px;'>เกิดข้อผิดพลาด</h1>
		<h1 style='font-size: 80px;'>หมายเลขอ้างอิงนี้</h1>
		<h1 style='font-size: 80px;'>ถูกใช้งานแล้ว</h1></B>
		<p><a href='/topup/get.php'>[กลับไปลองอีกครั้ง]</a> </p></center>";
				}
				break;
				}else if($walletmoney == $checkid && $money == 24){
				$sql = "select * from users where username='".$_SESSION['user']['username']."'";
				$sqle = "SELECT * FROM histrory WHERE NumberWallet='$walletmoney'";
				$query = mysqli_query($con,$sqle);
				$result = mysqli_fetch_assoc($query);
				if($result['status'] == ''){
					echo "<center><B style='font-size: 60px;'><h1 style='color:green'>เติมเงินเรียบร้อย</h1>
					<h1>จำนวนเงิน ที่คุณเติมคือ $money บาท</h1>
					<h1>ขอบคุณที่ใช้บริการครับ !</h1></B>  
					<p><a href='/main'>[ไปเช่าเน็ตกันเถอะ]</a> </p></center>";
					$sql = "insert into histrory (NumberWallet,money,username,status) values ('$walletmoney','$money','".$_SESSION['user']['username']."',1)";
					mysqli_query($con,$sql);
					$sql1 = "insert into users (saldo) values ('$money') where username='".$_SESSION['user']['username']."'";
					$sql1 = "update users set saldo=saldo+'".$money."'where username='".$_SESSION['user']['username']."'";
					mysqli_query($con,$sql1) or die; ('Error Query');
				}else{
					echo "<center><B style='color:red'><h1 style='font-size: 80px;'>เกิดข้อผิดพลาด</h1>
		<h1 style='font-size: 80px;'>หมายเลขอ้างอิงนี้</h1>
		<h1 style='font-size: 80px;'>ถูกใช้งานแล้ว</h1></B>
		<p><a href='/topup/get.php'>[กลับไปลองอีกครั้ง]</a> </p></center>";
				}
				break;
				}else if($walletmoney == $checkid && $money == 25){
				$sql = "select * from users where username='".$_SESSION['user']['username']."'";
				$sqle = "SELECT * FROM histrory WHERE NumberWallet='$walletmoney'";
				$query = mysqli_query($con,$sqle);
				$result = mysqli_fetch_assoc($query);
				if($result['status'] == ''){
					echo "<center><B style='font-size: 60px;'><h1 style='color:green'>เติมเงินเรียบร้อย</h1>
					<h1>จำนวนเงิน ที่คุณเติมคือ $money บาท</h1>
					<h1>ขอบคุณที่ใช้บริการครับ !</h1></B>  
					<p><a href='/main'>[ไปเช่าเน็ตกันเถอะ]</a> </p></center>";
					$sql = "insert into histrory (NumberWallet,money,username,status) values ('$walletmoney','$money','".$_SESSION['user']['username']."',1)";
					mysqli_query($con,$sql);
					$sql1 = "insert into users (saldo) values ('$money') where username='".$_SESSION['user']['username']."'";
					$sql1 = "update users set saldo=saldo+'".$money."'where username='".$_SESSION['user']['username']."'";
					mysqli_query($con,$sql1) or die; ('Error Query');
				}else{
					echo "<center><B style='color:red'><h1 style='font-size: 80px;'>เกิดข้อผิดพลาด</h1>
		<h1 style='font-size: 80px;'>หมายเลขอ้างอิงนี้</h1>
		<h1 style='font-size: 80px;'>ถูกใช้งานแล้ว</h1></B>
		<p><a href='/topup/get.php'>[กลับไปลองอีกครั้ง]</a> </p></center>";
				}
				break;
				}else if($walletmoney == $checkid && $money == 26){
				$sql = "select * from users where username='".$_SESSION['user']['username']."'";
				$sqle = "SELECT * FROM histrory WHERE NumberWallet='$walletmoney'";
				$query = mysqli_query($con,$sqle);
				$result = mysqli_fetch_assoc($query);
				if($result['status'] == ''){
					echo "<center><B style='font-size: 60px;'><h1 style='color:green'>เติมเงินเรียบร้อย</h1>
					<h1>จำนวนเงิน ที่คุณเติมคือ $money บาท</h1>
					<h1>ขอบคุณที่ใช้บริการครับ !</h1></B>  
					<p><a href='/main'>[ไปเช่าเน็ตกันเถอะ]</a> </p></center>";
					$sql = "insert into histrory (NumberWallet,money,username,status) values ('$walletmoney','$money','".$_SESSION['user']['username']."',1)";
					mysqli_query($con,$sql);
					$sql1 = "insert into users (saldo) values ('$money') where username='".$_SESSION['user']['username']."'";
					$sql1 = "update users set saldo=saldo+'".$money."'where username='".$_SESSION['user']['username']."'";
					mysqli_query($con,$sql1) or die; ('Error Query');
				}else{
					echo "<center><B style='color:red'><h1 style='font-size: 80px;'>เกิดข้อผิดพลาด</h1>
		<h1 style='font-size: 80px;'>หมายเลขอ้างอิงนี้</h1>
		<h1 style='font-size: 80px;'>ถูกใช้งานแล้ว</h1></B>
		<p><a href='/topup/get.php'>[กลับไปลองอีกครั้ง]</a> </p></center>";
				}
				break;
				}else if($walletmoney == $checkid && $money == 27){
				$sql = "select * from users where username='".$_SESSION['user']['username']."'";
				$sqle = "SELECT * FROM histrory WHERE NumberWallet='$walletmoney'";
				$query = mysqli_query($con,$sqle);
				$result = mysqli_fetch_assoc($query);
				if($result['status'] == ''){
					echo "<center><B style='font-size: 60px;'><h1 style='color:green'>เติมเงินเรียบร้อย</h1>
					<h1>จำนวนเงิน ที่คุณเติมคือ $money บาท</h1>
					<h1>ขอบคุณที่ใช้บริการครับ !</h1></B>  
					<p><a href='/main'>[ไปเช่าเน็ตกันเถอะ]</a> </p></center>";
					$sql = "insert into histrory (NumberWallet,money,username,status) values ('$walletmoney','$money','".$_SESSION['user']['username']."',1)";
					mysqli_query($con,$sql);
					$sql1 = "insert into users (saldo) values ('$money') where username='".$_SESSION['user']['username']."'";
					$sql1 = "update users set saldo=saldo+'".$money."'where username='".$_SESSION['user']['username']."'";
					mysqli_query($con,$sql1) or die; ('Error Query');
				}else{
					echo "<center><B style='color:red'><h1 style='font-size: 80px;'>เกิดข้อผิดพลาด</h1>
		<h1 style='font-size: 80px;'>หมายเลขอ้างอิงนี้</h1>
		<h1 style='font-size: 80px;'>ถูกใช้งานแล้ว</h1></B>
		<p><a href='/topup/get.php'>[กลับไปลองอีกครั้ง]</a> </p></center>";
				}
				break;
				}else if($walletmoney == $checkid && $money == 28){
				$sql = "select * from users where username='".$_SESSION['user']['username']."'";
				$sqle = "SELECT * FROM histrory WHERE NumberWallet='$walletmoney'";
				$query = mysqli_query($con,$sqle);
				$result = mysqli_fetch_assoc($query);
				if($result['status'] == ''){
					echo "<center><B style='font-size: 60px;'><h1 style='color:green'>เติมเงินเรียบร้อย</h1>
					<h1>จำนวนเงิน ที่คุณเติมคือ $money บาท</h1>
					<h1>ขอบคุณที่ใช้บริการครับ !</h1></B>  
					<p><a href='/main'>[ไปเช่าเน็ตกันเถอะ]</a> </p></center>";
					$sql = "insert into histrory (NumberWallet,money,username,status) values ('$walletmoney','$money','".$_SESSION['user']['username']."',1)";
					mysqli_query($con,$sql);
					$sql1 = "insert into users (saldo) values ('$money') where username='".$_SESSION['user']['username']."'";
					$sql1 = "update users set saldo=saldo+'".$money."'where username='".$_SESSION['user']['username']."'";
					mysqli_query($con,$sql1) or die; ('Error Query');
				}else{
					echo "<center><B style='color:red'><h1 style='font-size: 80px;'>เกิดข้อผิดพลาด</h1>
		<h1 style='font-size: 80px;'>หมายเลขอ้างอิงนี้</h1>
		<h1 style='font-size: 80px;'>ถูกใช้งานแล้ว</h1></B>
		<p><a href='/topup/get.php'>[กลับไปลองอีกครั้ง]</a> </p></center>";
				}
				break;
			}else if($walletmoney == $checkid && $money == 29){
				$sql = "select * from users where username='".$_SESSION['user']['username']."'";
				$sqle = "SELECT * FROM histrory WHERE NumberWallet='$walletmoney'";
				$query = mysqli_query($con,$sqle);
				$result = mysqli_fetch_assoc($query);
				if($result['status'] == ''){
					echo "<center><B style='font-size: 60px;'><h1 style='color:green'>เติมเงินเรียบร้อย</h1>
					<h1>จำนวนเงิน ที่คุณเติมคือ $money บาท</h1>
					<h1>ขอบคุณที่ใช้บริการครับ !</h1></B>  
					<p><a href='/main'>[ไปเช่าเน็ตกันเถอะ]</a> </p></center>";
					$sql = "insert into histrory (NumberWallet,money,username,status) values ('$walletmoney','$money','".$_SESSION['user']['username']."',1)";
					mysqli_query($con,$sql);
					$sql1 = "insert into users (saldo) values ('$money') where username='".$_SESSION['user']['username']."'";
					$sql1 = "update users set saldo=saldo+'".$money."'where username='".$_SESSION['user']['username']."'";
					mysqli_query($con,$sql1) or die; ('Error Query');
				}else{
					echo "<center><B style='color:red'><h1 style='font-size: 80px;'>เกิดข้อผิดพลาด</h1>
		<h1 style='font-size: 80px;'>หมายเลขอ้างอิงนี้</h1>
		<h1 style='font-size: 80px;'>ถูกใช้งานแล้ว</h1></B>
		<p><a href='/topup/get.php'>[กลับไปลองอีกครั้ง]</a> </p></center>";
				}
				break;
				}else if($walletmoney == $checkid && $money == 30){
				$sql = "select * from users where username='".$_SESSION['user']['username']."'";
				$sqle = "SELECT * FROM histrory WHERE NumberWallet='$walletmoney'";
				$query = mysqli_query($con,$sqle);
				$result = mysqli_fetch_assoc($query);
				if($result['status'] == ''){
					echo "<center><B style='font-size: 60px;'><h1 style='color:green'>เติมเงินเรียบร้อย</h1>
					<h1>จำนวนเงิน ที่คุณเติมคือ $money บาท</h1>
					<h1>ขอบคุณที่ใช้บริการครับ !</h1></B>  
					<p><a href='/main'>[ไปเช่าเน็ตกันเถอะ]</a> </p></center>";
					$sql = "insert into histrory (NumberWallet,money,username,status) values ('$walletmoney','$money','".$_SESSION['user']['username']."',1)";
					mysqli_query($con,$sql);
					$sql1 = "insert into users (saldo) values ('$money') where username='".$_SESSION['user']['username']."'";
					$sql1 = "update users set saldo=saldo+'".$money."'where username='".$_SESSION['user']['username']."'";
					mysqli_query($con,$sql1) or die; ('Error Query');
				}else{
					echo "<center><B style='color:red'><h1 style='font-size: 80px;'>เกิดข้อผิดพลาด</h1>
		<h1 style='font-size: 80px;'>หมายเลขอ้างอิงนี้</h1>
		<h1 style='font-size: 80px;'>ถูกใช้งานแล้ว</h1></B>
		<p><a href='/topup/get.php'>[กลับไปลองอีกครั้ง]</a> </p></center>";
				}
				break;
				}else if($walletmoney == $checkid && $money == 31){
				$sql = "select * from users where username='".$_SESSION['user']['username']."'";
				$sqle = "SELECT * FROM histrory WHERE NumberWallet='$walletmoney'";
				$query = mysqli_query($con,$sqle);
				$result = mysqli_fetch_assoc($query);
				if($result['status'] == ''){
					echo "<center><B style='font-size: 60px;'><h1 style='color:green'>เติมเงินเรียบร้อย</h1>
					<h1>จำนวนเงิน ที่คุณเติมคือ $money บาท</h1>
					<h1>ขอบคุณที่ใช้บริการครับ !</h1></B>  
					<p><a href='/main'>[ไปเช่าเน็ตกันเถอะ]</a> </p></center>";
					$sql = "insert into histrory (NumberWallet,money,username,status) values ('$walletmoney','$money','".$_SESSION['user']['username']."',1)";
					mysqli_query($con,$sql);
					$sql1 = "insert into users (saldo) values ('$money') where username='".$_SESSION['user']['username']."'";
					$sql1 = "update users set saldo=saldo+'".$money."'where username='".$_SESSION['user']['username']."'";
					mysqli_query($con,$sql1) or die; ('Error Query');
				}else{
					echo "<center><B style='color:red'><h1 style='font-size: 80px;'>เกิดข้อผิดพลาด</h1>
		<h1 style='font-size: 80px;'>หมายเลขอ้างอิงนี้</h1>
		<h1 style='font-size: 80px;'>ถูกใช้งานแล้ว</h1></B>
		<p><a href='/topup/get.php'>[กลับไปลองอีกครั้ง]</a> </p></center>";
				}
				break;
				}else if($walletmoney == $checkid && $money == 32){
				$sql = "select * from users where username='".$_SESSION['user']['username']."'";
				$sqle = "SELECT * FROM histrory WHERE NumberWallet='$walletmoney'";
				$query = mysqli_query($con,$sqle);
				$result = mysqli_fetch_assoc($query);
				if($result['status'] == ''){
					echo "<center><B style='font-size: 60px;'><h1 style='color:green'>เติมเงินเรียบร้อย</h1>
					<h1>จำนวนเงิน ที่คุณเติมคือ $money บาท</h1>
					<h1>ขอบคุณที่ใช้บริการครับ !</h1></B>  
					<p><a href='/main'>[ไปเช่าเน็ตกันเถอะ]</a> </p></center>";
					$sql = "insert into histrory (NumberWallet,money,username,status) values ('$walletmoney','$money','".$_SESSION['user']['username']."',1)";
					mysqli_query($con,$sql);
					$sql1 = "insert into users (saldo) values ('$money') where username='".$_SESSION['user']['username']."'";
					$sql1 = "update users set saldo=saldo+'".$money."'where username='".$_SESSION['user']['username']."'";
					mysqli_query($con,$sql1) or die; ('Error Query');
				}else{
					echo "<center><B style='color:red'><h1 style='font-size: 80px;'>เกิดข้อผิดพลาด</h1>
		<h1 style='font-size: 80px;'>หมายเลขอ้างอิงนี้</h1>
		<h1 style='font-size: 80px;'>ถูกใช้งานแล้ว</h1></B>
		<p><a href='/topup/get.php'>[กลับไปลองอีกครั้ง]</a> </p></center>";
				}
				break;
				}else if($walletmoney == $checkid && $money == 33){
				$sql = "select * from users where username='".$_SESSION['user']['username']."'";
				$sqle = "SELECT * FROM histrory WHERE NumberWallet='$walletmoney'";
				$query = mysqli_query($con,$sqle);
				$result = mysqli_fetch_assoc($query);
				if($result['status'] == ''){
					echo "<center><B style='font-size: 60px;'><h1 style='color:green'>เติมเงินเรียบร้อย</h1>
					<h1>จำนวนเงิน ที่คุณเติมคือ $money บาท</h1>
					<h1>ขอบคุณที่ใช้บริการครับ !</h1></B>  
					<p><a href='/main'>[ไปเช่าเน็ตกันเถอะ]</a> </p></center>";
					$sql = "insert into histrory (NumberWallet,money,username,status) values ('$walletmoney','$money','".$_SESSION['user']['username']."',1)";
					mysqli_query($con,$sql);
					$sql1 = "insert into users (saldo) values ('$money') where username='".$_SESSION['user']['username']."'";
					$sql1 = "update users set saldo=saldo+'".$money."'where username='".$_SESSION['user']['username']."'";
					mysqli_query($con,$sql1) or die; ('Error Query');
				}else{
					echo "<center><B style='color:red'><h1 style='font-size: 80px;'>เกิดข้อผิดพลาด</h1>
		<h1 style='font-size: 80px;'>หมายเลขอ้างอิงนี้</h1>
		<h1 style='font-size: 80px;'>ถูกใช้งานแล้ว</h1></B>
		<p><a href='/topup/get.php'>[กลับไปลองอีกครั้ง]</a> </p></center>";
				}
				break;
				}else if($walletmoney == $checkid && $money == 34){
				$sql = "select * from users where username='".$_SESSION['user']['username']."'";
				$sqle = "SELECT * FROM histrory WHERE NumberWallet='$walletmoney'";
				$query = mysqli_query($con,$sqle);
				$result = mysqli_fetch_assoc($query);
				if($result['status'] == ''){
					echo "<center><B style='font-size: 60px;'><h1 style='color:green'>เติมเงินเรียบร้อย</h1>
					<h1>จำนวนเงิน ที่คุณเติมคือ $money บาท</h1>
					<h1>ขอบคุณที่ใช้บริการครับ !</h1></B>  
					<p><a href='/main'>[ไปเช่าเน็ตกันเถอะ]</a> </p></center>";
					$sql = "insert into histrory (NumberWallet,money,username,status) values ('$walletmoney','$money','".$_SESSION['user']['username']."',1)";
					mysqli_query($con,$sql);
					$sql1 = "insert into users (saldo) values ('$money') where username='".$_SESSION['user']['username']."'";
					$sql1 = "update users set saldo=saldo+'".$money."'where username='".$_SESSION['user']['username']."'";
					mysqli_query($con,$sql1) or die; ('Error Query');
				}else{
					echo "<center><B style='color:red'><h1 style='font-size: 80px;'>เกิดข้อผิดพลาด</h1>
		<h1 style='font-size: 80px;'>หมายเลขอ้างอิงนี้</h1>
		<h1 style='font-size: 80px;'>ถูกใช้งานแล้ว</h1></B>
		<p><a href='/topup/get.php'>[กลับไปลองอีกครั้ง]</a> </p></center>";
				}
				break;
				}else if($walletmoney == $checkid && $money == 35){
				$sql = "select * from users where username='".$_SESSION['user']['username']."'";
				$sqle = "SELECT * FROM histrory WHERE NumberWallet='$walletmoney'";
				$query = mysqli_query($con,$sqle);
				$result = mysqli_fetch_assoc($query);
				if($result['status'] == ''){
					echo "<center><B style='font-size: 60px;'><h1 style='color:green'>เติมเงินเรียบร้อย</h1>
					<h1>จำนวนเงิน ที่คุณเติมคือ $money บาท</h1>
					<h1>ขอบคุณที่ใช้บริการครับ !</h1></B>  
					<p><a href='/main'>[ไปเช่าเน็ตกันเถอะ]</a> </p></center>";
					$sql = "insert into histrory (NumberWallet,money,username,status) values ('$walletmoney','$money','".$_SESSION['user']['username']."',1)";
					mysqli_query($con,$sql);
					$sql1 = "insert into users (saldo) values ('$money') where username='".$_SESSION['user']['username']."'";
					$sql1 = "update users set saldo=saldo+'".$money."'where username='".$_SESSION['user']['username']."'";
					mysqli_query($con,$sql1) or die; ('Error Query');
				}else{
					echo "<center><B style='color:red'><h1 style='font-size: 80px;'>เกิดข้อผิดพลาด</h1>
		<h1 style='font-size: 80px;'>หมายเลขอ้างอิงนี้</h1>
		<h1 style='font-size: 80px;'>ถูกใช้งานแล้ว</h1></B>
		<p><a href='/topup/get.php'>[กลับไปลองอีกครั้ง]</a> </p></center>";
				}
				break;
				}else if($walletmoney == $checkid && $money == 36){
				$sql = "select * from users where username='".$_SESSION['user']['username']."'";
				$sqle = "SELECT * FROM histrory WHERE NumberWallet='$walletmoney'";
				$query = mysqli_query($con,$sqle);
				$result = mysqli_fetch_assoc($query);
				if($result['status'] == ''){
					echo "<center><B style='font-size: 60px;'><h1 style='color:green'>เติมเงินเรียบร้อย</h1>
					<h1>จำนวนเงิน ที่คุณเติมคือ $money บาท</h1>
					<h1>ขอบคุณที่ใช้บริการครับ !</h1></B>  
					<p><a href='/main'>[ไปเช่าเน็ตกันเถอะ]</a> </p></center>";
					$sql = "insert into histrory (NumberWallet,money,username,status) values ('$walletmoney','$money','".$_SESSION['user']['username']."',1)";
					mysqli_query($con,$sql);
					$sql1 = "insert into users (saldo) values ('$money') where username='".$_SESSION['user']['username']."'";
					$sql1 = "update users set saldo=saldo+'".$money."'where username='".$_SESSION['user']['username']."'";
					mysqli_query($con,$sql1) or die; ('Error Query');
				}else{
					echo "<center><B style='color:red'><h1 style='font-size: 80px;'>เกิดข้อผิดพลาด</h1>
		<h1 style='font-size: 80px;'>หมายเลขอ้างอิงนี้</h1>
		<h1 style='font-size: 80px;'>ถูกใช้งานแล้ว</h1></B>
		<p><a href='/topup/get.php'>[กลับไปลองอีกครั้ง]</a> </p></center>";
				}
				break;
				}else if($walletmoney == $checkid && $money == 37){
				$sql = "select * from users where username='".$_SESSION['user']['username']."'";
				$sqle = "SELECT * FROM histrory WHERE NumberWallet='$walletmoney'";
				$query = mysqli_query($con,$sqle);
				$result = mysqli_fetch_assoc($query);
				if($result['status'] == ''){
					echo "<center><B style='font-size: 60px;'><h1 style='color:green'>เติมเงินเรียบร้อย</h1>
					<h1>จำนวนเงิน ที่คุณเติมคือ $money บาท</h1>
					<h1>ขอบคุณที่ใช้บริการครับ !</h1></B>  
					<p><a href='/main'>[ไปเช่าเน็ตกันเถอะ]</a> </p></center>";
					$sql = "insert into histrory (NumberWallet,money,username,status) values ('$walletmoney','$money','".$_SESSION['user']['username']."',1)";
					mysqli_query($con,$sql);
					$sql1 = "insert into users (saldo) values ('$money') where username='".$_SESSION['user']['username']."'";
					$sql1 = "update users set saldo=saldo+'".$money."'where username='".$_SESSION['user']['username']."'";
					mysqli_query($con,$sql1) or die; ('Error Query');
				}else{
					echo "<center><B style='color:red'><h1 style='font-size: 80px;'>เกิดข้อผิดพลาด</h1>
		<h1 style='font-size: 80px;'>หมายเลขอ้างอิงนี้</h1>
		<h1 style='font-size: 80px;'>ถูกใช้งานแล้ว</h1></B>
		<p><a href='/topup/get.php'>[กลับไปลองอีกครั้ง]</a> </p></center>";
				}
				break;
				}else if($walletmoney == $checkid && $money == 38){
				$sql = "select * from users where username='".$_SESSION['user']['username']."'";
				$sqle = "SELECT * FROM histrory WHERE NumberWallet='$walletmoney'";
				$query = mysqli_query($con,$sqle);
				$result = mysqli_fetch_assoc($query);
				if($result['status'] == ''){
					echo "<center><B style='font-size: 60px;'><h1 style='color:green'>เติมเงินเรียบร้อย</h1>
					<h1>จำนวนเงิน ที่คุณเติมคือ $money บาท</h1>
					<h1>ขอบคุณที่ใช้บริการครับ !</h1></B>  
					<p><a href='/main'>[ไปเช่าเน็ตกันเถอะ]</a> </p></center>";
					$sql = "insert into histrory (NumberWallet,money,username,status) values ('$walletmoney','$money','".$_SESSION['user']['username']."',1)";
					mysqli_query($con,$sql);
					$sql1 = "insert into users (saldo) values ('$money') where username='".$_SESSION['user']['username']."'";
					$sql1 = "update users set saldo=saldo+'".$money."'where username='".$_SESSION['user']['username']."'";
					mysqli_query($con,$sql1) or die; ('Error Query');
				}else{
					echo "<center><B style='color:red'><h1 style='font-size: 80px;'>เกิดข้อผิดพลาด</h1>
		<h1 style='font-size: 80px;'>หมายเลขอ้างอิงนี้</h1>
		<h1 style='font-size: 80px;'>ถูกใช้งานแล้ว</h1></B>
		<p><a href='/topup/get.php'>[กลับไปลองอีกครั้ง]</a> </p></center>";
				}
				break;
			}else if($walletmoney == $checkid && $money == 39){
				$sql = "select * from users where username='".$_SESSION['user']['username']."'";
				$sqle = "SELECT * FROM histrory WHERE NumberWallet='$walletmoney'";
				$query = mysqli_query($con,$sqle);
				$result = mysqli_fetch_assoc($query);
				if($result['status'] == ''){
					echo "<center><B style='font-size: 60px;'><h1 style='color:green'>เติมเงินเรียบร้อย</h1>
					<h1>จำนวนเงิน ที่คุณเติมคือ $money บาท</h1>
					<h1>ขอบคุณที่ใช้บริการครับ !</h1></B>  
					<p><a href='/main'>[ไปเช่าเน็ตกันเถอะ]</a> </p></center>";
					$sql = "insert into histrory (NumberWallet,money,username,status) values ('$walletmoney','$money','".$_SESSION['user']['username']."',1)";
					mysqli_query($con,$sql);
					$sql1 = "insert into users (saldo) values ('$money') where username='".$_SESSION['user']['username']."'";
					$sql1 = "update users set saldo=saldo+'".$money."'where username='".$_SESSION['user']['username']."'";
					mysqli_query($con,$sql1) or die; ('Error Query');
				}else{
					echo "<center><B style='color:red'><h1 style='font-size: 80px;'>เกิดข้อผิดพลาด</h1>
		<h1 style='font-size: 80px;'>หมายเลขอ้างอิงนี้</h1>
		<h1 style='font-size: 80px;'>ถูกใช้งานแล้ว</h1></B>
		<p><a href='/topup/get.php'>[กลับไปลองอีกครั้ง]</a> </p></center>";
				}
				break;
				}else if($walletmoney == $checkid && $money == 40){
				$sql = "select * from users where username='".$_SESSION['user']['username']."'";
				$sqle = "SELECT * FROM histrory WHERE NumberWallet='$walletmoney'";
				$query = mysqli_query($con,$sqle);
				$result = mysqli_fetch_assoc($query);
				if($result['status'] == ''){
					echo "<center><B style='font-size: 60px;'><h1 style='color:green'>เติมเงินเรียบร้อย</h1>
					<h1>จำนวนเงิน ที่คุณเติมคือ $money บาท</h1>
					<h1>ขอบคุณที่ใช้บริการครับ !</h1></B>  
					<p><a href='/main'>[ไปเช่าเน็ตกันเถอะ]</a> </p></center>";
					$sql = "insert into histrory (NumberWallet,money,username,status) values ('$walletmoney','$money','".$_SESSION['user']['username']."',1)";
					mysqli_query($con,$sql);
					$sql1 = "insert into users (saldo) values ('$money') where username='".$_SESSION['user']['username']."'";
					$sql1 = "update users set saldo=saldo+'".$money."'where username='".$_SESSION['user']['username']."'";
					mysqli_query($con,$sql1) or die; ('Error Query');
				}else{
					echo "<center><B style='color:red'><h1 style='font-size: 80px;'>เกิดข้อผิดพลาด</h1>
		<h1 style='font-size: 80px;'>หมายเลขอ้างอิงนี้</h1>
		<h1 style='font-size: 80px;'>ถูกใช้งานแล้ว</h1></B>
		<p><a href='/topup/get.php'>[กลับไปลองอีกครั้ง]</a> </p></center>";
				}
				break;
				}else if($walletmoney == $checkid && $money == 41){
				$sql = "select * from users where username='".$_SESSION['user']['username']."'";
				$sqle = "SELECT * FROM histrory WHERE NumberWallet='$walletmoney'";
				$query = mysqli_query($con,$sqle);
				$result = mysqli_fetch_assoc($query);
				if($result['status'] == ''){
					echo "<center><B style='font-size: 60px;'><h1 style='color:green'>เติมเงินเรียบร้อย</h1>
					<h1>จำนวนเงิน ที่คุณเติมคือ $money บาท</h1>
					<h1>ขอบคุณที่ใช้บริการครับ !</h1></B>  
					<p><a href='/main'>[ไปเช่าเน็ตกันเถอะ]</a> </p></center>";
					$sql = "insert into histrory (NumberWallet,money,username,status) values ('$walletmoney','$money','".$_SESSION['user']['username']."',1)";
					mysqli_query($con,$sql);
					$sql1 = "insert into users (saldo) values ('$money') where username='".$_SESSION['user']['username']."'";
					$sql1 = "update users set saldo=saldo+'".$money."'where username='".$_SESSION['user']['username']."'";
					mysqli_query($con,$sql1) or die; ('Error Query');
				}else{
					echo "<center><B style='color:red'><h1 style='font-size: 80px;'>เกิดข้อผิดพลาด</h1>
		<h1 style='font-size: 80px;'>หมายเลขอ้างอิงนี้</h1>
		<h1 style='font-size: 80px;'>ถูกใช้งานแล้ว</h1></B>
		<p><a href='/topup/get.php'>[กลับไปลองอีกครั้ง]</a> </p></center>";
				}
				break;
				}else if($walletmoney == $checkid && $money == 42){
				$sql = "select * from users where username='".$_SESSION['user']['username']."'";
				$sqle = "SELECT * FROM histrory WHERE NumberWallet='$walletmoney'";
				$query = mysqli_query($con,$sqle);
				$result = mysqli_fetch_assoc($query);
				if($result['status'] == ''){
					echo "<center><B style='font-size: 60px;'><h1 style='color:green'>เติมเงินเรียบร้อย</h1>
					<h1>จำนวนเงิน ที่คุณเติมคือ $money บาท</h1>
					<h1>ขอบคุณที่ใช้บริการครับ !</h1></B>  
					<p><a href='/main'>[ไปเช่าเน็ตกันเถอะ]</a> </p></center>";
					$sql = "insert into histrory (NumberWallet,money,username,status) values ('$walletmoney','$money','".$_SESSION['user']['username']."',1)";
					mysqli_query($con,$sql);
					$sql1 = "insert into users (saldo) values ('$money') where username='".$_SESSION['user']['username']."'";
					$sql1 = "update users set saldo=saldo+'".$money."'where username='".$_SESSION['user']['username']."'";
					mysqli_query($con,$sql1) or die; ('Error Query');
				}else{
					echo "<center><B style='color:red'><h1 style='font-size: 80px;'>เกิดข้อผิดพลาด</h1>
		<h1 style='font-size: 80px;'>หมายเลขอ้างอิงนี้</h1>
		<h1 style='font-size: 80px;'>ถูกใช้งานแล้ว</h1></B>
		<p><a href='/topup/get.php'>[กลับไปลองอีกครั้ง]</a> </p></center>";
				}
				break;
				}else if($walletmoney == $checkid && $money == 43){
				$sql = "select * from users where username='".$_SESSION['user']['username']."'";
				$sqle = "SELECT * FROM histrory WHERE NumberWallet='$walletmoney'";
				$query = mysqli_query($con,$sqle);
				$result = mysqli_fetch_assoc($query);
				if($result['status'] == ''){
					echo "<center><B style='font-size: 60px;'><h1 style='color:green'>เติมเงินเรียบร้อย</h1>
					<h1>จำนวนเงิน ที่คุณเติมคือ $money บาท</h1>
					<h1>ขอบคุณที่ใช้บริการครับ !</h1></B>  
					<p><a href='/main'>[ไปเช่าเน็ตกันเถอะ]</a> </p></center>";
					$sql = "insert into histrory (NumberWallet,money,username,status) values ('$walletmoney','$money','".$_SESSION['user']['username']."',1)";
					mysqli_query($con,$sql);
					$sql1 = "insert into users (saldo) values ('$money') where username='".$_SESSION['user']['username']."'";
					$sql1 = "update users set saldo=saldo+'".$money."'where username='".$_SESSION['user']['username']."'";
					mysqli_query($con,$sql1) or die; ('Error Query');
				}else{
					echo "<center><B style='color:red'><h1 style='font-size: 80px;'>เกิดข้อผิดพลาด</h1>
		<h1 style='font-size: 80px;'>หมายเลขอ้างอิงนี้</h1>
		<h1 style='font-size: 80px;'>ถูกใช้งานแล้ว</h1></B>
		<p><a href='/topup/get.php'>[กลับไปลองอีกครั้ง]</a> </p></center>";
				}
				break;
				}else if($walletmoney == $checkid && $money == 44){
				$sql = "select * from users where username='".$_SESSION['user']['username']."'";
				$sqle = "SELECT * FROM histrory WHERE NumberWallet='$walletmoney'";
				$query = mysqli_query($con,$sqle);
				$result = mysqli_fetch_assoc($query);
				if($result['status'] == ''){
					echo "<center><B style='font-size: 60px;'><h1 style='color:green'>เติมเงินเรียบร้อย</h1>
					<h1>จำนวนเงิน ที่คุณเติมคือ $money บาท</h1>
					<h1>ขอบคุณที่ใช้บริการครับ !</h1></B>  
					<p><a href='/main'>[ไปเช่าเน็ตกันเถอะ]</a> </p></center>";
					$sql = "insert into histrory (NumberWallet,money,username,status) values ('$walletmoney','$money','".$_SESSION['user']['username']."',1)";
					mysqli_query($con,$sql);
					$sql1 = "insert into users (saldo) values ('$money') where username='".$_SESSION['user']['username']."'";
					$sql1 = "update users set saldo=saldo+'".$money."'where username='".$_SESSION['user']['username']."'";
					mysqli_query($con,$sql1) or die; ('Error Query');
				}else{
					echo "<center><B style='color:red'><h1 style='font-size: 80px;'>เกิดข้อผิดพลาด</h1>
		<h1 style='font-size: 80px;'>หมายเลขอ้างอิงนี้</h1>
		<h1 style='font-size: 80px;'>ถูกใช้งานแล้ว</h1></B>
		<p><a href='/topup/get.php'>[กลับไปลองอีกครั้ง]</a> </p></center>";
				}
				break;
				}else if($walletmoney == $checkid && $money == 45){
				$sql = "select * from users where username='".$_SESSION['user']['username']."'";
				$sqle = "SELECT * FROM histrory WHERE NumberWallet='$walletmoney'";
				$query = mysqli_query($con,$sqle);
				$result = mysqli_fetch_assoc($query);
				if($result['status'] == ''){
					echo "<center><B style='font-size: 60px;'><h1 style='color:green'>เติมเงินเรียบร้อย</h1>
					<h1>จำนวนเงิน ที่คุณเติมคือ $money บาท</h1>
					<h1>ขอบคุณที่ใช้บริการครับ !</h1></B>  
					<p><a href='/main'>[ไปเช่าเน็ตกันเถอะ]</a> </p></center>";
					$sql = "insert into histrory (NumberWallet,money,username,status) values ('$walletmoney','$money','".$_SESSION['user']['username']."',1)";
					mysqli_query($con,$sql);
					$sql1 = "insert into users (saldo) values ('$money') where username='".$_SESSION['user']['username']."'";
					$sql1 = "update users set saldo=saldo+'".$money."'where username='".$_SESSION['user']['username']."'";
					mysqli_query($con,$sql1) or die; ('Error Query');
				}else{
					echo "<center><B style='color:red'><h1 style='font-size: 80px;'>เกิดข้อผิดพลาด</h1>
		<h1 style='font-size: 80px;'>หมายเลขอ้างอิงนี้</h1>
		<h1 style='font-size: 80px;'>ถูกใช้งานแล้ว</h1></B>
		<p><a href='/topup/get.php'>[กลับไปลองอีกครั้ง]</a> </p></center>";
				}
				break;
				}else if($walletmoney == $checkid && $money == 46){
				$sql = "select * from users where username='".$_SESSION['user']['username']."'";
				$sqle = "SELECT * FROM histrory WHERE NumberWallet='$walletmoney'";
				$query = mysqli_query($con,$sqle);
				$result = mysqli_fetch_assoc($query);
				if($result['status'] == ''){
					echo "<center><B style='font-size: 60px;'><h1 style='color:green'>เติมเงินเรียบร้อย</h1>
					<h1>จำนวนเงิน ที่คุณเติมคือ $money บาท</h1>
					<h1>ขอบคุณที่ใช้บริการครับ !</h1></B>  
					<p><a href='/main'>[ไปเช่าเน็ตกันเถอะ]</a> </p></center>";
					$sql = "insert into histrory (NumberWallet,money,username,status) values ('$walletmoney','$money','".$_SESSION['user']['username']."',1)";
					mysqli_query($con,$sql);
					$sql1 = "insert into users (saldo) values ('$money') where username='".$_SESSION['user']['username']."'";
					$sql1 = "update users set saldo=saldo+'".$money."'where username='".$_SESSION['user']['username']."'";
					mysqli_query($con,$sql1) or die; ('Error Query');
				}else{
					echo "<center><B style='color:red'><h1 style='font-size: 80px;'>เกิดข้อผิดพลาด</h1>
		<h1 style='font-size: 80px;'>หมายเลขอ้างอิงนี้</h1>
		<h1 style='font-size: 80px;'>ถูกใช้งานแล้ว</h1></B>
		<p><a href='/topup/get.php'>[กลับไปลองอีกครั้ง]</a> </p></center>";
				}
				break;
				}else if($walletmoney == $checkid && $money == 47){
				$sql = "select * from users where username='".$_SESSION['user']['username']."'";
				$sqle = "SELECT * FROM histrory WHERE NumberWallet='$walletmoney'";
				$query = mysqli_query($con,$sqle);
				$result = mysqli_fetch_assoc($query);
				if($result['status'] == ''){
					echo "<center><B style='font-size: 60px;'><h1 style='color:green'>เติมเงินเรียบร้อย</h1>
					<h1>จำนวนเงิน ที่คุณเติมคือ $money บาท</h1>
					<h1>ขอบคุณที่ใช้บริการครับ !</h1></B>  
					<p><a href='/main'>[ไปเช่าเน็ตกันเถอะ]</a> </p></center>";
					$sql = "insert into histrory (NumberWallet,money,username,status) values ('$walletmoney','$money','".$_SESSION['user']['username']."',1)";
					mysqli_query($con,$sql);
					$sql1 = "insert into users (saldo) values ('$money') where username='".$_SESSION['user']['username']."'";
					$sql1 = "update users set saldo=saldo+'".$money."'where username='".$_SESSION['user']['username']."'";
					mysqli_query($con,$sql1) or die; ('Error Query');
				}else{
					echo "<center><B style='color:red'><h1 style='font-size: 80px;'>เกิดข้อผิดพลาด</h1>
		<h1 style='font-size: 80px;'>หมายเลขอ้างอิงนี้</h1>
		<h1 style='font-size: 80px;'>ถูกใช้งานแล้ว</h1></B>
		<p><a href='/topup/get.php'>[กลับไปลองอีกครั้ง]</a> </p></center>";
				}
				break;
				}else if($walletmoney == $checkid && $money == 48){
				$sql = "select * from users where username='".$_SESSION['user']['username']."'";
				$sqle = "SELECT * FROM histrory WHERE NumberWallet='$walletmoney'";
				$query = mysqli_query($con,$sqle);
				$result = mysqli_fetch_assoc($query);
				if($result['status'] == ''){
					echo "<center><B style='font-size: 60px;'><h1 style='color:green'>เติมเงินเรียบร้อย</h1>
					<h1>จำนวนเงิน ที่คุณเติมคือ $money บาท</h1>
					<h1>ขอบคุณที่ใช้บริการครับ !</h1></B>  
					<p><a href='/main'>[ไปเช่าเน็ตกันเถอะ]</a> </p></center>";
					$sql = "insert into histrory (NumberWallet,money,username,status) values ('$walletmoney','$money','".$_SESSION['user']['username']."',1)";
					mysqli_query($con,$sql);
					$sql1 = "insert into users (saldo) values ('$money') where username='".$_SESSION['user']['username']."'";
					$sql1 = "update users set saldo=saldo+'".$money."'where username='".$_SESSION['user']['username']."'";
					mysqli_query($con,$sql1) or die; ('Error Query');
				}else{
					echo "<center><B style='color:red'><h1 style='font-size: 80px;'>เกิดข้อผิดพลาด</h1>
		<h1 style='font-size: 80px;'>หมายเลขอ้างอิงนี้</h1>
		<h1 style='font-size: 80px;'>ถูกใช้งานแล้ว</h1></B>
		<p><a href='/topup/get.php'>[กลับไปลองอีกครั้ง]</a> </p></center>";
				}
				break;
			}else if($walletmoney == $checkid && $money == 49){
				$sql = "select * from users where username='".$_SESSION['user']['username']."'";
				$sqle = "SELECT * FROM histrory WHERE NumberWallet='$walletmoney'";
				$query = mysqli_query($con,$sqle);
				$result = mysqli_fetch_assoc($query);
				if($result['status'] == ''){
					echo "<center><B style='font-size: 60px;'><h1 style='color:green'>เติมเงินเรียบร้อย</h1>
					<h1>จำนวนเงิน ที่คุณเติมคือ $money บาท</h1>
					<h1>ขอบคุณที่ใช้บริการครับ !</h1></B>  
					<p><a href='/main'>[ไปเช่าเน็ตกันเถอะ]</a> </p></center>";
					$sql = "insert into histrory (NumberWallet,money,username,status) values ('$walletmoney','$money','".$_SESSION['user']['username']."',1)";
					mysqli_query($con,$sql);
					$sql1 = "insert into users (saldo) values ('$money') where username='".$_SESSION['user']['username']."'";
					$sql1 = "update users set saldo=saldo+'".$money."'where username='".$_SESSION['user']['username']."'";
					mysqli_query($con,$sql1) or die; ('Error Query');
				}else{
					echo "<center><B style='color:red'><h1 style='font-size: 80px;'>เกิดข้อผิดพลาด</h1>
		<h1 style='font-size: 80px;'>หมายเลขอ้างอิงนี้</h1>
		<h1 style='font-size: 80px;'>ถูกใช้งานแล้ว</h1></B>
		<p><a href='/topup/get.php'>[กลับไปลองอีกครั้ง]</a> </p></center>";
				}
				break;
				}else if($walletmoney == $checkid && $money == 50){
				$sql = "select * from users where username='".$_SESSION['user']['username']."'";
				$sqle = "SELECT * FROM histrory WHERE NumberWallet='$walletmoney'";
				$query = mysqli_query($con,$sqle);
				$result = mysqli_fetch_assoc($query);
				if($result['status'] == ''){
					echo "<center><B style='font-size: 60px;'><h1 style='color:green'>เติมเงินเรียบร้อย</h1>
					<h1>จำนวนเงิน ที่คุณเติมคือ $money บาท</h1>
					<h1>ขอบคุณที่ใช้บริการครับ !</h1></B>  
					<p><a href='/main'>[ไปเช่าเน็ตกันเถอะ]</a> </p></center>";
					$sql = "insert into histrory (NumberWallet,money,username,status) values ('$walletmoney','$money','".$_SESSION['user']['username']."',1)";
					mysqli_query($con,$sql);
					$sql1 = "insert into users (saldo) values ('$money') where username='".$_SESSION['user']['username']."'";
					$sql1 = "update users set saldo=saldo+'".$money."'where username='".$_SESSION['user']['username']."'";
					mysqli_query($con,$sql1) or die; ('Error Query');
				}else{
					echo "<center><B style='color:red'><h1 style='font-size: 80px;'>เกิดข้อผิดพลาด</h1>
		<h1 style='font-size: 80px;'>หมายเลขอ้างอิงนี้</h1>
		<h1 style='font-size: 80px;'>ถูกใช้งานแล้ว</h1></B>
		<p><a href='/topup/get.php'>[กลับไปลองอีกครั้ง]</a> </p></center>";
				}
				break;
				}else if($walletmoney == $checkid && $money == 51){
				$sql = "select * from users where username='".$_SESSION['user']['username']."'";
				$sqle = "SELECT * FROM histrory WHERE NumberWallet='$walletmoney'";
				$query = mysqli_query($con,$sqle);
				$result = mysqli_fetch_assoc($query);
				if($result['status'] == ''){
					echo "<center><B style='font-size: 60px;'><h1 style='color:green'>เติมเงินเรียบร้อย</h1>
					<h1>จำนวนเงิน ที่คุณเติมคือ $money บาท</h1>
					<h1>ขอบคุณที่ใช้บริการครับ !</h1></B>  
					<p><a href='/main'>[ไปเช่าเน็ตกันเถอะ]</a> </p></center>";
					$sql = "insert into histrory (NumberWallet,money,username,status) values ('$walletmoney','$money','".$_SESSION['user']['username']."',1)";
					mysqli_query($con,$sql);
					$sql1 = "insert into users (saldo) values ('$money') where username='".$_SESSION['user']['username']."'";
					$sql1 = "update users set saldo=saldo+'".$money."'where username='".$_SESSION['user']['username']."'";
					mysqli_query($con,$sql1) or die; ('Error Query');
				}else{
					echo "<center><B style='color:red'><h1 style='font-size: 80px;'>เกิดข้อผิดพลาด</h1>
		<h1 style='font-size: 80px;'>หมายเลขอ้างอิงนี้</h1>
		<h1 style='font-size: 80px;'>ถูกใช้งานแล้ว</h1></B>
		<p><a href='/topup/get.php'>[กลับไปลองอีกครั้ง]</a> </p></center>";
				}
				break;
				}else if($walletmoney == $checkid && $money == 52){
				$sql = "select * from users where username='".$_SESSION['user']['username']."'";
				$sqle = "SELECT * FROM histrory WHERE NumberWallet='$walletmoney'";
				$query = mysqli_query($con,$sqle);
				$result = mysqli_fetch_assoc($query);
				if($result['status'] == ''){
					echo "<center><B style='font-size: 60px;'><h1 style='color:green'>เติมเงินเรียบร้อย</h1>
					<h1>จำนวนเงิน ที่คุณเติมคือ $money บาท</h1>
					<h1>ขอบคุณที่ใช้บริการครับ !</h1></B>  
					<p><a href='/main'>[ไปเช่าเน็ตกันเถอะ]</a> </p></center>";
					$sql = "insert into histrory (NumberWallet,money,username,status) values ('$walletmoney','$money','".$_SESSION['user']['username']."',1)";
					mysqli_query($con,$sql);
					$sql1 = "insert into users (saldo) values ('$money') where username='".$_SESSION['user']['username']."'";
					$sql1 = "update users set saldo=saldo+'".$money."'where username='".$_SESSION['user']['username']."'";
					mysqli_query($con,$sql1) or die; ('Error Query');
				}else{
					echo "<center><B style='color:red'><h1 style='font-size: 80px;'>เกิดข้อผิดพลาด</h1>
		<h1 style='font-size: 80px;'>หมายเลขอ้างอิงนี้</h1>
		<h1 style='font-size: 80px;'>ถูกใช้งานแล้ว</h1></B>
		<p><a href='/topup/get.php'>[กลับไปลองอีกครั้ง]</a> </p></center>";
				}
				break;
				}else if($walletmoney == $checkid && $money == 53){
				$sql = "select * from users where username='".$_SESSION['user']['username']."'";
				$sqle = "SELECT * FROM histrory WHERE NumberWallet='$walletmoney'";
				$query = mysqli_query($con,$sqle);
				$result = mysqli_fetch_assoc($query);
				if($result['status'] == ''){
					echo "<center><B style='font-size: 60px;'><h1 style='color:green'>เติมเงินเรียบร้อย</h1>
					<h1>จำนวนเงิน ที่คุณเติมคือ $money บาท</h1>
					<h1>ขอบคุณที่ใช้บริการครับ !</h1></B>  
					<p><a href='/main'>[ไปเช่าเน็ตกันเถอะ]</a> </p></center>";
					$sql = "insert into histrory (NumberWallet,money,username,status) values ('$walletmoney','$money','".$_SESSION['user']['username']."',1)";
					mysqli_query($con,$sql);
					$sql1 = "insert into users (saldo) values ('$money') where username='".$_SESSION['user']['username']."'";
					$sql1 = "update users set saldo=saldo+'".$money."'where username='".$_SESSION['user']['username']."'";
					mysqli_query($con,$sql1) or die; ('Error Query');
				}else{
					echo "<center><B style='color:red'><h1 style='font-size: 80px;'>เกิดข้อผิดพลาด</h1>
		<h1 style='font-size: 80px;'>หมายเลขอ้างอิงนี้</h1>
		<h1 style='font-size: 80px;'>ถูกใช้งานแล้ว</h1></B>
		<p><a href='/topup/get.php'>[กลับไปลองอีกครั้ง]</a> </p></center>";
				}
				break;
				}else if($walletmoney == $checkid && $money == 54){
				$sql = "select * from users where username='".$_SESSION['user']['username']."'";
				$sqle = "SELECT * FROM histrory WHERE NumberWallet='$walletmoney'";
				$query = mysqli_query($con,$sqle);
				$result = mysqli_fetch_assoc($query);
				if($result['status'] == ''){
					echo "<center><B style='font-size: 60px;'><h1 style='color:green'>เติมเงินเรียบร้อย</h1>
					<h1>จำนวนเงิน ที่คุณเติมคือ $money บาท</h1>
					<h1>ขอบคุณที่ใช้บริการครับ !</h1></B>  
					<p><a href='/main'>[ไปเช่าเน็ตกันเถอะ]</a> </p></center>";
					$sql = "insert into histrory (NumberWallet,money,username,status) values ('$walletmoney','$money','".$_SESSION['user']['username']."',1)";
					mysqli_query($con,$sql);
					$sql1 = "insert into users (saldo) values ('$money') where username='".$_SESSION['user']['username']."'";
					$sql1 = "update users set saldo=saldo+'".$money."'where username='".$_SESSION['user']['username']."'";
					mysqli_query($con,$sql1) or die; ('Error Query');
				}else{
					echo "<center><B style='color:red'><h1 style='font-size: 80px;'>เกิดข้อผิดพลาด</h1>
		<h1 style='font-size: 80px;'>หมายเลขอ้างอิงนี้</h1>
		<h1 style='font-size: 80px;'>ถูกใช้งานแล้ว</h1></B>
		<p><a href='/topup/get.php'>[กลับไปลองอีกครั้ง]</a> </p></center>";
				}
				break;
				}else if($walletmoney == $checkid && $money == 55){
				$sql = "select * from users where username='".$_SESSION['user']['username']."'";
				$sqle = "SELECT * FROM histrory WHERE NumberWallet='$walletmoney'";
				$query = mysqli_query($con,$sqle);
				$result = mysqli_fetch_assoc($query);
				if($result['status'] == ''){
					echo "<center><B style='font-size: 60px;'><h1 style='color:green'>เติมเงินเรียบร้อย</h1>
					<h1>จำนวนเงิน ที่คุณเติมคือ $money บาท</h1>
					<h1>ขอบคุณที่ใช้บริการครับ !</h1></B>  
					<p><a href='/main'>[ไปเช่าเน็ตกันเถอะ]</a> </p></center>";
					$sql = "insert into histrory (NumberWallet,money,username,status) values ('$walletmoney','$money','".$_SESSION['user']['username']."',1)";
					mysqli_query($con,$sql);
					$sql1 = "insert into users (saldo) values ('$money') where username='".$_SESSION['user']['username']."'";
					$sql1 = "update users set saldo=saldo+'".$money."'where username='".$_SESSION['user']['username']."'";
					mysqli_query($con,$sql1) or die; ('Error Query');
				}else{
					echo "<center><B style='color:red'><h1 style='font-size: 80px;'>เกิดข้อผิดพลาด</h1>
		<h1 style='font-size: 80px;'>หมายเลขอ้างอิงนี้</h1>
		<h1 style='font-size: 80px;'>ถูกใช้งานแล้ว</h1></B>
		<p><a href='/topup/get.php'>[กลับไปลองอีกครั้ง]</a> </p></center>";
				}
				break;
				}else if($walletmoney == $checkid && $money == 56){
				$sql = "select * from users where username='".$_SESSION['user']['username']."'";
				$sqle = "SELECT * FROM histrory WHERE NumberWallet='$walletmoney'";
				$query = mysqli_query($con,$sqle);
				$result = mysqli_fetch_assoc($query);
				if($result['status'] == ''){
					echo "<center><B style='font-size: 60px;'><h1 style='color:green'>เติมเงินเรียบร้อย</h1>
					<h1>จำนวนเงิน ที่คุณเติมคือ $money บาท</h1>
					<h1>ขอบคุณที่ใช้บริการครับ !</h1></B>  
					<p><a href='/main'>[ไปเช่าเน็ตกันเถอะ]</a> </p></center>";
					$sql = "insert into histrory (NumberWallet,money,username,status) values ('$walletmoney','$money','".$_SESSION['user']['username']."',1)";
					mysqli_query($con,$sql);
					$sql1 = "insert into users (saldo) values ('$money') where username='".$_SESSION['user']['username']."'";
					$sql1 = "update users set saldo=saldo+'".$money."'where username='".$_SESSION['user']['username']."'";
					mysqli_query($con,$sql1) or die; ('Error Query');
				}else{
					echo "<center><B style='color:red'><h1 style='font-size: 80px;'>เกิดข้อผิดพลาด</h1>
		<h1 style='font-size: 80px;'>หมายเลขอ้างอิงนี้</h1>
		<h1 style='font-size: 80px;'>ถูกใช้งานแล้ว</h1></B>
		<p><a href='/topup/get.php'>[กลับไปลองอีกครั้ง]</a> </p></center>";
				}
				break;
				}else if($walletmoney == $checkid && $money == 57){
				$sql = "select * from users where username='".$_SESSION['user']['username']."'";
				$sqle = "SELECT * FROM histrory WHERE NumberWallet='$walletmoney'";
				$query = mysqli_query($con,$sqle);
				$result = mysqli_fetch_assoc($query);
				if($result['status'] == ''){
					echo "<center><B style='font-size: 60px;'><h1 style='color:green'>เติมเงินเรียบร้อย</h1>
					<h1>จำนวนเงิน ที่คุณเติมคือ $money บาท</h1>
					<h1>ขอบคุณที่ใช้บริการครับ !</h1></B>  
					<p><a href='/main'>[ไปเช่าเน็ตกันเถอะ]</a> </p></center>";
					$sql = "insert into histrory (NumberWallet,money,username,status) values ('$walletmoney','$money','".$_SESSION['user']['username']."',1)";
					mysqli_query($con,$sql);
					$sql1 = "insert into users (saldo) values ('$money') where username='".$_SESSION['user']['username']."'";
					$sql1 = "update users set saldo=saldo+'".$money."'where username='".$_SESSION['user']['username']."'";
					mysqli_query($con,$sql1) or die; ('Error Query');
				}else{
					echo "<center><B style='color:red'><h1 style='font-size: 80px;'>เกิดข้อผิดพลาด</h1>
		<h1 style='font-size: 80px;'>หมายเลขอ้างอิงนี้</h1>
		<h1 style='font-size: 80px;'>ถูกใช้งานแล้ว</h1></B>
		<p><a href='/topup/get.php'>[กลับไปลองอีกครั้ง]</a> </p></center>";
				}
				break;
				}else if($walletmoney == $checkid && $money == 58){
				$sql = "select * from users where username='".$_SESSION['user']['username']."'";
				$sqle = "SELECT * FROM histrory WHERE NumberWallet='$walletmoney'";
				$query = mysqli_query($con,$sqle);
				$result = mysqli_fetch_assoc($query);
				if($result['status'] == ''){
					echo "<center><B style='font-size: 60px;'><h1 style='color:green'>เติมเงินเรียบร้อย</h1>
					<h1>จำนวนเงิน ที่คุณเติมคือ $money บาท</h1>
					<h1>ขอบคุณที่ใช้บริการครับ !</h1></B>  
					<p><a href='/main'>[ไปเช่าเน็ตกันเถอะ]</a> </p></center>";
					$sql = "insert into histrory (NumberWallet,money,username,status) values ('$walletmoney','$money','".$_SESSION['user']['username']."',1)";
					mysqli_query($con,$sql);
					$sql1 = "insert into users (saldo) values ('$money') where username='".$_SESSION['user']['username']."'";
					$sql1 = "update users set saldo=saldo+'".$money."'where username='".$_SESSION['user']['username']."'";
					mysqli_query($con,$sql1) or die; ('Error Query');
				}else{
					echo "<center><B style='color:red'><h1 style='font-size: 80px;'>เกิดข้อผิดพลาด</h1>
		<h1 style='font-size: 80px;'>หมายเลขอ้างอิงนี้</h1>
		<h1 style='font-size: 80px;'>ถูกใช้งานแล้ว</h1></B>
		<p><a href='/topup/get.php'>[กลับไปลองอีกครั้ง]</a> </p></center>";
				}
				break;
			}else if($walletmoney == $checkid && $money == 59){
				$sql = "select * from users where username='".$_SESSION['user']['username']."'";
				$sqle = "SELECT * FROM histrory WHERE NumberWallet='$walletmoney'";
				$query = mysqli_query($con,$sqle);
				$result = mysqli_fetch_assoc($query);
				if($result['status'] == ''){
					echo "<center><B style='font-size: 60px;'><h1 style='color:green'>เติมเงินเรียบร้อย</h1>
					<h1>จำนวนเงิน ที่คุณเติมคือ $money บาท</h1>
					<h1>ขอบคุณที่ใช้บริการครับ !</h1></B>  
					<p><a href='/main'>[ไปเช่าเน็ตกันเถอะ]</a> </p></center>";
					$sql = "insert into histrory (NumberWallet,money,username,status) values ('$walletmoney','$money','".$_SESSION['user']['username']."',1)";
					mysqli_query($con,$sql);
					$sql1 = "insert into users (saldo) values ('$money') where username='".$_SESSION['user']['username']."'";
					$sql1 = "update users set saldo=saldo+'".$money."'where username='".$_SESSION['user']['username']."'";
					mysqli_query($con,$sql1) or die; ('Error Query');
				}else{
					echo "<center><B style='color:red'><h1 style='font-size: 80px;'>เกิดข้อผิดพลาด</h1>
		<h1 style='font-size: 80px;'>หมายเลขอ้างอิงนี้</h1>
		<h1 style='font-size: 80px;'>ถูกใช้งานแล้ว</h1></B>
		<p><a href='/topup/get.php'>[กลับไปลองอีกครั้ง]</a> </p></center>";
				}
				break;
				}else if($walletmoney == $checkid && $money == 60){
				$sql = "select * from users where username='".$_SESSION['user']['username']."'";
				$sqle = "SELECT * FROM histrory WHERE NumberWallet='$walletmoney'";
				$query = mysqli_query($con,$sqle);
				$result = mysqli_fetch_assoc($query);
				if($result['status'] == ''){
					echo "<center><B style='font-size: 60px;'><h1 style='color:green'>เติมเงินเรียบร้อย</h1>
					<h1>จำนวนเงิน ที่คุณเติมคือ $money บาท</h1>
					<h1>ขอบคุณที่ใช้บริการครับ !</h1></B>  
					<p><a href='/main'>[ไปเช่าเน็ตกันเถอะ]</a> </p></center>";
					$sql = "insert into histrory (NumberWallet,money,username,status) values ('$walletmoney','$money','".$_SESSION['user']['username']."',1)";
					mysqli_query($con,$sql);
					$sql1 = "insert into users (saldo) values ('$money') where username='".$_SESSION['user']['username']."'";
					$sql1 = "update users set saldo=saldo+'".$money."'where username='".$_SESSION['user']['username']."'";
					mysqli_query($con,$sql1) or die; ('Error Query');
				}else{
					echo "<center><B style='color:red'><h1 style='font-size: 80px;'>เกิดข้อผิดพลาด</h1>
		<h1 style='font-size: 80px;'>หมายเลขอ้างอิงนี้</h1>
		<h1 style='font-size: 80px;'>ถูกใช้งานแล้ว</h1></B>
		<p><a href='/topup/get.php'>[กลับไปลองอีกครั้ง]</a> </p></center>";
				}
				break;
			}else if($walletmoney == $checkid && $money == 65){
				$sql = "select * from users where username='".$_SESSION['user']['username']."'";
				$sqle = "SELECT * FROM histrory WHERE NumberWallet='$walletmoney'";
				$query = mysqli_query($con,$sqle);
				$result = mysqli_fetch_assoc($query);
				if($result['status'] == ''){
					echo "<center><B style='font-size: 60px;'><h1 style='color:green'>เติมเงินเรียบร้อย</h1>
					<h1>จำนวนเงิน ที่คุณเติมคือ $money บาท</h1>
					<h1>ขอบคุณที่ใช้บริการครับ !</h1></B>  
					<p><a href='/main'>[ไปเช่าเน็ตกันเถอะ]</a> </p></center>";
					$sql = "insert into histrory (NumberWallet,money,username,status) values ('$walletmoney','$money','".$_SESSION['user']['username']."',1)";
					mysqli_query($con,$sql);
					$sql1 = "insert into users (saldo) values ('$money') where username='".$_SESSION['user']['username']."'";
					$sql1 = "update users set saldo=saldo+'".$money."'where username='".$_SESSION['user']['username']."'";
					mysqli_query($con,$sql1) or die; ('Error Query');
				}else{
					echo "<center><B style='color:red'><h1 style='font-size: 80px;'>เกิดข้อผิดพลาด</h1>
		<h1 style='font-size: 80px;'>หมายเลขอ้างอิงนี้</h1>
		<h1 style='font-size: 80px;'>ถูกใช้งานแล้ว</h1></B>
		<p><a href='/topup/get.php'>[กลับไปลองอีกครั้ง]</a> </p></center>";
				}
				break;
				}else if($walletmoney == $checkid && $money == 70){
				$sql = "select * from users where username='".$_SESSION['user']['username']."'";
				$sqle = "SELECT * FROM histrory WHERE NumberWallet='$walletmoney'";
				$query = mysqli_query($con,$sqle);
				$result = mysqli_fetch_assoc($query);
				if($result['status'] == ''){
					echo "<center><B style='font-size: 60px;'><h1 style='color:green'>เติมเงินเรียบร้อย</h1>
					<h1>จำนวนเงิน ที่คุณเติมคือ $money บาท</h1>
					<h1>ขอบคุณที่ใช้บริการครับ !</h1></B>  
					<p><a href='/main'>[ไปเช่าเน็ตกันเถอะ]</a> </p></center>";
					$sql = "insert into histrory (NumberWallet,money,username,status) values ('$walletmoney','$money','".$_SESSION['user']['username']."',1)";
					mysqli_query($con,$sql);
					$sql1 = "insert into users (saldo) values ('$money') where username='".$_SESSION['user']['username']."'";
					$sql1 = "update users set saldo=saldo+'".$money."'where username='".$_SESSION['user']['username']."'";
					mysqli_query($con,$sql1) or die; ('Error Query');
				}else{
					echo "<center><B style='color:red'><h1 style='font-size: 80px;'>เกิดข้อผิดพลาด</h1>
		<h1 style='font-size: 80px;'>หมายเลขอ้างอิงนี้</h1>
		<h1 style='font-size: 80px;'>ถูกใช้งานแล้ว</h1></B>
		<p><a href='/topup/get.php'>[กลับไปลองอีกครั้ง]</a> </p></center>";
				}
				break;
			}else if($walletmoney == $checkid && $money == 75){
				$sql = "select * from users where username='".$_SESSION['user']['username']."'";
				$sqle = "SELECT * FROM histrory WHERE NumberWallet='$walletmoney'";
				$query = mysqli_query($con,$sqle);
				$result = mysqli_fetch_assoc($query);
				if($result['status'] == ''){
					echo "<center><B style='font-size: 60px;'><h1 style='color:green'>เติมเงินเรียบร้อย</h1>
					<h1>จำนวนเงิน ที่คุณเติมคือ $money บาท</h1>
					<h1>ขอบคุณที่ใช้บริการครับ !</h1></B>  
					<p><a href='/main'>[ไปเช่าเน็ตกันเถอะ]</a> </p></center>";
					$sql = "insert into histrory (NumberWallet,money,username,status) values ('$walletmoney','$money','".$_SESSION['user']['username']."',1)";
					mysqli_query($con,$sql);
					$sql1 = "insert into users (saldo) values ('$money') where username='".$_SESSION['user']['username']."'";
					$sql1 = "update users set saldo=saldo+'".$money."'where username='".$_SESSION['user']['username']."'";
					mysqli_query($con,$sql1) or die; ('Error Query');
				}else{
					echo "<center><B style='color:red'><h1 style='font-size: 80px;'>เกิดข้อผิดพลาด</h1>
		<h1 style='font-size: 80px;'>หมายเลขอ้างอิงนี้</h1>
		<h1 style='font-size: 80px;'>ถูกใช้งานแล้ว</h1></B>
		<p><a href='/topup/get.php'>[กลับไปลองอีกครั้ง]</a> </p></center>";
				}
				break;
				}else if($walletmoney == $checkid && $money == 80){
				$sql = "select * from users where username='".$_SESSION['user']['username']."'";
				$sqle = "SELECT * FROM histrory WHERE NumberWallet='$walletmoney'";
				$query = mysqli_query($con,$sqle);
				$result = mysqli_fetch_assoc($query);
				if($result['status'] == ''){
					echo "<center><B style='font-size: 60px;'><h1 style='color:green'>เติมเงินเรียบร้อย</h1>
					<h1>จำนวนเงิน ที่คุณเติมคือ $money บาท</h1>
					<h1>ขอบคุณที่ใช้บริการครับ !</h1></B>  
					<p><a href='/main'>[ไปเช่าเน็ตกันเถอะ]</a> </p></center>";
					$sql = "insert into histrory (NumberWallet,money,username,status) values ('$walletmoney','$money','".$_SESSION['user']['username']."',1)";
					mysqli_query($con,$sql);
					$sql1 = "insert into users (saldo) values ('$money') where username='".$_SESSION['user']['username']."'";
					$sql1 = "update users set saldo=saldo+'".$money."'where username='".$_SESSION['user']['username']."'";
					mysqli_query($con,$sql1) or die; ('Error Query');
				}else{
					echo "<center><B style='color:red'><h1 style='font-size: 80px;'>เกิดข้อผิดพลาด</h1>
		<h1 style='font-size: 80px;'>หมายเลขอ้างอิงนี้</h1>
		<h1 style='font-size: 80px;'>ถูกใช้งานแล้ว</h1></B>
		<p><a href='/topup/get.php'>[กลับไปลองอีกครั้ง]</a> </p></center>";
				}
				break;
			}else if($walletmoney == $checkid && $money == 85){
				$sql = "select * from users where username='".$_SESSION['user']['username']."'";
				$sqle = "SELECT * FROM histrory WHERE NumberWallet='$walletmoney'";
				$query = mysqli_query($con,$sqle);
				$result = mysqli_fetch_assoc($query);
				if($result['status'] == ''){
					echo "<center><B style='font-size: 60px;'><h1 style='color:green'>เติมเงินเรียบร้อย</h1>
					<h1>จำนวนเงิน ที่คุณเติมคือ $money บาท</h1>
					<h1>ขอบคุณที่ใช้บริการครับ !</h1></B>  
					<p><a href='/main'>[ไปเช่าเน็ตกันเถอะ]</a> </p></center>";
					$sql = "insert into histrory (NumberWallet,money,username,status) values ('$walletmoney','$money','".$_SESSION['user']['username']."',1)";
					mysqli_query($con,$sql);
					$sql1 = "insert into users (saldo) values ('$money') where username='".$_SESSION['user']['username']."'";
					$sql1 = "update users set saldo=saldo+'".$money."'where username='".$_SESSION['user']['username']."'";
					mysqli_query($con,$sql1) or die; ('Error Query');
				}else{
					echo "<center><B style='color:red'><h1 style='font-size: 80px;'>เกิดข้อผิดพลาด</h1>
		<h1 style='font-size: 80px;'>หมายเลขอ้างอิงนี้</h1>
		<h1 style='font-size: 80px;'>ถูกใช้งานแล้ว</h1></B>
		<p><a href='/topup/get.php'>[กลับไปลองอีกครั้ง]</a> </p></center>";
				}
				break;
				}else if($walletmoney == $checkid && $money == 90){
				$sql = "select * from users where username='".$_SESSION['user']['username']."'";
				$sqle = "SELECT * FROM histrory WHERE NumberWallet='$walletmoney'";
				$query = mysqli_query($con,$sqle);
				$result = mysqli_fetch_assoc($query);
				if($result['status'] == ''){
					echo "<center><B style='font-size: 60px;'><h1 style='color:green'>เติมเงินเรียบร้อย</h1>
					<h1>จำนวนเงิน ที่คุณเติมคือ $money บาท</h1>
					<h1>ขอบคุณที่ใช้บริการครับ !</h1></B>  
					<p><a href='/main'>[ไปเช่าเน็ตกันเถอะ]</a> </p></center>";
					$sql = "insert into histrory (NumberWallet,money,username,status) values ('$walletmoney','$money','".$_SESSION['user']['username']."',1)";
					mysqli_query($con,$sql);
					$sql1 = "insert into users (saldo) values ('$money') where username='".$_SESSION['user']['username']."'";
					$sql1 = "update users set saldo=saldo+'".$money."'where username='".$_SESSION['user']['username']."'";
					mysqli_query($con,$sql1) or die; ('Error Query');
				}else{
					echo "<center><B style='color:red'><h1 style='font-size: 80px;'>เกิดข้อผิดพลาด</h1>
		<h1 style='font-size: 80px;'>หมายเลขอ้างอิงนี้</h1>
		<h1 style='font-size: 80px;'>ถูกใช้งานแล้ว</h1></B>
		<p><a href='/topup/get.php'>[กลับไปลองอีกครั้ง]</a> </p></center>";
				}
				break;
			}else if($walletmoney == $checkid && $money == 95){
				$sql = "select * from users where username='".$_SESSION['user']['username']."'";
				$sqle = "SELECT * FROM histrory WHERE NumberWallet='$walletmoney'";
				$query = mysqli_query($con,$sqle);
				$result = mysqli_fetch_assoc($query);
				if($result['status'] == ''){
					echo "<center><B style='font-size: 60px;'><h1 style='color:green'>เติมเงินเรียบร้อย</h1>
					<h1>จำนวนเงิน ที่คุณเติมคือ $money บาท</h1>
					<h1>ขอบคุณที่ใช้บริการครับ !</h1></B>  
					<p><a href='/main'>[ไปเช่าเน็ตกันเถอะ]</a> </p></center>";
					$sql = "insert into histrory (NumberWallet,money,username,status) values ('$walletmoney','$money','".$_SESSION['user']['username']."',1)";
					mysqli_query($con,$sql);
					$sql1 = "insert into users (saldo) values ('$money') where username='".$_SESSION['user']['username']."'";
					$sql1 = "update users set saldo=saldo+'".$money."'where username='".$_SESSION['user']['username']."'";
					mysqli_query($con,$sql1) or die; ('Error Query');
				}else{
					echo "<center><B style='color:red'><h1 style='font-size: 80px;'>เกิดข้อผิดพลาด</h1>
		<h1 style='font-size: 80px;'>หมายเลขอ้างอิงนี้</h1>
		<h1 style='font-size: 80px;'>ถูกใช้งานแล้ว</h1></B>
		<p><a href='/topup/get.php'>[กลับไปลองอีกครั้ง]</a> </p></center>";
				}
				break;
				}else if($walletmoney == $checkid && $money == 100){
				$sql = "select * from users where username='".$_SESSION['user']['username']."'";
				$sqle = "SELECT * FROM histrory WHERE NumberWallet='$walletmoney'";
				$query = mysqli_query($con,$sqle);
				$result = mysqli_fetch_assoc($query);
				if($result['status'] == ''){
					echo "<center><B style='font-size: 60px;'><h1 style='color:green'>เติมเงินเรียบร้อย</h1>
					<h1>จำนวนเงิน ที่คุณเติมคือ $money บาท</h1>
					<h1>ขอบคุณที่ใช้บริการครับ !</h1></B>  
					<p><a href='/main'>[ไปเช่าเน็ตกันเถอะ]</a> </p></center>";
					$sql = "insert into histrory (NumberWallet,money,username,status) values ('$walletmoney','$money','".$_SESSION['user']['username']."',1)";
					mysqli_query($con,$sql);
					$sql1 = "insert into users (saldo) values ('$money') where username='".$_SESSION['user']['username']."'";
					$sql1 = "update users set saldo=saldo+'".$money."'where username='".$_SESSION['user']['username']."'";
					mysqli_query($con,$sql1) or die; ('Error Query');
				}else{
					echo "<center><B style='color:red'><h1 style='font-size: 80px;'>เกิดข้อผิดพลาด</h1>
		<h1 style='font-size: 80px;'>หมายเลขอ้างอิงนี้</h1>
		<h1 style='font-size: 80px;'>ถูกใช้งานแล้ว</h1></B>
		<p><a href='/topup/get.php'>[กลับไปลองอีกครั้ง]</a> </p></center>";
				}
				break;
			}else if($walletmoney == $checkid && $money == 105){
				$sql = "select * from users where username='".$_SESSION['user']['username']."'";
				$sqle = "SELECT * FROM histrory WHERE NumberWallet='$walletmoney'";
				$query = mysqli_query($con,$sqle);
				$result = mysqli_fetch_assoc($query);
				if($result['status'] == ''){
					echo "<center><B style='font-size: 60px;'><h1 style='color:green'>เติมเงินเรียบร้อย</h1>
					<h1>จำนวนเงิน ที่คุณเติมคือ $money บาท</h1>
					<h1>ขอบคุณที่ใช้บริการครับ !</h1></B>  
					<p><a href='/main'>[ไปเช่าเน็ตกันเถอะ]</a> </p></center>";
					$sql = "insert into histrory (NumberWallet,money,username,status) values ('$walletmoney','$money','".$_SESSION['user']['username']."',1)";
					mysqli_query($con,$sql);
					$sql1 = "insert into users (saldo) values ('$money') where username='".$_SESSION['user']['username']."'";
					$sql1 = "update users set saldo=saldo+'".$money."'where username='".$_SESSION['user']['username']."'";
					mysqli_query($con,$sql1) or die; ('Error Query');
				}else{
					echo "<center><B style='color:red'><h1 style='font-size: 80px;'>เกิดข้อผิดพลาด</h1>
		<h1 style='font-size: 80px;'>หมายเลขอ้างอิงนี้</h1>
		<h1 style='font-size: 80px;'>ถูกใช้งานแล้ว</h1></B>
		<p><a href='/topup/get.php'>[กลับไปลองอีกครั้ง]</a> </p></center>";
				}
				break;
				}else if($walletmoney == $checkid && $money == 110){
				$sql = "select * from users where username='".$_SESSION['user']['username']."'";
				$sqle = "SELECT * FROM histrory WHERE NumberWallet='$walletmoney'";
				$query = mysqli_query($con,$sqle);
				$result = mysqli_fetch_assoc($query);
				if($result['status'] == ''){
					echo "<center><B style='font-size: 60px;'><h1 style='color:green'>เติมเงินเรียบร้อย</h1>
					<h1>จำนวนเงิน ที่คุณเติมคือ $money บาท</h1>
					<h1>ขอบคุณที่ใช้บริการครับ !</h1></B>  
					<p><a href='/main'>[ไปเช่าเน็ตกันเถอะ]</a> </p></center>";
					$sql = "insert into histrory (NumberWallet,money,username,status) values ('$walletmoney','$money','".$_SESSION['user']['username']."',1)";
					mysqli_query($con,$sql);
					$sql1 = "insert into users (saldo) values ('$money') where username='".$_SESSION['user']['username']."'";
					$sql1 = "update users set saldo=saldo+'".$money."'where username='".$_SESSION['user']['username']."'";
					mysqli_query($con,$sql1) or die; ('Error Query');
				}else{
					echo "<center><B style='color:red'><h1 style='font-size: 80px;'>เกิดข้อผิดพลาด</h1>
		<h1 style='font-size: 80px;'>หมายเลขอ้างอิงนี้</h1>
		<h1 style='font-size: 80px;'>ถูกใช้งานแล้ว</h1></B>
		<p><a href='/topup/get.php'>[กลับไปลองอีกครั้ง]</a> </p></center>";
				}
				break;
			}else if($walletmoney == $checkid && $money == 115){
				$sql = "select * from users where username='".$_SESSION['user']['username']."'";
				$sqle = "SELECT * FROM histrory WHERE NumberWallet='$walletmoney'";
				$query = mysqli_query($con,$sqle);
				$result = mysqli_fetch_assoc($query);
				if($result['status'] == ''){
					echo "<center><B style='font-size: 60px;'><h1 style='color:green'>เติมเงินเรียบร้อย</h1>
					<h1>จำนวนเงิน ที่คุณเติมคือ $money บาท</h1>
					<h1>ขอบคุณที่ใช้บริการครับ !</h1></B>  
					<p><a href='/main'>[ไปเช่าเน็ตกันเถอะ]</a> </p></center>";
					$sql = "insert into histrory (NumberWallet,money,username,status) values ('$walletmoney','$money','".$_SESSION['user']['username']."',1)";
					mysqli_query($con,$sql);
					$sql1 = "insert into users (saldo) values ('$money') where username='".$_SESSION['user']['username']."'";
					$sql1 = "update users set saldo=saldo+'".$money."'where username='".$_SESSION['user']['username']."'";
					mysqli_query($con,$sql1) or die; ('Error Query');
				}else{
					echo "<center><B style='color:red'><h1 style='font-size: 80px;'>เกิดข้อผิดพลาด</h1>
		<h1 style='font-size: 80px;'>หมายเลขอ้างอิงนี้</h1>
		<h1 style='font-size: 80px;'>ถูกใช้งานแล้ว</h1></B>
		<p><a href='/topup/get.php'>[กลับไปลองอีกครั้ง]</a> </p></center>";
				}
				break;
				}else if($walletmoney == $checkid && $money == 120){
				$sql = "select * from users where username='".$_SESSION['user']['username']."'";
				$sqle = "SELECT * FROM histrory WHERE NumberWallet='$walletmoney'";
				$query = mysqli_query($con,$sqle);
				$result = mysqli_fetch_assoc($query);
				if($result['status'] == ''){
					echo "<center><B style='font-size: 60px;'><h1 style='color:green'>เติมเงินเรียบร้อย</h1>
					<h1>จำนวนเงิน ที่คุณเติมคือ $money บาท</h1>
					<h1>ขอบคุณที่ใช้บริการครับ !</h1></B>  
					<p><a href='/main'>[ไปเช่าเน็ตกันเถอะ]</a> </p></center>";
					$sql = "insert into histrory (NumberWallet,money,username,status) values ('$walletmoney','$money','".$_SESSION['user']['username']."',1)";
					mysqli_query($con,$sql);
					$sql1 = "insert into users (saldo) values ('$money') where username='".$_SESSION['user']['username']."'";
					$sql1 = "update users set saldo=saldo+'".$money."'where username='".$_SESSION['user']['username']."'";
					mysqli_query($con,$sql1) or die; ('Error Query');
				}else{
					echo "<center><B style='color:red'><h1 style='font-size: 80px;'>เกิดข้อผิดพลาด</h1>
		<h1 style='font-size: 80px;'>หมายเลขอ้างอิงนี้</h1>
		<h1 style='font-size: 80px;'>ถูกใช้งานแล้ว</h1></B>
		<p><a href='/topup/get.php'>[กลับไปลองอีกครั้ง]</a> </p></center>";
				}
				break;
				}else if($walletmoney == $checkid && $money == 125){
				$sql = "select * from users where username='".$_SESSION['user']['username']."'";
				$sqle = "SELECT * FROM histrory WHERE NumberWallet='$walletmoney'";
				$query = mysqli_query($con,$sqle);
				$result = mysqli_fetch_assoc($query);
				if($result['status'] == ''){
					echo "<center><B style='font-size: 60px;'><h1 style='color:green'>เติมเงินเรียบร้อย</h1>
					<h1>จำนวนเงิน ที่คุณเติมคือ $money บาท</h1>
					<h1>ขอบคุณที่ใช้บริการครับ !</h1></B>  
					<p><a href='/main'>[ไปเช่าเน็ตกันเถอะ]</a> </p></center>";
					$sql = "insert into histrory (NumberWallet,money,username,status) values ('$walletmoney','$money','".$_SESSION['user']['username']."',1)";
					mysqli_query($con,$sql);
					$sql1 = "insert into users (saldo) values ('$money') where username='".$_SESSION['user']['username']."'";
					$sql1 = "update users set saldo=saldo+'".$money."'where username='".$_SESSION['user']['username']."'";
					mysqli_query($con,$sql1) or die; ('Error Query');
				}else{
					echo "<center><B style='color:red'><h1 style='font-size: 80px;'>เกิดข้อผิดพลาด</h1>
		<h1 style='font-size: 80px;'>หมายเลขอ้างอิงนี้</h1>
		<h1 style='font-size: 80px;'>ถูกใช้งานแล้ว</h1></B>
		<p><a href='/topup/get.php'>[กลับไปลองอีกครั้ง]</a> </p></center>";
				}
				break;
				}else if($walletmoney == $checkid && $money == 130){
				$sql = "select * from users where username='".$_SESSION['user']['username']."'";
				$sqle = "SELECT * FROM histrory WHERE NumberWallet='$walletmoney'";
				$query = mysqli_query($con,$sqle);
				$result = mysqli_fetch_assoc($query);
				if($result['status'] == ''){
					echo "<center><B style='font-size: 60px;'><h1 style='color:green'>เติมเงินเรียบร้อย</h1>
					<h1>จำนวนเงิน ที่คุณเติมคือ $money บาท</h1>
					<h1>ขอบคุณที่ใช้บริการครับ !</h1></B>  
					<p><a href='/main'>[ไปเช่าเน็ตกันเถอะ]</a> </p></center>";
					$sql = "insert into histrory (NumberWallet,money,username,status) values ('$walletmoney','$money','".$_SESSION['user']['username']."',1)";
					mysqli_query($con,$sql);
					$sql1 = "insert into users (saldo) values ('$money') where username='".$_SESSION['user']['username']."'";
					$sql1 = "update users set saldo=saldo+'".$money."'where username='".$_SESSION['user']['username']."'";
					mysqli_query($con,$sql1) or die; ('Error Query');
				}else{
					echo "<center><B style='color:red'><h1 style='font-size: 80px;'>เกิดข้อผิดพลาด</h1>
		<h1 style='font-size: 80px;'>หมายเลขอ้างอิงนี้</h1>
		<h1 style='font-size: 80px;'>ถูกใช้งานแล้ว</h1></B>
		<p><a href='/topup/get.php'>[กลับไปลองอีกครั้ง]</a> </p></center>";
				}
				break;
				}else if($walletmoney == $checkid && $money == 135){
				$sql = "select * from users where username='".$_SESSION['user']['username']."'";
				$sqle = "SELECT * FROM histrory WHERE NumberWallet='$walletmoney'";
				$query = mysqli_query($con,$sqle);
				$result = mysqli_fetch_assoc($query);
				if($result['status'] == ''){
					echo "<center><B style='font-size: 60px;'><h1 style='color:green'>เติมเงินเรียบร้อย</h1>
					<h1>จำนวนเงิน ที่คุณเติมคือ $money บาท</h1>
					<h1>ขอบคุณที่ใช้บริการครับ !</h1></B>  
					<p><a href='/main'>[ไปเช่าเน็ตกันเถอะ]</a> </p></center>";
					$sql = "insert into histrory (NumberWallet,money,username,status) values ('$walletmoney','$money','".$_SESSION['user']['username']."',1)";
					mysqli_query($con,$sql);
					$sql1 = "insert into users (saldo) values ('$money') where username='".$_SESSION['user']['username']."'";
					$sql1 = "update users set saldo=saldo+'".$money."'where username='".$_SESSION['user']['username']."'";
					mysqli_query($con,$sql1) or die; ('Error Query');
				}else{
					echo "<center><B style='color:red'><h1 style='font-size: 80px;'>เกิดข้อผิดพลาด</h1>
		<h1 style='font-size: 80px;'>หมายเลขอ้างอิงนี้</h1>
		<h1 style='font-size: 80px;'>ถูกใช้งานแล้ว</h1></B>
		<p><a href='/topup/get.php'>[กลับไปลองอีกครั้ง]</a> </p></center>";
				}
				break;
				}else if($walletmoney == $checkid && $money == 140){
				$sql = "select * from users where username='".$_SESSION['user']['username']."'";
				$sqle = "SELECT * FROM histrory WHERE NumberWallet='$walletmoney'";
				$query = mysqli_query($con,$sqle);
				$result = mysqli_fetch_assoc($query);
				if($result['status'] == ''){
					echo "<center><B style='font-size: 60px;'><h1 style='color:green'>เติมเงินเรียบร้อย</h1>
					<h1>จำนวนเงิน ที่คุณเติมคือ $money บาท</h1>
					<h1>ขอบคุณที่ใช้บริการครับ !</h1></B>  
					<p><a href='/main'>[ไปเช่าเน็ตกันเถอะ]</a> </p></center>";
					$sql = "insert into histrory (NumberWallet,money,username,status) values ('$walletmoney','$money','".$_SESSION['user']['username']."',1)";
					mysqli_query($con,$sql);
					$sql1 = "insert into users (saldo) values ('$money') where username='".$_SESSION['user']['username']."'";
					$sql1 = "update users set saldo=saldo+'".$money."'where username='".$_SESSION['user']['username']."'";
					mysqli_query($con,$sql1) or die; ('Error Query');
				}else{
					echo "<center><B style='color:red'><h1 style='font-size: 80px;'>เกิดข้อผิดพลาด</h1>
		<h1 style='font-size: 80px;'>หมายเลขอ้างอิงนี้</h1>
		<h1 style='font-size: 80px;'>ถูกใช้งานแล้ว</h1></B>
		<p><a href='/topup/get.php'>[กลับไปลองอีกครั้ง]</a> </p></center>";
				}
				break;
				}else if($walletmoney == $checkid && $money == 145){
				$sql = "select * from users where username='".$_SESSION['user']['username']."'";
				$sqle = "SELECT * FROM histrory WHERE NumberWallet='$walletmoney'";
				$query = mysqli_query($con,$sqle);
				$result = mysqli_fetch_assoc($query);
				if($result['status'] == ''){
					echo "<center><B style='font-size: 60px;'><h1 style='color:green'>เติมเงินเรียบร้อย</h1>
					<h1>จำนวนเงิน ที่คุณเติมคือ $money บาท</h1>
					<h1>ขอบคุณที่ใช้บริการครับ !</h1></B>  
					<p><a href='/main'>[ไปเช่าเน็ตกันเถอะ]</a> </p></center>";
					$sql = "insert into histrory (NumberWallet,money,username,status) values ('$walletmoney','$money','".$_SESSION['user']['username']."',1)";
					mysqli_query($con,$sql);
					$sql1 = "insert into users (saldo) values ('$money') where username='".$_SESSION['user']['username']."'";
					$sql1 = "update users set saldo=saldo+'".$money."'where username='".$_SESSION['user']['username']."'";
					mysqli_query($con,$sql1) or die; ('Error Query');
				}else{
					echo "<center><B style='color:red'><h1 style='font-size: 80px;'>เกิดข้อผิดพลาด</h1>
		<h1 style='font-size: 80px;'>หมายเลขอ้างอิงนี้</h1>
		<h1 style='font-size: 80px;'>ถูกใช้งานแล้ว</h1></B>
		<p><a href='/topup/get.php'>[กลับไปลองอีกครั้ง]</a> </p></center>";
				}
				break;
				}else if($walletmoney == $checkid && $money == 150){
				$sql = "select * from users where username='".$_SESSION['user']['username']."'";
				$sqle = "SELECT * FROM histrory WHERE NumberWallet='$walletmoney'";
				$query = mysqli_query($con,$sqle);
				$result = mysqli_fetch_assoc($query);
				if($result['status'] == ''){
					echo "<center><B style='font-size: 60px;'><h1 style='color:green'>เติมเงินเรียบร้อย</h1>
					<h1>จำนวนเงิน ที่คุณเติมคือ $money บาท</h1>
					<h1>ขอบคุณที่ใช้บริการครับ !</h1></B>  
					<p><a href='/main'>[ไปเช่าเน็ตกันเถอะ]</a> </p></center>";
					$sql = "insert into histrory (NumberWallet,money,username,status) values ('$walletmoney','$money','".$_SESSION['user']['username']."',1)";
					mysqli_query($con,$sql);
					$sql1 = "insert into users (saldo) values ('$money') where username='".$_SESSION['user']['username']."'";
					$sql1 = "update users set saldo=saldo+'".$money."'where username='".$_SESSION['user']['username']."'";
					mysqli_query($con,$sql1) or die; ('Error Query');
				}else{
					echo "<center><B style='color:red'><h1 style='font-size: 80px;'>เกิดข้อผิดพลาด</h1>
		<h1 style='font-size: 80px;'>หมายเลขอ้างอิงนี้</h1>
		<h1 style='font-size: 80px;'>ถูกใช้งานแล้ว</h1></B>
		<p><a href='/topup/get.php'>[กลับไปลองอีกครั้ง]</a> </p></center>";
				}
				break;
				}else if($walletmoney == $checkid && $money == 155){
				$sql = "select * from users where username='".$_SESSION['user']['username']."'";
				$sqle = "SELECT * FROM histrory WHERE NumberWallet='$walletmoney'";
				$query = mysqli_query($con,$sqle);
				$result = mysqli_fetch_assoc($query);
				if($result['status'] == ''){
					echo "<center><B style='font-size: 60px;'><h1 style='color:green'>เติมเงินเรียบร้อย</h1>
					<h1>จำนวนเงิน ที่คุณเติมคือ $money บาท</h1>
					<h1>ขอบคุณที่ใช้บริการครับ !</h1></B>  
					<p><a href='/main'>[ไปเช่าเน็ตกันเถอะ]</a> </p></center>";
					$sql = "insert into histrory (NumberWallet,money,username,status) values ('$walletmoney','$money','".$_SESSION['user']['username']."',1)";
					mysqli_query($con,$sql);
					$sql1 = "insert into users (saldo) values ('$money') where username='".$_SESSION['user']['username']."'";
					$sql1 = "update users set saldo=saldo+'".$money."'where username='".$_SESSION['user']['username']."'";
					mysqli_query($con,$sql1) or die; ('Error Query');
				}else{
					echo "<center><B style='color:red'><h1 style='font-size: 80px;'>เกิดข้อผิดพลาด</h1>
		<h1 style='font-size: 80px;'>หมายเลขอ้างอิงนี้</h1>
		<h1 style='font-size: 80px;'>ถูกใช้งานแล้ว</h1></B>
		<p><a href='/topup/get.php'>[กลับไปลองอีกครั้ง]</a> </p></center>";
				}
				break;
				}else if($walletmoney == $checkid && $money == 160){
				$sql = "select * from users where username='".$_SESSION['user']['username']."'";
				$sqle = "SELECT * FROM histrory WHERE NumberWallet='$walletmoney'";
				$query = mysqli_query($con,$sqle);
				$result = mysqli_fetch_assoc($query);
				if($result['status'] == ''){
					echo "<center><B style='font-size: 60px;'><h1 style='color:green'>เติมเงินเรียบร้อย</h1>
					<h1>จำนวนเงิน ที่คุณเติมคือ $money บาท</h1>
					<h1>ขอบคุณที่ใช้บริการครับ !</h1></B>  
					<p><a href='/main'>[ไปเช่าเน็ตกันเถอะ]</a> </p></center>";
					$sql = "insert into histrory (NumberWallet,money,username,status) values ('$walletmoney','$money','".$_SESSION['user']['username']."',1)";
					mysqli_query($con,$sql);
					$sql1 = "insert into users (saldo) values ('$money') where username='".$_SESSION['user']['username']."'";
					$sql1 = "update users set saldo=saldo+'".$money."'where username='".$_SESSION['user']['username']."'";
					mysqli_query($con,$sql1) or die; ('Error Query');
				}else{
					echo "<center><B style='color:red'><h1 style='font-size: 80px;'>เกิดข้อผิดพลาด</h1>
		<h1 style='font-size: 80px;'>หมายเลขอ้างอิงนี้</h1>
		<h1 style='font-size: 80px;'>ถูกใช้งานแล้ว</h1></B>
		<p><a href='/topup/get.php'>[กลับไปลองอีกครั้ง]</a> </p></center>";
				}
				break;
				}else if($walletmoney == $checkid && $money == 165){
				$sql = "select * from users where username='".$_SESSION['user']['username']."'";
				$sqle = "SELECT * FROM histrory WHERE NumberWallet='$walletmoney'";
				$query = mysqli_query($con,$sqle);
				$result = mysqli_fetch_assoc($query);
				if($result['status'] == ''){
					echo "<center><B style='font-size: 60px;'><h1 style='color:green'>เติมเงินเรียบร้อย</h1>
					<h1>จำนวนเงิน ที่คุณเติมคือ $money บาท</h1>
					<h1>ขอบคุณที่ใช้บริการครับ !</h1></B>  
					<p><a href='/main'>[ไปเช่าเน็ตกันเถอะ]</a> </p></center>";
					$sql = "insert into histrory (NumberWallet,money,username,status) values ('$walletmoney','$money','".$_SESSION['user']['username']."',1)";
					mysqli_query($con,$sql);
					$sql1 = "insert into users (saldo) values ('$money') where username='".$_SESSION['user']['username']."'";
					$sql1 = "update users set saldo=saldo+'".$money."'where username='".$_SESSION['user']['username']."'";
					mysqli_query($con,$sql1) or die; ('Error Query');
				}else{
					echo "<center><B style='color:red'><h1 style='font-size: 80px;'>เกิดข้อผิดพลาด</h1>
		<h1 style='font-size: 80px;'>หมายเลขอ้างอิงนี้</h1>
		<h1 style='font-size: 80px;'>ถูกใช้งานแล้ว</h1></B>
		<p><a href='/topup/get.php'>[กลับไปลองอีกครั้ง]</a> </p></center>";
				}
				break;
				}else if($walletmoney == $checkid && $money == 170){
				$sql = "select * from users where username='".$_SESSION['user']['username']."'";
				$sqle = "SELECT * FROM histrory WHERE NumberWallet='$walletmoney'";
				$query = mysqli_query($con,$sqle);
				$result = mysqli_fetch_assoc($query);
				if($result['status'] == ''){
					echo "<center><B style='font-size: 60px;'><h1 style='color:green'>เติมเงินเรียบร้อย</h1>
					<h1>จำนวนเงิน ที่คุณเติมคือ $money บาท</h1>
					<h1>ขอบคุณที่ใช้บริการครับ !</h1></B>  
					<p><a href='/main'>[ไปเช่าเน็ตกันเถอะ]</a> </p></center>";
					$sql = "insert into histrory (NumberWallet,money,username,status) values ('$walletmoney','$money','".$_SESSION['user']['username']."',1)";
					mysqli_query($con,$sql);
					$sql1 = "insert into users (saldo) values ('$money') where username='".$_SESSION['user']['username']."'";
					$sql1 = "update users set saldo=saldo+'".$money."'where username='".$_SESSION['user']['username']."'";
					mysqli_query($con,$sql1) or die; ('Error Query');
				}else{
					echo "<center><B style='color:red'><h1 style='font-size: 80px;'>เกิดข้อผิดพลาด</h1>
		<h1 style='font-size: 80px;'>หมายเลขอ้างอิงนี้</h1>
		<h1 style='font-size: 80px;'>ถูกใช้งานแล้ว</h1></B>
		<p><a href='/topup/get.php'>[กลับไปลองอีกครั้ง]</a> </p></center>";
				}
				break;
				}else if($walletmoney == $checkid && $money == 175){
				$sql = "select * from users where username='".$_SESSION['user']['username']."'";
				$sqle = "SELECT * FROM histrory WHERE NumberWallet='$walletmoney'";
				$query = mysqli_query($con,$sqle);
				$result = mysqli_fetch_assoc($query);
				if($result['status'] == ''){
					echo "<center><B style='font-size: 60px;'><h1 style='color:green'>เติมเงินเรียบร้อย</h1>
					<h1>จำนวนเงิน ที่คุณเติมคือ $money บาท</h1>
					<h1>ขอบคุณที่ใช้บริการครับ !</h1></B>  
					<p><a href='/main'>[ไปเช่าเน็ตกันเถอะ]</a> </p></center>";
					$sql = "insert into histrory (NumberWallet,money,username,status) values ('$walletmoney','$money','".$_SESSION['user']['username']."',1)";
					mysqli_query($con,$sql);
					$sql1 = "insert into users (saldo) values ('$money') where username='".$_SESSION['user']['username']."'";
					$sql1 = "update users set saldo=saldo+'".$money."'where username='".$_SESSION['user']['username']."'";
					mysqli_query($con,$sql1) or die; ('Error Query');
				}else{
					echo "<center><B style='color:red'><h1 style='font-size: 80px;'>เกิดข้อผิดพลาด</h1>
		<h1 style='font-size: 80px;'>หมายเลขอ้างอิงนี้</h1>
		<h1 style='font-size: 80px;'>ถูกใช้งานแล้ว</h1></B>
		<p><a href='/topup/get.php'>[กลับไปลองอีกครั้ง]</a> </p></center>";
				}
				break;
				}else if($walletmoney == $checkid && $money == 180){
				$sql = "select * from users where username='".$_SESSION['user']['username']."'";
				$sqle = "SELECT * FROM histrory WHERE NumberWallet='$walletmoney'";
				$query = mysqli_query($con,$sqle);
				$result = mysqli_fetch_assoc($query);
				if($result['status'] == ''){
					echo "<center><B style='font-size: 60px;'><h1 style='color:green'>เติมเงินเรียบร้อย</h1>
					<h1>จำนวนเงิน ที่คุณเติมคือ $money บาท</h1>
					<h1>ขอบคุณที่ใช้บริการครับ !</h1></B>  
					<p><a href='/main'>[ไปเช่าเน็ตกันเถอะ]</a> </p></center>";
					$sql = "insert into histrory (NumberWallet,money,username,status) values ('$walletmoney','$money','".$_SESSION['user']['username']."',1)";
					mysqli_query($con,$sql);
					$sql1 = "insert into users (saldo) values ('$money') where username='".$_SESSION['user']['username']."'";
					$sql1 = "update users set saldo=saldo+'".$money."'where username='".$_SESSION['user']['username']."'";
					mysqli_query($con,$sql1) or die; ('Error Query');
				}else{
					echo "<center><B style='color:red'><h1 style='font-size: 80px;'>เกิดข้อผิดพลาด</h1>
		<h1 style='font-size: 80px;'>หมายเลขอ้างอิงนี้</h1>
		<h1 style='font-size: 80px;'>ถูกใช้งานแล้ว</h1></B>
		<p><a href='/topup/get.php'>[กลับไปลองอีกครั้ง]</a> </p></center>";
				}
				break;
				}else if($walletmoney == $checkid && $money == 185){
				$sql = "select * from users where username='".$_SESSION['user']['username']."'";
				$sqle = "SELECT * FROM histrory WHERE NumberWallet='$walletmoney'";
				$query = mysqli_query($con,$sqle);
				$result = mysqli_fetch_assoc($query);
				if($result['status'] == ''){
					echo "<center><B style='font-size: 60px;'><h1 style='color:green'>เติมเงินเรียบร้อย</h1>
					<h1>จำนวนเงิน ที่คุณเติมคือ $money บาท</h1>
					<h1>ขอบคุณที่ใช้บริการครับ !</h1></B>  
					<p><a href='/main'>[ไปเช่าเน็ตกันเถอะ]</a> </p></center>";
					$sql = "insert into histrory (NumberWallet,money,username,status) values ('$walletmoney','$money','".$_SESSION['user']['username']."',1)";
					mysqli_query($con,$sql);
					$sql1 = "insert into users (saldo) values ('$money') where username='".$_SESSION['user']['username']."'";
					$sql1 = "update users set saldo=saldo+'".$money."'where username='".$_SESSION['user']['username']."'";
					mysqli_query($con,$sql1) or die; ('Error Query');
				}else{
					echo "<center><B style='color:red'><h1 style='font-size: 80px;'>เกิดข้อผิดพลาด</h1>
		<h1 style='font-size: 80px;'>หมายเลขอ้างอิงนี้</h1>
		<h1 style='font-size: 80px;'>ถูกใช้งานแล้ว</h1></B>
		<p><a href='/topup/get.php'>[กลับไปลองอีกครั้ง]</a> </p></center>";
				}
				break;
				}else if($walletmoney == $checkid && $money == 190){
				$sql = "select * from users where username='".$_SESSION['user']['username']."'";
				$sqle = "SELECT * FROM histrory WHERE NumberWallet='$walletmoney'";
				$query = mysqli_query($con,$sqle);
				$result = mysqli_fetch_assoc($query);
				if($result['status'] == ''){
					echo "<center><B style='font-size: 60px;'><h1 style='color:green'>เติมเงินเรียบร้อย</h1>
					<h1>จำนวนเงิน ที่คุณเติมคือ $money บาท</h1>
					<h1>ขอบคุณที่ใช้บริการครับ !</h1></B>  
					<p><a href='/main'>[ไปเช่าเน็ตกันเถอะ]</a> </p></center>";
					$sql = "insert into histrory (NumberWallet,money,username,status) values ('$walletmoney','$money','".$_SESSION['user']['username']."',1)";
					mysqli_query($con,$sql);
					$sql1 = "insert into users (saldo) values ('$money') where username='".$_SESSION['user']['username']."'";
					$sql1 = "update users set saldo=saldo+'".$money."'where username='".$_SESSION['user']['username']."'";
					mysqli_query($con,$sql1) or die; ('Error Query');
				}else{
					echo "<center><B style='color:red'><h1 style='font-size: 80px;'>เกิดข้อผิดพลาด</h1>
		<h1 style='font-size: 80px;'>หมายเลขอ้างอิงนี้</h1>
		<h1 style='font-size: 80px;'>ถูกใช้งานแล้ว</h1></B>
		<p><a href='/topup/get.php'>[กลับไปลองอีกครั้ง]</a> </p></center>";
				}
				break;
				}else if($walletmoney == $checkid && $money == 195){
				$sql = "select * from users where username='".$_SESSION['user']['username']."'";
				$sqle = "SELECT * FROM histrory WHERE NumberWallet='$walletmoney'";
				$query = mysqli_query($con,$sqle);
				$result = mysqli_fetch_assoc($query);
				if($result['status'] == ''){
					echo "<center><B style='font-size: 60px;'><h1 style='color:green'>เติมเงินเรียบร้อย</h1>
					<h1>จำนวนเงิน ที่คุณเติมคือ $money บาท</h1>
					<h1>ขอบคุณที่ใช้บริการครับ !</h1></B>  
					<p><a href='/main'>[ไปเช่าเน็ตกันเถอะ]</a> </p></center>";
					$sql = "insert into histrory (NumberWallet,money,username,status) values ('$walletmoney','$money','".$_SESSION['user']['username']."',1)";
					mysqli_query($con,$sql);
					$sql1 = "insert into users (saldo) values ('$money') where username='".$_SESSION['user']['username']."'";
					$sql1 = "update users set saldo=saldo+'".$money."'where username='".$_SESSION['user']['username']."'";
					mysqli_query($con,$sql1) or die; ('Error Query');
				}else{
					echo "<center><B style='color:red'><h1 style='font-size: 80px;'>เกิดข้อผิดพลาด</h1>
		<h1 style='font-size: 80px;'>หมายเลขอ้างอิงนี้</h1>
		<h1 style='font-size: 80px;'>ถูกใช้งานแล้ว</h1></B>
		<p><a href='/topup/get.php'>[กลับไปลองอีกครั้ง]</a> </p></center>";
				}
				break;
				}else if($walletmoney == $checkid && $money == 200){
				$sql = "select * from users where username='".$_SESSION['user']['username']."'";
				$sqle = "SELECT * FROM histrory WHERE NumberWallet='$walletmoney'";
				$query = mysqli_query($con,$sqle);
				$result = mysqli_fetch_assoc($query);
				if($result['status'] == ''){
					echo "<center><B style='font-size: 60px;'><h1 style='color:green'>เติมเงินเรียบร้อย</h1>
					<h1>จำนวนเงิน ที่คุณเติมคือ $money บาท</h1>
					<h1>ขอบคุณที่ใช้บริการครับ !</h1></B>  
					<p><a href='/main'>[ไปเช่าเน็ตกันเถอะ]</a> </p></center>";
					$sql = "insert into histrory (NumberWallet,money,username,status) values ('$walletmoney','$money','".$_SESSION['user']['username']."',1)";
					mysqli_query($con,$sql);
					$sql1 = "insert into users (saldo) values ('$money') where username='".$_SESSION['user']['username']."'";
					$sql1 = "update users set saldo=saldo+'".$money."'where username='".$_SESSION['user']['username']."'";
					mysqli_query($con,$sql1) or die; ('Error Query');
				}else{
					echo "<center><B style='color:red'><h1 style='font-size: 80px;'>เกิดข้อผิดพลาด</h1>
		<h1 style='font-size: 80px;'>หมายเลขอ้างอิงนี้</h1>
		<h1 style='font-size: 80px;'>ถูกใช้งานแล้ว</h1></B>
		<p><a href='/topup/get.php'>[กลับไปลองอีกครั้ง]</a> </p></center>";
				}
				break;
				}else if($walletmoney == $checkid && $money == 250){
				$sql = "select * from users where username='".$_SESSION['user']['username']."'";
				$sqle = "SELECT * FROM histrory WHERE NumberWallet='$walletmoney'";
				$query = mysqli_query($con,$sqle);
				$result = mysqli_fetch_assoc($query);
				if($result['status'] == ''){
					echo "<center><B style='font-size: 60px;'><h1 style='color:green'>เติมเงินเรียบร้อย</h1>
					<h1>จำนวนเงิน ที่คุณเติมคือ $money บาท</h1>
					<h1>ขอบคุณที่ใช้บริการครับ !</h1></B>  
					<p><a href='/main'>[ไปเช่าเน็ตกันเถอะ]</a> </p></center>";
					$sql = "insert into histrory (NumberWallet,money,username,status) values ('$walletmoney','$money','".$_SESSION['user']['username']."',1)";
					mysqli_query($con,$sql);
					$sql1 = "insert into users (saldo) values ('$money') where username='".$_SESSION['user']['username']."'";
					$sql1 = "update users set saldo=saldo+'".$money."'where username='".$_SESSION['user']['username']."'";
					mysqli_query($con,$sql1) or die; ('Error Query');
				}else{
					echo "<center><B style='color:red'><h1 style='font-size: 80px;'>เกิดข้อผิดพลาด</h1>
		<h1 style='font-size: 80px;'>หมายเลขอ้างอิงนี้</h1>
		<h1 style='font-size: 80px;'>ถูกใช้งานแล้ว</h1></B>
		<p><a href='/topup/get.php'>[กลับไปลองอีกครั้ง]</a> </p></center>";
				}
				break;
				}else if($walletmoney == $checkid && $money == 300){
				$sql = "select * from users where username='".$_SESSION['user']['username']."'";
				$sqle = "SELECT * FROM histrory WHERE NumberWallet='$walletmoney'";
				$query = mysqli_query($con,$sqle);
				$result = mysqli_fetch_assoc($query);
				if($result['status'] == ''){
				echo "<center><B style='font-size: 60px;'><h1 style='color:green'>เติมเงินเรียบร้อย</h1>
					<h1>จำนวนเงิน ที่คุณเติมคือ $money บาท</h1>
					<h1>ขอบคุณที่ใช้บริการครับ !</h1></B>  
					<p><a href='/main'>[ไปเช่าเน็ตกันเถอะ]</a> </p></center>";
					$sql = "insert into histrory (NumberWallet,money,username,status) values ('$walletmoney','$money','".$_SESSION['user']['username']."',1)";
					mysqli_query($con,$sql);
					$sql1 = "insert into users (saldo) values ('$money') where username='".$_SESSION['user']['username']."'";
					$sql1 = "update users set saldo=saldo+'".$money."'where username='".$_SESSION['user']['username']."'";
					mysqli_query($con,$sql1) or die; ('Error Query');
				}else{
					echo "<center><B style='color:red'><h1 style='font-size: 80px;'>เกิดข้อผิดพลาด</h1>
		<h1 style='font-size: 80px;'>หมายเลขอ้างอิงนี้</h1>
		<h1 style='font-size: 80px;'>ถูกใช้งานแล้ว</h1></B>
		<p><a href='/topup/get.php'>[กลับไปลองอีกครั้ง]</a> </p></center>";
				}
				break;
				}else if($walletmoney == $checkid && $money == 350){
				$sql = "select * from users where username='".$_SESSION['user']['username']."'";
				$sqle = "SELECT * FROM histrory WHERE NumberWallet='$walletmoney'";
				$query = mysqli_query($con,$sqle);
				$result = mysqli_fetch_assoc($query);
				if($result['status'] == ''){
					echo "<center><B style='font-size: 60px;'><h1 style='color:green'>เติมเงินเรียบร้อย</h1>
					<h1>จำนวนเงิน ที่คุณเติมคือ $money บาท</h1>
					<h1>ขอบคุณที่ใช้บริการครับ !</h1></B>  
					<p><a href='/main'>[ไปเช่าเน็ตกันเถอะ]</a> </p></center>";
					$sql = "insert into histrory (NumberWallet,money,username,status) values ('$walletmoney','$money','".$_SESSION['user']['username']."',1)";
					mysqli_query($con,$sql);
					$sql1 = "insert into users (saldo) values ('$money') where username='".$_SESSION['user']['username']."'";
					$sql1 = "update users set saldo=saldo+'".$money."'where username='".$_SESSION['user']['username']."'";
					mysqli_query($con,$sql1) or die; ('Error Query');
				}else{
					echo "<center><B style='color:red'><h1 style='font-size: 80px;'>เกิดข้อผิดพลาด</h1>
		<h1 style='font-size: 80px;'>หมายเลขอ้างอิงนี้</h1>
		<h1 style='font-size: 80px;'>ถูกใช้งานแล้ว</h1></B>
		<p><a href='/topup/get.php'>[กลับไปลองอีกครั้ง]</a> </p></center>";
				}
				break;
				}else if($walletmoney == $checkid && $money == 400){
				$sql = "select * from users where username='".$_SESSION['user']['username']."'";
				$sqle = "SELECT * FROM histrory WHERE NumberWallet='$walletmoney'";
				$query = mysqli_query($con,$sqle);
				$result = mysqli_fetch_assoc($query);
				if($result['status'] == ''){
					echo "<center><B style='font-size: 60px;'><h1 style='color:green'>เติมเงินเรียบร้อย</h1>
					<h1>จำนวนเงิน ที่คุณเติมคือ $money บาท</h1>
					<h1>ขอบคุณที่ใช้บริการครับ !</h1></B>  
					<p><a href='/main'>[ไปเช่าเน็ตกันเถอะ]</a> </p></center>";
					$sql = "insert into histrory (NumberWallet,money,username,status) values ('$walletmoney','$money','".$_SESSION['user']['username']."',1)";
					mysqli_query($con,$sql);
					$sql1 = "insert into users (saldo) values ('$money') where username='".$_SESSION['user']['username']."'";
					$sql1 = "update users set saldo=saldo+'".$money."'where username='".$_SESSION['user']['username']."'";
					mysqli_query($con,$sql1) or die; ('Error Query');
				}else{
					echo "<center><B style='color:red'><h1 style='font-size: 80px;'>เกิดข้อผิดพลาด</h1>
		<h1 style='font-size: 80px;'>หมายเลขอ้างอิงนี้</h1>
		<h1 style='font-size: 80px;'>ถูกใช้งานแล้ว</h1></B>
		<p><a href='/topup/get.php'>[กลับไปลองอีกครั้ง]</a> </p></center>";
				}
				break;
			}else{
					echo "<center><B style='font-size: 60px;'><h1 style='color:red'>เกิดข้อผิดพลาด</h1>
		<h1>เลขอ้างอิงไม่ครบหรือไม่ถูกต้อง</h1></B>
		<p><a href='/topup/get.php'>[กลับไปลองอีกครั้ง]</a> </p></center>";
				
				break;
			}
	}

	//Logout
	$wallet->logout();
}else{
	echo 'ยังไม่มีการเชื่อมต่อบัญชี!';
}
?>
