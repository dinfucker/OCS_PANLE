<?php SESSION_START(); include '../application/controllers/topup/wallet/config.php'; if(!$_SESSION['user']['username']){ header("location: login.php"); } $sql = "SELECT * FROM users WHERE username='".$_SESSION['user']['username']."'"; $query = mysqli_query($con,$sql) or die ("Error Query"); $result = mysqli_fetch_assoc($query); ?>
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>LIFESTYLE VPN</title>
  <link rel="SHORTCUT ICON" href="http://lifestyle-vpn.ga/asset/img/i4.png" <="" head="">
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">

  <link rel="stylesheet" href="/asset/css/bootstrap.min.css">
  <link href="/asset/css/bootstrap-dialog.min.css" rel="stylesheet">

  <!-- Bootstrap core CSS     -->
    <link href="/topup/assets/css/bootstrap.min.css" rel="stylesheet" />
    <!--  Material Dashboard CSS    -->
    <link href="/topup/assets/css/material-dashboard.css" rel="stylesheet" />
    <!--  CSS for Demo Purpose, don't include it in your project     -->
    <link href="/topup/assets/css/demo.css" rel="stylesheet" />
    <!-- Custom Fonts -->
    <link href="http://maxcdn.bootstrapcdn.com/font-awesome/latest/css/font-awesome.min.css" rel="stylesheet">
  	<link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
	  <link href='https://fonts.googleapis.com/css?family=Kanit|Mitr|Pridi:400,300&subset=thai,latin' rel='stylesheet' type='text/css'>
    <style>
		body {
		  font-family: 'Kanit', sans-serif;
		  font-family: 'Pridi', serif;
		  font-family: 'Mitr', sans-serif;
		}
		h1 {
		  font-family: 'Kanit', sans-serif;
		  font-family: 'Pridi', serif;
		  font-family: 'Mitr', sans-serif;
		}
    </style>
</head>
<body class="hold-transition register-page">
<br><br>
<div class="register-box">           
	<section class="content">
          <div class="main-panel">                                   
             <div class="content">
                 <div class="container-fluid">
                     <div class="row">  
                   	
                    	 <div class="col-md-9">
                            <div class="card card-profile">
                                <div class="card-avatar">
                                    <a href="#">
								
                                        <img class="img" src="/topup/assets/img/88.png" />
                                    </a>
                                </div>
                                <div class="content">
                                    <h5 class="category text-gray">WELCOME to LIFESTYLE VPN</h5>
                                    <h4 class="card-title">TRUE WALLET</h4>
                                   
                                    <button class="btn btn-primary btn-round">USERNAME</button>
			<p><b>ชื่อบัญชี :</b>			<?php echo $result['username'];?></p>
		<p><b>ยอนเงินคงเหลือ :</b>	    <?php echo $result['saldo'];?></p>
                                   <form action="confirm.php" method="post">
																			<div class="form-group">
																			<p class="card-content">
                                        นำหมายเลขอ้างอิงจากการโอนมาใส่<p>
																				<label>ดูจากรายการที่แอพ WALLET</label>
                                      </p>
                              <div class="col-sm-4">
								<div class="input-group text-center">
									<span class="input-group-addon">
									<i class="material-icons">next_week</i>
									</span>
										<input class="form-control" placeholder="ใส่เลขอ้างอิง" name="wallet" type="number" required>
								</div>    
							</div> <br><br><br><br>
																				
										<input class="btn btn-info btn-round" type="submit" value="ยืนยันเลขอ้างอิง" name="wallet" onClick="this.disabled=1;this.value='ตัวอย่าง การดูเลขอ้างอิง..';document.forms[0].submit();loading()" style="height:40px;font-size16px">								
		</form> 
	<div><a href="http://tmwallet.thaighost.net/images/transactionid.jpg" target="_transactionid">ตัวอย่าง การดูเลขอ้างอิง?</a></div></font>
                                </div>
                            </div>
                        </div>
                    </div>
                 </div>
             </div>

        </section>
    </div>
                   
</body>
</html>