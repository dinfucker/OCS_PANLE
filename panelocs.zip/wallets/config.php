<?php
$host = 'localhost';
$user = 'root';
$pass = 'dinfucker'; //ใส่รหัสครับ phpmyadmin
$db = 'LTE';
$con = mysqli_connect($host,$user,$pass,$db);
mysqli_set_charset($con);


$walletmoney = $_POST['wallet'];

ini_set('display_errors', 1);
include_once('manager/TrueWallet.php');
$wallet = new TrueWallet();

//ใส่ชื่อรหัส wallet ของคุณ
$username = "jame10000lnw@gmail.com"; 
$password = "0903927323q";

$wallet->logout();
